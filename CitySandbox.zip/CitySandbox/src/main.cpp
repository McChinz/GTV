// =====================================================================
//  CITY SANDBOX  v0.1  -  PS Vita (vitaGL, fixed-function pipeline)
//  First-person open-world city sandbox: walk a ~320m city grid with
//  NPC pedestrians, hold a rifle, aim down iron sights and shoot.
//
//  Controls
//    Left stick   move              Right stick  look
//    L            aim down sights   R            shoot (full auto)
//    Square       reload            Cross        jump
//    Circle(hold) sprint            Start        pause / controls
//    Pause menu: Select = quit to LiveArea
//
//  Requires ur0:data/libshacccg.suprx (runtime shader compiler).
// =====================================================================
#include <vitaGL.h>
#include <psp2/ctrl.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/power.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <vector>

// Padding in the read-only segment. vita-elf-create needs a few KB free after
// segment 0; the build script retries with different sizes if the layout is tight.
#ifndef ELF_PAD
#define ELF_PAD 16
#endif
extern const unsigned char g_elfPad[ELF_PAD];
const unsigned char g_elfPad[ELF_PAD] __attribute__((used, aligned(16))) = {1};

#define SCR_W 960
#define SCR_H 544
#define PI_F 3.14159265f

// ---------------------------------------------------------------------
//  Tunables
// ---------------------------------------------------------------------
static const float CELL        = 40.0f;   // block pitch (road center to road center)
static const float ROAD_HALF   = 6.0f;    // half width of an avenue (side streets are narrower)
static const float CURB_H      = 0.15f;   // sidewalk height
static const int   CELL_MIN    = -1;      // cells -1..8 (outer ring = skyline wall)
static const int   NCELL       = 10;
static const int   NCHUNK      = 5;       // 2x2 cells per render chunk
static const float WORLD_MIN   = -5.0f;   // playable area clamp
static const float WORLD_MAX   = 325.0f;

static const float WALK_SPEED   = 5.4f;   // ~60s to cross 320m
static const float SPRINT_SPEED = 8.6f;
static const float ADS_SPEED_MUL= 0.55f;
static const float JUMP_VEL     = 4.6f;
static const float GRAVITY      = 13.0f;
static const float EYE_HEIGHT   = 1.62f;
static const float PLAYER_RAD   = 0.35f;

static const float LOOK_YAW     = 2.7f;   // rad/s at full stick
static const float LOOK_PITCH   = 1.9f;
static const float ADS_LOOK_MUL = 0.45f;

static const float FOV_HIP      = 72.0f;
static const float FOV_ADS      = 46.0f;
static const float FOV_GUN      = 54.0f;
static const float FAR_PLANE    = 155.0f;
static const float FOG_START    = 50.0f;
static const float FOG_END      = 140.0f;
static const float PROP_DIST    = 62.0f;  // props (trees, cars, lights) LOD distance
static const float NPC_DRAW_DIST= 65.0f;

static const float FIRE_DELAY   = 0.095f; // ~630 rpm
static const int   NUM_NPCS     = 90;

// ---------------------------------------------------------------------
//  Math
// ---------------------------------------------------------------------
struct Vec3 { float x, y, z; };
static inline Vec3 v3(float x, float y, float z) { Vec3 r; r.x = x; r.y = y; r.z = z; return r; }
static inline Vec3 operator+(Vec3 a, Vec3 b) { return v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static inline Vec3 operator-(Vec3 a, Vec3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static inline Vec3 operator*(Vec3 a, float s) { return v3(a.x * s, a.y * s, a.z * s); }
static inline float dot3(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline Vec3 cross3(Vec3 a, Vec3 b) { return v3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
static inline float len3(Vec3 a) { return sqrtf(dot3(a, a)); }
static inline Vec3 norm3(Vec3 a) { float l = len3(a); return l > 1e-6f ? a * (1.0f / l) : v3(0, 1, 0); }
static inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static inline float approach(float cur, float target, float rate, float dt) {
    float k = 1.0f - expf(-rate * dt);
    return cur + (target - cur) * k;
}
static inline float wrapAngle(float a) {
    while (a > PI_F) a -= 2.0f * PI_F;
    while (a < -PI_F) a += 2.0f * PI_F;
    return a;
}

struct Mat4 { float m[16]; };
static Mat4 mIdent() { Mat4 r; memset(r.m, 0, sizeof(r.m)); r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.0f; return r; }
static Mat4 mMul(const Mat4& a, const Mat4& b) {
    Mat4 r;
    for (int c = 0; c < 4; c++)
        for (int rr = 0; rr < 4; rr++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a.m[k * 4 + rr] * b.m[c * 4 + k];
            r.m[c * 4 + rr] = s;
        }
    return r;
}
static Mat4 mTrans(float x, float y, float z) { Mat4 r = mIdent(); r.m[12] = x; r.m[13] = y; r.m[14] = z; return r; }
static Mat4 mScale(float s) { Mat4 r = mIdent(); r.m[0] = r.m[5] = r.m[10] = s; return r; }
static Mat4 mRotX(float a) { Mat4 r = mIdent(); float c = cosf(a), s = sinf(a); r.m[5] = c; r.m[9] = -s; r.m[6] = s; r.m[10] = c; return r; }
static Mat4 mRotY(float a) { Mat4 r = mIdent(); float c = cosf(a), s = sinf(a); r.m[0] = c; r.m[8] = s; r.m[2] = -s; r.m[10] = c; return r; }
static Mat4 mRotZ(float a) { Mat4 r = mIdent(); float c = cosf(a), s = sinf(a); r.m[0] = c; r.m[4] = -s; r.m[1] = s; r.m[5] = c; return r; }
static Vec3 mApply(const Mat4& M, Vec3 p) {
    return v3(M.m[0] * p.x + M.m[4] * p.y + M.m[8] * p.z + M.m[12],
              M.m[1] * p.x + M.m[5] * p.y + M.m[9] * p.z + M.m[13],
              M.m[2] * p.x + M.m[6] * p.y + M.m[10] * p.z + M.m[14]);
}
static Mat4 mPerspective(float fovyDeg, float aspect, float n, float f) {
    Mat4 r; memset(r.m, 0, sizeof(r.m));
    float t = 1.0f / tanf(fovyDeg * PI_F / 360.0f);
    r.m[0] = t / aspect; r.m[5] = t;
    r.m[10] = (f + n) / (n - f); r.m[11] = -1.0f;
    r.m[14] = (2.0f * f * n) / (n - f);
    return r;
}
static Mat4 mOrtho(float l, float rr, float b, float t, float n, float f) {
    Mat4 r = mIdent();
    r.m[0] = 2.0f / (rr - l); r.m[5] = 2.0f / (t - b); r.m[10] = -2.0f / (f - n);
    r.m[12] = -(rr + l) / (rr - l); r.m[13] = -(t + b) / (t - b); r.m[14] = -(f + n) / (f - n);
    return r;
}

// ---------------------------------------------------------------------
//  RNG
// ---------------------------------------------------------------------
static uint32_t g_rng = 0x1234567u;
static inline uint32_t xrand() { g_rng ^= g_rng << 13; g_rng ^= g_rng >> 17; g_rng ^= g_rng << 5; return g_rng; }
static inline float frand() { return (xrand() & 0xFFFFFF) / 16777216.0f; }
static inline float frange(float a, float b) { return a + (b - a) * frand(); }
static inline float hash2(int x, int y, int s) {
    uint32_t h = (uint32_t)x * 374761393u + (uint32_t)y * 668265263u + (uint32_t)s * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u; h ^= h >> 16;
    return (h & 0xFFFF) / 65535.0f;
}

// ---------------------------------------------------------------------
//  Mesh (separate tightly packed arrays -> simplest vitaGL client path)
// ---------------------------------------------------------------------
struct Col { float r, g, b, a; };
static inline Col col4(float r, float g, float b, float a = 1.0f) { Col c; c.r = r; c.g = g; c.b = b; c.a = a; return c; }
static inline Col shadeC(Col c, float s) { return col4(c.r * s, c.g * s, c.b * s, c.a); }

struct Mesh {
    std::vector<float> p, t, c;
    void clear() { p.clear(); t.clear(); c.clear(); }
    int count() const { return (int)(p.size() / 3); }
    inline void v(Vec3 q, float u, float w, const Col& k) {
        p.push_back(q.x); p.push_back(q.y); p.push_back(q.z);
        t.push_back(u); t.push_back(w);
        c.push_back(k.r); c.push_back(k.g); c.push_back(k.b); c.push_back(k.a);
    }
};

static void quad(Mesh& m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, float u0, float v0, float u1, float v1, Col k) {
    m.v(a, u0, v0, k); m.v(b, u1, v0, k); m.v(c, u1, v1, k);
    m.v(a, u0, v0, k); m.v(c, u1, v1, k); m.v(d, u0, v1, k);
}

// Horizontal quad (facing up), uv = world coords * uvs
static void topQuad(Mesh& m, float x0, float z0, float x1, float z1, float y, float uvs, Col k) {
    quad(m, v3(x0, y, z0), v3(x1, y, z0), v3(x1, y, z1), v3(x0, y, z1),
         x0 * uvs, z0 * uvs, x1 * uvs, z1 * uvs, k);
}

// u repeats: uSize > 0 -> round(width/uSize) whole repeats, uSize < 0 -> width/|uSize|, 0 -> 1
static inline float repeatsFor(float w, float s) {
    if (s > 0) { float r = floorf(w / s + 0.5f); return r < 1 ? 1 : r; }
    if (s < 0) return w / -s;
    return 1.0f;
}

// Four vertical walls of an axis aligned box (no top/bottom)
static void sideFaces(Mesh& m, float x0, float z0, float x1, float z1, float y0, float y1,
                      float uSize, float vSize, Col k) {
    float ux = repeatsFor(x1 - x0, uSize), uz = repeatsFor(z1 - z0, uSize);
    float vv = repeatsFor(y1 - y0, vSize);
    quad(m, v3(x0, y0, z0), v3(x1, y0, z0), v3(x1, y1, z0), v3(x0, y1, z0), 0, 0, ux, vv, shadeC(k, 0.62f)); // -z
    quad(m, v3(x1, y0, z1), v3(x0, y0, z1), v3(x0, y1, z1), v3(x1, y1, z1), 0, 0, ux, vv, shadeC(k, 0.82f)); // +z
    quad(m, v3(x0, y0, z1), v3(x0, y0, z0), v3(x0, y1, z0), v3(x0, y1, z1), 0, 0, uz, vv, shadeC(k, 0.70f)); // -x
    quad(m, v3(x1, y0, z0), v3(x1, y0, z1), v3(x1, y1, z1), v3(x1, y1, z0), 0, 0, uz, vv, shadeC(k, 0.92f)); // +x
}

static void boxSolid(Mesh& m, float x0, float y0, float z0, float x1, float y1, float z1, Col k) {
    sideFaces(m, x0, z0, x1, z1, y0, y1, 0, 0, k);
    quad(m, v3(x0, y1, z0), v3(x1, y1, z0), v3(x1, y1, z1), v3(x0, y1, z1), 0, 0, 1, 1, k);
}

// Transformed box with simple directional lighting (for NPCs, gun)
static void xbox(Mesh& m, const Mat4& X, Vec3 mn, Vec3 mx, Col k, Vec3 L) {
    Vec3 p[8];
    for (int i = 0; i < 8; i++)
        p[i] = mApply(X, v3((i & 1) ? mx.x : mn.x, (i & 2) ? mx.y : mn.y, (i & 4) ? mx.z : mn.z));
    static const int F[6][4] = {
        {0, 1, 3, 2}, {5, 4, 6, 7}, {4, 0, 2, 6}, {1, 5, 7, 3}, {2, 3, 7, 6}, {4, 5, 1, 0}
    };
    for (int f = 0; f < 6; f++) {
        Vec3 a = p[F[f][0]], b = p[F[f][1]], c = p[F[f][2]], d = p[F[f][3]];
        Vec3 n = norm3(cross3(d - a, b - a));
        float s = 0.55f + 0.45f * fmaxf(0.0f, dot3(n, L));
        quad(m, a, b, c, d, 0, 0, 1, 1, shadeC(k, s));
    }
}

// Box stretched between two points (arms)
static void beam(Mesh& m, Vec3 a, Vec3 b, float w, Col k, Vec3 L) {
    Vec3 dz = b - a; float l = len3(dz); if (l < 1e-4f) return;
    dz = dz * (1.0f / l);
    Vec3 ref = fabsf(dz.y) < 0.9f ? v3(0, 1, 0) : v3(1, 0, 0);
    Vec3 dx = norm3(cross3(ref, dz));
    Vec3 dy = cross3(dz, dx);
    Mat4 X = mIdent();
    X.m[0] = dx.x; X.m[1] = dx.y; X.m[2] = dx.z;
    X.m[4] = dy.x; X.m[5] = dy.y; X.m[6] = dy.z;
    X.m[8] = dz.x; X.m[9] = dz.y; X.m[10] = dz.z;
    X.m[12] = a.x; X.m[13] = a.y; X.m[14] = a.z;
    xbox(m, X, v3(-w, -w, 0), v3(w, w, l), k, L);
}

static void drawMesh(const Mesh& m) {
    int n = m.count();
    if (n <= 0) return;
    const int CH = 30000; // keep each draw well under 16-bit index limits
    for (int s = 0; s < n; s += CH) {
        int cnt = n - s; if (cnt > CH) cnt = CH;
        glVertexPointer(3, GL_FLOAT, 0, &m.p[s * 3]);
        glTexCoordPointer(2, GL_FLOAT, 0, &m.t[s * 2]);
        glColorPointer(4, GL_FLOAT, 0, &m.c[s * 4]);
        glDrawArrays(GL_TRIANGLES, 0, cnt);
    }
}

// ---------------------------------------------------------------------
//  Textures (procedural)
// ---------------------------------------------------------------------
enum { T_WHITE = 0, T_ASPHALT, T_SIDEWALK, T_FACADE, T_SHOP, T_GRASS, NTEX };
static GLuint g_tex[NTEX];

static GLuint uploadTex(int w, int h, const unsigned char* d, bool mip) {
    GLuint id; glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, d);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    if (mip) {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glGenerateMipmap(GL_TEXTURE_2D);
    } else {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    }
    return id;
}

static inline void px(unsigned char* d, int w, int x, int y, int r, int g, int b) {
    unsigned char* q = d + (y * w + x) * 4;
    q[0] = (unsigned char)clampf((float)r, 0, 255); q[1] = (unsigned char)clampf((float)g, 0, 255);
    q[2] = (unsigned char)clampf((float)b, 0, 255); q[3] = 255;
}

static void makeTextures() {
    static unsigned char buf[128 * 128 * 4];
    // white
    memset(buf, 255, 8 * 8 * 4);
    g_tex[T_WHITE] = uploadTex(8, 8, buf, false);

    // asphalt (one repeat = 5m)
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        float n = hash2(x, y, 1) * 18 + hash2(x / 4, y / 4, 2) * 10;
        int g = (int)(66 + n);
        if (hash2(x, y, 3) > 0.985f) g += 30;
        px(buf, 64, x, y, g, g, g + 3);
    }
    g_tex[T_ASPHALT] = uploadTex(64, 64, buf, true);

    // sidewalk tiles (one repeat = 2m, 1m tiles)
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        int g = (int)(176 + hash2(x, y, 4) * 12 + hash2(x / 8, y / 8, 5) * 8);
        if ((x % 32) < 1 || (y % 32) < 1) g -= 42;
        px(buf, 64, x, y, g, g - 2, g - 6);
    }
    g_tex[T_SIDEWALK] = uploadTex(64, 64, buf, true);

    // facade: one window per repeat (4m x 3.5m), v=0 is the bottom
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        int g = (int)(218 + hash2(x, y, 6) * 14);
        int r = g, gg = g - 3, b = g - 8;
        bool win = x >= 12 && x < 52 && y >= 18 && y < 54;
        bool frame = win && (x < 14 || x >= 50 || y < 20 || y >= 52 || (x >= 31 && x < 33));
        bool sill = x >= 10 && x < 54 && y >= 15 && y < 18;
        if (sill) { r = gg = b = 190; }
        if (win) {
            if (frame) { r = 78; gg = 80; b = 86; }
            else {
                float t = (y - 20) / 32.0f;
                r = (int)(52 + t * 40); gg = (int)(70 + t * 42); b = (int)(92 + t * 46);
                if (((x + y) % 26) < 5) { r += 26; gg += 26; b += 26; }
                if (hash2(x / 6, y / 6, 7) > 0.8f) { r -= 12; gg -= 12; b -= 12; }
            }
        }
        if (y < 2) { r -= 30; gg -= 30; b -= 30; }
        px(buf, 64, x, y, r, gg, b);
    }
    g_tex[T_FACADE] = uploadTex(64, 64, buf, true);

    // shop front (one repeat = 6m wide, ground floor height)
    for (int y = 0; y < 64; y++) for (int x = 0; x < 128; x++) {
        int r, g, b;
        if (y < 5) { r = g = b = 70; }
        else if (y < 46) {
            bool frame = x < 6 || x >= 122 || y < 8 || y >= 43 || (x >= 52 && x < 55) || (x >= 75 && x < 78);
            bool door = x >= 55 && x < 75;
            if (frame) { r = 45; g = 45; b = 50; }
            else {
                float t = (y - 8) / 35.0f;
                r = (int)(34 + t * 30); g = (int)(46 + t * 34); b = (int)(60 + t * 40);
                if (door) { r -= 8; g -= 8; b -= 4; }
                if (((x * 2 + y) % 40) < 6) { r += 22; g += 22; b += 22; }
                if (!door && y < 20 && hash2(x / 10, y / 5, 8) > 0.55f) { r += 25; g += 18; b += 8; } // goods inside
            }
        }
        else if (y < 48) { r = g = b = 60; }
        else if (y < 58) { r = g = b = 236; }      // sign band (tinted per shop)
        else { int q = (int)(205 + hash2(x, y, 9) * 12); r = q; g = q - 3; b = q - 8; }
        px(buf, 128, x, y, r, g, b);
    }
    g_tex[T_SHOP] = uploadTex(128, 64, buf, true);

    // grass
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        float n = hash2(x, y, 10) * 30 + hash2(x / 5, y / 5, 11) * 20;
        px(buf, 64, x, y, (int)(52 + n * 0.6f), (int)(98 + n), (int)(40 + n * 0.3f));
    }
    g_tex[T_GRASS] = uploadTex(64, 64, buf, true);
}

// ---------------------------------------------------------------------
//  World
// ---------------------------------------------------------------------
struct AABB { float mn[3], mx[3]; };
static std::vector<AABB> g_cols;

static void addCol(float x0, float y0, float z0, float x1, float y1, float z1) {
    AABB a; a.mn[0] = x0; a.mn[1] = y0; a.mn[2] = z0; a.mx[0] = x1; a.mx[1] = y1; a.mx[2] = z1;
    g_cols.push_back(a);
}

struct Chunk { Mesh base[NTEX]; };
struct CellProps { Mesh props; };
static Chunk g_chunks[NCHUNK][NCHUNK];
static CellProps g_props[NCELL][NCELL];
static Mesh g_outerGround;

// Road hierarchy: avenues on even grid lines (12m wide), side streets on odd lines (8m wide)
static inline bool isAvenue(int k) { return ((k % 2) + 2) % 2 == 0; }
static inline float rh(int k) { return isAvenue(k) ? ROAD_HALF : 4.0f; }
static inline bool inBlock(float x, float z) {
    int i = (int)floorf(x / CELL), j = (int)floorf(z / CELL);
    float fx = x - i * CELL, fz = z - j * CELL;
    return fx >= rh(i) && fx <= CELL - rh(i + 1) && fz >= rh(j) && fz <= CELL - rh(j + 1);
}
// intersection control
enum { IC_LIGHT = 0, IC_TWOWAY, IC_ALLWAY };
static inline int interCtrl(int ii, int jj) {
    bool a = isAvenue(ii), b = isAvenue(jj);
    return (a && b) ? IC_LIGHT : ((a || b) ? IC_TWOWAY : IC_ALLWAY);
}
// does traffic heading (dx,dz) into intersection (ii,jj) have to stop (stop sign)?
static inline bool approachHasStop(int ii, int jj, int dx) {
    int c = interCtrl(ii, jj);
    if (c == IC_ALLWAY) return true;
    if (c == IC_TWOWAY) return !isAvenue(dx != 0 ? jj : ii);
    return false;
}
static inline float groundHeight(float x, float z) { return inBlock(x, z) ? CURB_H : 0.0f; }

static const Col BUILDING_TINTS[] = {
    {0.95f, 0.90f, 0.80f, 1}, {0.80f, 0.80f, 0.82f, 1}, {0.78f, 0.52f, 0.42f, 1}, {0.88f, 0.78f, 0.62f, 1},
    {0.72f, 0.78f, 0.86f, 1}, {0.98f, 0.97f, 0.95f, 1}, {0.66f, 0.62f, 0.58f, 1}, {0.85f, 0.70f, 0.55f, 1},
    {0.62f, 0.40f, 0.33f, 1}, {0.90f, 0.86f, 0.74f, 1}
};
static const Col SHOP_TINTS[] = {
    {1.0f, 0.70f, 0.65f, 1}, {0.70f, 0.85f, 1.0f, 1}, {0.75f, 1.0f, 0.75f, 1}, {1.0f, 0.95f, 0.65f, 1},
    {0.95f, 0.95f, 0.95f, 1}, {1.0f, 0.80f, 0.55f, 1}, {0.85f, 0.75f, 1.0f, 1}
};
static const Col CAR_COLS[] = {
    {0.75f, 0.10f, 0.10f, 1}, {0.10f, 0.20f, 0.55f, 1}, {0.85f, 0.85f, 0.85f, 1}, {0.12f, 0.12f, 0.13f, 1},
    {0.55f, 0.57f, 0.60f, 1}, {0.95f, 0.75f, 0.10f, 1}, {0.15f, 0.40f, 0.20f, 1}, {0.40f, 0.10f, 0.35f, 1}
};
#define PICK(arr) arr[xrand() % (sizeof(arr) / sizeof(arr[0]))]

static void addBuilding(Chunk& C, float x0, float z0, float x1, float z1, float H, const Col* forcedShop = 0) {
    Col tint = PICK(BUILDING_TINTS);
    Col shop = PICK(SHOP_TINTS);
    if (forcedShop) shop = *forcedShop;
    const float GF = CURB_H + 4.0f;
    // ground floor shops
    sideFaces(C.base[T_SHOP], x0, z0, x1, z1, CURB_H, GF, 6.0f, 0, shop);
    // upper floors
    sideFaces(C.base[T_FACADE], x0, z0, x1, z1, GF, H, 4.0f, 3.5f, tint);
    // ledge above shops
    Col ledge = shadeC(tint, 0.75f);
    Mesh& W = C.base[T_WHITE];
    boxSolid(W, x0 - 0.2f, GF, z0 - 0.2f, x1 + 0.2f, GF + 0.35f, z1 + 0.2f, ledge);
    // roof + parapet
    Col roof = col4(0.45f, 0.44f, 0.43f);
    topQuad(W, x0, z0, x1, z1, H, 0, roof);
    float pt = 0.3f, ph = 0.7f;
    sideFaces(W, x0, z0, x1, z1, H, H + ph, 0, 0, ledge);                         // parapet outside
    sideFaces(W, x0 + pt, z0 + pt, x1 - pt, z1 - pt, H, H + ph, 0, 0, shadeC(ledge, 0.8f)); // inside
    // rooftop unit
    if (frand() < 0.7f) {
        float cx = frange(x0 + 2.5f, x1 - 2.5f), cz = frange(z0 + 2.5f, z1 - 2.5f);
        float s = frange(1.0f, 2.2f);
        boxSolid(W, cx - s, H, cz - s, cx + s, H + frange(1.2f, 2.6f), cz + s, col4(0.6f, 0.6f, 0.62f));
    }
    addCol(x0, 0, z0, x1, H + ph, z1);
}

static void addTree(Mesh& M, float x, float z, float y) {
    float h = frange(2.6f, 3.4f);
    Col trunk = col4(0.38f, 0.27f, 0.18f);
    Col leaf = col4(frange(0.18f, 0.28f), frange(0.42f, 0.55f), frange(0.15f, 0.22f));
    boxSolid(M, x - 0.14f, y, z - 0.14f, x + 0.14f, y + h, z + 0.14f, trunk);
    float r = frange(1.3f, 1.8f);
    boxSolid(M, x - r, y + h - 0.4f, z - r, x + r, y + h + 1.6f, z + r, leaf);
    float r2 = r * 0.65f;
    boxSolid(M, x - r2, y + h + 1.6f, z - r2, x + r2, y + h + 2.6f, z + r2, shadeC(leaf, 1.08f));
    addCol(x - 0.14f, y, z - 0.14f, x + 0.14f, y + h, z + 0.14f);
    addCol(x - r, y + h - 0.4f, z - r, x + r, y + h + 2.6f, z + r);
}

static void addStreetLight(Mesh& M, float x, float z, float dirx, float dirz) {
    Col pole = col4(0.25f, 0.27f, 0.28f);
    float y = CURB_H;
    boxSolid(M, x - 0.08f, y, z - 0.08f, x + 0.08f, y + 6.2f, z + 0.08f, pole);
    float ax = x + dirx * 1.6f, az = z + dirz * 1.6f;
    float mnx = fminf(x, ax) - 0.06f, mxx = fmaxf(x, ax) + 0.06f;
    float mnz = fminf(z, az) - 0.06f, mxz = fmaxf(z, az) + 0.06f;
    boxSolid(M, mnx, y + 6.0f, mnz, mxx, y + 6.12f, mxz, pole);
    boxSolid(M, ax - 0.25f, y + 5.8f, az - 0.25f, ax + 0.25f, y + 6.0f, az + 0.25f, col4(0.95f, 0.93f, 0.80f));
    addCol(x - 0.08f, y, z - 0.08f, x + 0.08f, y + 6.2f, z + 0.08f);
}

static void addCar(Mesh& M, float cx, float cz, bool alongX) {
    Col body = PICK(CAR_COLS);
    Col glass = col4(0.12f, 0.16f, 0.20f);
    Col tire = col4(0.07f, 0.07f, 0.07f);
    float hl = frange(2.0f, 2.3f), hw = 0.9f;
    // local helper: (a = along, c = across)
    #define CBOX(a0, y0, c0, a1, y1, c1, K) do { \
        if (alongX) boxSolid(M, cx + (a0), (y0), cz + (c0), cx + (a1), (y1), cz + (c1), K); \
        else        boxSolid(M, cx + (c0), (y0), cz + (a0), cx + (c1), (y1), cz + (a1), K); } while (0)
    CBOX(-hl, 0.32f, -hw, hl, 0.95f, hw, body);
    CBOX(-hl * 0.55f, 0.95f, -hw * 0.88f, hl * 0.4f, 1.42f, hw * 0.88f, glass);
    CBOX(-hl * 0.5f, 1.42f, -hw * 0.84f, hl * 0.35f, 1.50f, hw * 0.84f, body);
    for (int i = 0; i < 4; i++) {
        float a = (i & 1) ? hl * 0.65f : -hl * 0.65f;
        float c = (i & 2) ? hw * 0.75f : -hw * 0.95f;
        CBOX(a - 0.33f, 0.0f, c, a + 0.33f, 0.62f, c + 0.2f, tire);
    }
    CBOX(hl - 0.02f, 0.62f, -hw * 0.8f, hl + 0.03f, 0.80f, -hw * 0.4f, col4(1, 1, 0.9f));
    CBOX(hl - 0.02f, 0.62f, hw * 0.4f, hl + 0.03f, 0.80f, hw * 0.8f, col4(1, 1, 0.9f));
    CBOX(-hl - 0.03f, 0.62f, -hw * 0.8f, -hl + 0.02f, 0.78f, -hw * 0.45f, col4(0.8f, 0.05f, 0.05f));
    CBOX(-hl - 0.03f, 0.62f, hw * 0.45f, -hl + 0.02f, 0.78f, hw * 0.8f, col4(0.8f, 0.05f, 0.05f));
    #undef CBOX
    if (alongX) addCol(cx - hl, 0, cz - hw, cx + hl, 1.5f, cz + hw);
    else        addCol(cx - hw, 0, cz - hl, cx + hw, 1.5f, cz + hl);
}

// ---- story locations -------------------------------------------------
enum { CT_BUILDING = 0, CT_PARK, CT_HOME, CT_STORE, CT_HOME2, CT_CAFE };
static int g_cellType[NCELL][NCELL];
static const int HOME_I = 4, HOME_J = 4;      // block x 166..194, z 166..194
static const int STORE_I = 2, STORE_J = 6;    // block x 86..114,  z 246..274
static const int HOME2_I = 5, HOME2_J = 4;    // Rosa's house
static const int CAFE_I = 6, CAFE_J = 4;      // cafe: block x 246..276, z 166..196
static const float MGR_X = 258.8f, MGR_Z = 176.4f;          // cafe manager, behind the counter
static const float MACHINE_X = 263.9f, MACHINE_Z = 173.6f;  // where you stand to use the espresso machine
static const float ROSA_X = 222.4f, ROSA_Z = 172.5f;
// Rosa's living room (paintable)
static const float RM_X0 = 212.25f, RM_X1 = 227.75f, RM_Z0 = 176.25f, RM_Z1 = 187.75f;
static const float RM_CEIL = 3.2f, PAINT_CS = 0.5f;
static const float RDOOR_X0 = 218.75f, RDOOR_X1 = 221.25f, RDOOR_Y = CURB_H + 2.0f;
static const float WALT_X = 180.0f, WALT_Z = 171.0f;
static const float CLERK_X = 100.0f, CLERK_Z = 255.3f;   // behind the counter inside
static const float BENCH_X = 105.25f, BENCH_Z = 251.65f; // gun bench, right wall inside
static const float STORE_DOOR_X = 100.0f, STORE_DOOR_Z = 248.2f;
static const float SPAWN_X = 180.0f, SPAWN_Z = 168.5f;

// lawn grid (front yard of the home block)
static const float LAWN_X0 = 169.5f, LAWN_Z0 = 169.0f, LAWN_CS = 0.5f;
static const int LAWN_W = 42, LAWN_H = 23;

static void textWorld(Mesh& m, Vec3 origin, Vec3 right, Vec3 down, float s, const char* str, Col c);

static void genHomeBlock(Chunk& C, Mesh& P, float lx0, float lz0, float lx1, float lz1) {
    const Col WHITE = col4(1, 1, 1);
    Mesh& W = C.base[T_WHITE];
    // lot grass (the mowable lawn is drawn on top of it separately)
    topQuad(C.base[T_GRASS], lx0, lz0, lx1, lz1, CURB_H + 0.01f, 0.3f, WHITE);
    // front path from sidewalk to the door
    topQuad(C.base[T_SIDEWALK], 179.0f, lz0, 181.0f, 182.0f, CURB_H + 0.035f, 0.5f, WHITE);
    // house: two floors with windows, gable roof
    Col wall = col4(0.80f, 0.88f, 0.95f);
    sideFaces(C.base[T_FACADE], 172.0f, 182.0f, 188.0f, 190.0f, CURB_H, 7.15f, 4.0f, 3.5f, wall);
    Col roof = col4(0.45f, 0.20f, 0.16f);
    quad(W, v3(171.6f, 7.15f, 181.6f), v3(188.4f, 7.15f, 181.6f), v3(188.4f, 9.6f, 186.0f), v3(171.6f, 9.6f, 186.0f), 0, 0, 1, 1, shadeC(roof, 0.85f));
    quad(W, v3(188.4f, 7.15f, 190.4f), v3(171.6f, 7.15f, 190.4f), v3(171.6f, 9.6f, 186.0f), v3(188.4f, 9.6f, 186.0f), 0, 0, 1, 1, shadeC(roof, 1.0f));
    quad(W, v3(172.0f, 7.15f, 182.0f), v3(172.0f, 7.15f, 190.0f), v3(172.0f, 9.5f, 186.0f), v3(172.0f, 9.5f, 186.0f), 0, 0, 1, 1, shadeC(wall, 0.70f));
    quad(W, v3(188.0f, 7.15f, 182.0f), v3(188.0f, 7.15f, 190.0f), v3(188.0f, 9.5f, 186.0f), v3(188.0f, 9.5f, 186.0f), 0, 0, 1, 1, shadeC(wall, 0.92f));
    boxSolid(W, 184.5f, 8.0f, 187.0f, 185.6f, 10.6f, 188.1f, col4(0.55f, 0.35f, 0.28f));     // chimney
    boxSolid(W, 179.2f, CURB_H, 181.88f, 180.8f, 2.45f, 182.0f, col4(0.42f, 0.26f, 0.16f)); // door
    boxSolid(W, 178.4f, CURB_H, 181.0f, 181.6f, 0.35f, 182.0f, col4(0.70f, 0.70f, 0.68f));  // step
    addCol(172.0f, 0, 182.0f, 188.0f, 9.6f, 190.0f);
    // side hedges framing the front yard
    Col hedge = col4(0.20f, 0.42f, 0.18f);
    boxSolid(P, 168.6f, CURB_H, 169.0f, 169.4f, 1.1f, 181.5f, hedge);
    boxSolid(P, 190.6f, CURB_H, 169.0f, 191.4f, 1.1f, 181.5f, hedge);
    addCol(168.6f, 0, 169.0f, 169.4f, 1.1f, 181.5f);
    addCol(190.6f, 0, 169.0f, 191.4f, 1.1f, 181.5f);
    // mailbox
    boxSolid(P, 182.4f, CURB_H, 168.8f, 182.5f, 1.0f, 168.9f, col4(0.3f, 0.3f, 0.3f));
    boxSolid(P, 182.2f, 1.0f, 168.6f, 182.7f, 1.3f, 169.1f, col4(0.15f, 0.25f, 0.55f));
}

static void genPaintHouse(Chunk& C, Mesh& P, float lx0, float lz0, float lx1, float lz1) {
    const Col WHITE = col4(1, 1, 1);
    Mesh& W = C.base[T_WHITE];
    const float X0 = 212.0f, X1 = 228.0f, Z0 = 176.0f, Z1 = 188.0f, EAVE = 3.45f;
    topQuad(C.base[T_GRASS], lx0, lz0, lx1, lz1, CURB_H + 0.01f, 0.3f, WHITE);
    topQuad(C.base[T_SIDEWALK], 219.0f, lz0, 221.0f, Z0, CURB_H + 0.035f, 0.5f, WHITE);
    // exterior siding (front split around the door)
    Col sid = col4(0.93f, 0.86f, 0.72f);
    quad(W, v3(X0, CURB_H, Z0), v3(RDOOR_X0, CURB_H, Z0), v3(RDOOR_X0, EAVE, Z0), v3(X0, EAVE, Z0), 0, 0, 1, 1, shadeC(sid, 0.62f));
    quad(W, v3(RDOOR_X1, CURB_H, Z0), v3(X1, CURB_H, Z0), v3(X1, EAVE, Z0), v3(RDOOR_X1, EAVE, Z0), 0, 0, 1, 1, shadeC(sid, 0.62f));
    quad(W, v3(RDOOR_X0, RDOOR_Y, Z0), v3(RDOOR_X1, RDOOR_Y, Z0), v3(RDOOR_X1, EAVE, Z0), v3(RDOOR_X0, EAVE, Z0), 0, 0, 1, 1, shadeC(sid, 0.62f));
    quad(W, v3(X1, CURB_H, Z1), v3(X0, CURB_H, Z1), v3(X0, EAVE, Z1), v3(X1, EAVE, Z1), 0, 0, 1, 1, shadeC(sid, 0.82f));
    quad(W, v3(X0, CURB_H, Z1), v3(X0, CURB_H, Z0), v3(X0, EAVE, Z0), v3(X0, EAVE, Z1), 0, 0, 1, 1, shadeC(sid, 0.70f));
    quad(W, v3(X1, CURB_H, Z0), v3(X1, CURB_H, Z1), v3(X1, EAVE, Z1), v3(X1, EAVE, Z0), 0, 0, 1, 1, shadeC(sid, 0.92f));
    // door frame (thickness of the wall)
    Col fr = col4(0.95f, 0.95f, 0.93f);
    boxSolid(W, RDOOR_X0 - 0.1f, CURB_H, Z0 - 0.03f, RDOOR_X0, RDOOR_Y, RM_Z0, fr);
    boxSolid(W, RDOOR_X1, CURB_H, Z0 - 0.03f, RDOOR_X1 + 0.1f, RDOOR_Y, RM_Z0, fr);
    boxSolid(W, RDOOR_X0 - 0.1f, RDOOR_Y, Z0 - 0.03f, RDOOR_X1 + 0.1f, RDOOR_Y + 0.1f, RM_Z0, fr);
    // fake windows on the outside
    Col glass = col4(0.25f, 0.35f, 0.45f);
    for (int k = 0; k < 2; k++) {
        float wx = k == 0 ? 214.0f : 223.5f;
        boxSolid(W, wx - 0.08f, 1.02f, Z0 - 0.06f, wx + 2.58f, 2.48f, Z0, fr);
        boxSolid(W, wx, 1.1f, Z0 - 0.07f, wx + 2.5f, 2.4f, Z0 - 0.06f, glass);
    }
    // gable roof
    Col roof = col4(0.30f, 0.32f, 0.38f);
    quad(W, v3(X0 - 0.4f, EAVE, Z0 - 0.4f), v3(X1 + 0.4f, EAVE, Z0 - 0.4f), v3(X1 + 0.4f, 5.6f, 182.0f), v3(X0 - 0.4f, 5.6f, 182.0f), 0, 0, 1, 1, shadeC(roof, 0.85f));
    quad(W, v3(X1 + 0.4f, EAVE, Z1 + 0.4f), v3(X0 - 0.4f, EAVE, Z1 + 0.4f), v3(X0 - 0.4f, 5.6f, 182.0f), v3(X1 + 0.4f, 5.6f, 182.0f), 0, 0, 1, 1, roof);
    quad(W, v3(X0, EAVE, Z0), v3(X0, EAVE, Z1), v3(X0, 5.5f, 182.0f), v3(X0, 5.5f, 182.0f), 0, 0, 1, 1, shadeC(sid, 0.70f));
    quad(W, v3(X1, EAVE, Z0), v3(X1, EAVE, Z1), v3(X1, 5.5f, 182.0f), v3(X1, 5.5f, 182.0f), 0, 0, 1, 1, shadeC(sid, 0.92f));
    // interior: wood floor, ceiling, trim (walls themselves are the paint mesh)
    Col floorC = col4(0.55f, 0.40f, 0.26f);
    topQuad(W, RM_X0, RM_Z0, RM_X1, RM_Z1, CURB_H + 0.012f, 0, floorC);
    for (float x = RM_X0 + 0.5f; x < RM_X1 - 0.1f; x += 0.5f)
        topQuad(W, x - 0.015f, RM_Z0, x + 0.015f, RM_Z1, CURB_H + 0.016f, 0, shadeC(floorC, 0.75f));
    topQuad(W, RM_X0, RM_Z0, RM_X1, RM_Z1, RM_CEIL, 0, col4(0.92f, 0.92f, 0.90f));
    float ty = CURB_H + 3.0f;
    Col trim = col4(0.96f, 0.96f, 0.94f);
    quad(W, v3(RM_X0, ty, RM_Z0 + 0.004f), v3(RM_X1, ty, RM_Z0 + 0.004f), v3(RM_X1, RM_CEIL, RM_Z0 + 0.004f), v3(RM_X0, RM_CEIL, RM_Z0 + 0.004f), 0, 0, 1, 1, trim);
    quad(W, v3(RM_X0, ty, RM_Z1 - 0.004f), v3(RM_X1, ty, RM_Z1 - 0.004f), v3(RM_X1, RM_CEIL, RM_Z1 - 0.004f), v3(RM_X0, RM_CEIL, RM_Z1 - 0.004f), 0, 0, 1, 1, trim);
    quad(W, v3(RM_X0 + 0.004f, ty, RM_Z0), v3(RM_X0 + 0.004f, ty, RM_Z1), v3(RM_X0 + 0.004f, RM_CEIL, RM_Z1), v3(RM_X0 + 0.004f, RM_CEIL, RM_Z0), 0, 0, 1, 1, shadeC(trim, 0.9f));
    quad(W, v3(RM_X1 - 0.004f, ty, RM_Z0), v3(RM_X1 - 0.004f, ty, RM_Z1), v3(RM_X1 - 0.004f, RM_CEIL, RM_Z1), v3(RM_X1 - 0.004f, RM_CEIL, RM_Z0), 0, 0, 1, 1, shadeC(trim, 0.9f));
    topQuad(W, 218.5f, 181.0f, 219.5f, 182.0f, RM_CEIL - 0.02f, 0, col4(1, 1, 0.95f)); // ceiling light
    // drop cloth, covered couch, paint cans, tray
    topQuad(W, 215.5f, 180.5f, 224.5f, 185.5f, CURB_H + 0.02f, 0, col4(0.78f, 0.78f, 0.76f));
    boxSolid(W, 217.5f, CURB_H, 182.0f, 222.5f, 1.0f, 184.0f, col4(0.90f, 0.90f, 0.88f));
    boxSolid(W, 217.5f, 1.0f, 183.4f, 222.5f, 1.45f, 184.0f, col4(0.86f, 0.86f, 0.84f));
    addCol(217.5f, 0, 182.0f, 222.5f, 1.45f, 184.0f);
    Col can = col4(0.75f, 0.75f, 0.78f);
    boxSolid(W, 213.0f, CURB_H, 177.0f, 213.35f, 0.55f, 177.35f, can);
    boxSolid(W, 213.5f, CURB_H, 177.1f, 213.85f, 0.55f, 177.45f, can);
    boxSolid(W, 213.2f, CURB_H, 177.6f, 213.55f, 0.55f, 177.95f, can);
    boxSolid(W, 214.2f, CURB_H, 177.2f, 214.8f, 0.22f, 177.7f, col4(0.35f, 0.35f, 0.38f));
    // colliders: thin walls with a doorway
    addCol(X0, 0, Z0, RDOOR_X0, EAVE, RM_Z0);
    addCol(RDOOR_X1, 0, Z0, X1, EAVE, RM_Z0);
    addCol(RDOOR_X0, RDOOR_Y, Z0, RDOOR_X1, EAVE, RM_Z0);
    addCol(X0, 0, RM_Z1, X1, EAVE, Z1);
    addCol(X0, 0, Z0, RM_X0, EAVE, Z1);
    addCol(RM_X1, 0, Z0, X1, EAVE, Z1);
    addCol(X0 - 0.4f, EAVE, Z0 - 0.4f, X1 + 0.4f, 5.6f, Z1 + 0.4f);
    (void)P;
}

static void genCafe(Chunk& C, float lx0, float lz0, float lx1, float lz1) {
    const float H = 10.5f, GF = CURB_H + 4.0f;
    const float DX0 = 259.5f, DX1 = 262.5f, DY = 2.7f;
    const float RX0 = 255.0f, RX1 = 267.0f, RZ1 = 178.0f, CY = 4.0f;
    const float IZ = lz0 + 0.25f;
    Col tint = col4(0.85f, 0.78f, 0.62f), shop = col4(0.75f, 0.62f, 0.45f);
    Mesh& W = C.base[T_WHITE];
    Mesh& S = C.base[T_SHOP];
    // exterior ground floor with doorway
    quad(S, v3(lx0, CURB_H, lz1), v3(lx0, CURB_H, lz0), v3(lx0, GF, lz0), v3(lx0, GF, lz1), 0, 0, (lz1 - lz0) / 6, 1, shadeC(shop, 0.70f));
    quad(S, v3(lx1, CURB_H, lz0), v3(lx1, CURB_H, lz1), v3(lx1, GF, lz1), v3(lx1, GF, lz0), 0, 0, (lz1 - lz0) / 6, 1, shadeC(shop, 0.92f));
    quad(S, v3(lx1, CURB_H, lz1), v3(lx0, CURB_H, lz1), v3(lx0, GF, lz1), v3(lx1, GF, lz1), 0, 0, (lx1 - lx0) / 6, 1, shadeC(shop, 0.82f));
    Col fs = shadeC(shop, 0.62f);
    quad(S, v3(lx0, CURB_H, lz0), v3(DX0, CURB_H, lz0), v3(DX0, GF, lz0), v3(lx0, GF, lz0), 0, 0, (DX0 - lx0) / 6, 1, fs);
    quad(S, v3(DX1, CURB_H, lz0), v3(lx1, CURB_H, lz0), v3(lx1, GF, lz0), v3(DX1, GF, lz0), 0, 0, (lx1 - DX1) / 6, 1, fs);
    float vb = (DY - CURB_H) / (GF - CURB_H);
    quad(S, v3(DX0, DY, lz0), v3(DX1, DY, lz0), v3(DX1, GF, lz0), v3(DX0, GF, lz0), 0, vb, (DX1 - DX0) / 6, 1, fs);
    sideFaces(C.base[T_FACADE], lx0, lz0, lx1, lz1, GF, H, 4.0f, 3.5f, tint);
    Col ledge = shadeC(tint, 0.75f);
    boxSolid(W, lx0 - 0.2f, GF, lz0 - 0.2f, lx1 + 0.2f, GF + 0.35f, lz1 + 0.2f, ledge);
    topQuad(W, lx0, lz0, lx1, lz1, H, 0, col4(0.45f, 0.44f, 0.43f));
    sideFaces(W, lx0, lz0, lx1, lz1, H, H + 0.7f, 0, 0, ledge);
    sideFaces(W, lx0 + 0.3f, lz0 + 0.3f, lx1 - 0.3f, lz1 - 0.3f, H, H + 0.7f, 0, 0, shadeC(ledge, 0.8f));
    Col frame = col4(0.30f, 0.20f, 0.12f);
    boxSolid(W, DX0 - 0.08f, CURB_H, lz0 - 0.02f, DX0, DY, IZ, frame);
    boxSolid(W, DX1, CURB_H, lz0 - 0.02f, DX1 + 0.08f, DY, IZ, frame);
    boxSolid(W, DX0 - 0.08f, DY, lz0 - 0.02f, DX1 + 0.08f, DY + 0.08f, IZ, frame);
    // striped awning + sign
    for (int k = 0; k < 14; k++) {
        float ax = 254.0f + k * 1.0f;
        boxSolid(W, ax, 2.95f, lz0 - 1.3f, ax + 1.0f, 3.05f, lz0, (k % 2) ? col4(0.95f, 0.93f, 0.88f) : col4(0.15f, 0.45f, 0.30f));
    }
    boxSolid(W, 257.0f, 3.2f, lz0 - 0.22f, 265.0f, 4.05f, lz0, col4(0.15f, 0.40f, 0.28f));
    float ts = 0.13f, tw = (4 * 6 - 1) * ts;
    textWorld(W, v3(261.0f + tw * 0.5f, 3.98f, lz0 - 0.24f), v3(-1, 0, 0), v3(0, -1, 0), ts, "CAFE", col4(1, 0.95f, 0.85f));
    // interior: checker floor, walls, ceiling, pendant lights
    for (float x = RX0; x < RX1 - 0.01f; x += 1.0f)
        for (float z = IZ; z < RZ1 - 0.01f; z += 1.0f) {
            bool dark = ((int)(x - RX0) + (int)(z - IZ)) % 2;
            topQuad(W, x, z, fminf(x + 1.0f, RX1), fminf(z + 1.0f, RZ1), CURB_H + 0.012f, 0, dark ? col4(0.25f, 0.22f, 0.20f) : col4(0.90f, 0.88f, 0.84f));
        }
    topQuad(W, RX0, IZ, RX1, RZ1, CY, 0, col4(0.88f, 0.86f, 0.82f));
    Col wallC = col4(0.93f, 0.86f, 0.72f);
    quad(W, v3(RX0, CURB_H, IZ), v3(RX0, CURB_H, RZ1), v3(RX0, CY, RZ1), v3(RX0, CY, IZ), 0, 0, 1, 1, shadeC(wallC, 0.85f));
    quad(W, v3(RX1, CURB_H, RZ1), v3(RX1, CURB_H, IZ), v3(RX1, CY, IZ), v3(RX1, CY, RZ1), 0, 0, 1, 1, shadeC(wallC, 0.78f));
    quad(W, v3(RX0, CURB_H, RZ1), v3(RX1, CURB_H, RZ1), v3(RX1, CY, RZ1), v3(RX0, CY, RZ1), 0, 0, 1, 1, wallC);
    Col fw = shadeC(wallC, 0.92f);
    quad(W, v3(RX0, CURB_H, IZ), v3(DX0, CURB_H, IZ), v3(DX0, CY, IZ), v3(RX0, CY, IZ), 0, 0, 1, 1, fw);
    quad(W, v3(DX1, CURB_H, IZ), v3(RX1, CURB_H, IZ), v3(RX1, CY, IZ), v3(DX1, CY, IZ), 0, 0, 1, 1, fw);
    quad(W, v3(DX0, DY, IZ), v3(DX1, DY, IZ), v3(DX1, CY, IZ), v3(DX0, CY, IZ), 0, 0, 1, 1, fw);
    for (int k = 0; k < 3; k++) {
        float px = 257.5f + k * 3.5f;
        boxSolid(W, px - 0.02f, 3.3f, 172.98f, px + 0.02f, CY, 173.02f, col4(0.1f, 0.1f, 0.1f));
        boxSolid(W, px - 0.2f, 3.1f, 172.8f, px + 0.2f, 3.3f, 173.2f, col4(0.95f, 0.85f, 0.55f));
    }
    // counter, espresso machine, cups, menu board
    boxSolid(W, 256.0f, CURB_H, 174.3f, 266.0f, 1.0f, 175.1f, col4(0.42f, 0.28f, 0.17f));
    boxSolid(W, 255.9f, 1.0f, 174.2f, 266.1f, 1.06f, 175.2f, col4(0.82f, 0.80f, 0.76f));
    addCol(256.0f, 0, 174.3f, 266.0f, 1.06f, 175.1f);
    Col chrome = col4(0.75f, 0.76f, 0.78f);
    boxSolid(W, 263.2f, 1.06f, 174.4f, 264.6f, 1.55f, 175.05f, chrome);
    boxSolid(W, 263.2f, 1.55f, 174.4f, 264.6f, 1.6f, 175.05f, col4(0.15f, 0.15f, 0.16f));
    boxSolid(W, 263.5f, 1.2f, 174.3f, 263.7f, 1.3f, 174.4f, col4(0.2f, 0.2f, 0.2f));
    boxSolid(W, 264.1f, 1.2f, 174.3f, 264.3f, 1.3f, 174.4f, col4(0.2f, 0.2f, 0.2f));
    for (int k = 0; k < 4; k++) boxSolid(W, 265.0f, 1.06f + k * 0.09f, 174.5f, 265.18f, 1.14f + k * 0.09f, 174.68f, col4(0.97f, 0.97f, 0.95f));
    quad(W, v3(266.0f, 1.9f, RZ1 - 0.03f), v3(256.0f, 1.9f, RZ1 - 0.03f), v3(256.0f, 3.4f, RZ1 - 0.03f), v3(266.0f, 3.4f, RZ1 - 0.03f), 0, 0, 1, 1, col4(0.12f, 0.14f, 0.13f));
    textWorld(W, v3(265.4f, 3.2f, RZ1 - 0.05f), v3(-1, 0, 0), v3(0, -1, 0), 0.06f, "COFFEE   $2", col4(0.95f, 0.95f, 0.9f));
    textWorld(W, v3(265.4f, 2.7f, RZ1 - 0.05f), v3(-1, 0, 0), v3(0, -1, 0), 0.06f, "LATTE    $3", col4(0.95f, 0.95f, 0.9f));
    textWorld(W, v3(265.4f, 2.2f, RZ1 - 0.05f), v3(-1, 0, 0), v3(0, -1, 0), 0.06f, "MOCHA    $3", col4(0.95f, 0.95f, 0.9f));
    // two cafe tables with stools
    for (int t = 0; t < 2; t++) {
        float tx = t == 0 ? 256.9f : 265.1f, tz = 171.2f;
        boxSolid(W, tx - 0.04f, CURB_H, tz - 0.04f, tx + 0.04f, 0.85f, tz + 0.04f, col4(0.15f, 0.15f, 0.15f));
        boxSolid(W, tx - 0.4f, 0.85f, tz - 0.4f, tx + 0.4f, 0.9f, tz + 0.4f, col4(0.55f, 0.38f, 0.22f));
        boxSolid(W, tx - 0.18f, CURB_H, tz + 0.65f, tx + 0.18f, 0.6f, tz + 1.0f, col4(0.25f, 0.35f, 0.30f));
        addCol(tx - 0.4f, 0, tz - 0.4f, tx + 0.4f, 0.9f, tz + 0.4f);
    }
    // colliders
    addCol(lx0, 0, lz0, RX0, H + 0.7f, lz1);
    addCol(RX1, 0, lz0, lx1, H + 0.7f, lz1);
    addCol(RX0, 0, RZ1, RX1, H + 0.7f, lz1);
    addCol(RX0, 0, lz0, DX0, CY + 0.2f, IZ);
    addCol(DX1, 0, lz0, RX1, CY + 0.2f, IZ);
    addCol(DX0, DY, lz0, DX1, CY + 0.2f, IZ);
    addCol(RX0, CY, lz0, RX1, H + 0.7f, RZ1);
}

static void genGunStore(Chunk& C, float lx0, float lz0, float lx1, float lz1) {
    const float H = 15.0f, GF = CURB_H + 4.0f;
    const float DX0 = 98.5f, DX1 = 101.5f, DY = 2.7f;          // door opening
    const float RX0 = 94.0f, RX1 = 106.0f, RZ1 = 257.0f, CY = 4.0f; // interior room
    const float IZ = lz0 + 0.25f;                                // inner face of the front wall
    Col tint = col4(0.66f, 0.42f, 0.34f), shop = col4(0.55f, 0.52f, 0.50f);
    Mesh& W = C.base[T_WHITE];
    Mesh& S = C.base[T_SHOP];

    // ---- exterior ground floor (front split around the door)
    quad(S, v3(lx0, CURB_H, lz1), v3(lx0, CURB_H, lz0), v3(lx0, GF, lz0), v3(lx0, GF, lz1), 0, 0, (lz1 - lz0) / 6, 1, shadeC(shop, 0.70f));
    quad(S, v3(lx1, CURB_H, lz0), v3(lx1, CURB_H, lz1), v3(lx1, GF, lz1), v3(lx1, GF, lz0), 0, 0, (lz1 - lz0) / 6, 1, shadeC(shop, 0.92f));
    quad(S, v3(lx1, CURB_H, lz1), v3(lx0, CURB_H, lz1), v3(lx0, GF, lz1), v3(lx1, GF, lz1), 0, 0, (lx1 - lx0) / 6, 1, shadeC(shop, 0.82f));
    Col fs = shadeC(shop, 0.62f);
    quad(S, v3(lx0, CURB_H, lz0), v3(DX0, CURB_H, lz0), v3(DX0, GF, lz0), v3(lx0, GF, lz0), 0, 0, (DX0 - lx0) / 6, 1, fs);
    quad(S, v3(DX1, CURB_H, lz0), v3(lx1, CURB_H, lz0), v3(lx1, GF, lz0), v3(DX1, GF, lz0), 0, 0, (lx1 - DX1) / 6, 1, fs);
    float vb = (DY - CURB_H) / (GF - CURB_H);
    quad(S, v3(DX0, DY, lz0), v3(DX1, DY, lz0), v3(DX1, GF, lz0), v3(DX0, GF, lz0), 0, vb, (DX1 - DX0) / 6, 1, fs);

    // ---- upper floors, ledge, roof, parapet
    sideFaces(C.base[T_FACADE], lx0, lz0, lx1, lz1, GF, H, 4.0f, 3.5f, tint);
    Col ledge = shadeC(tint, 0.75f);
    boxSolid(W, lx0 - 0.2f, GF, lz0 - 0.2f, lx1 + 0.2f, GF + 0.35f, lz1 + 0.2f, ledge);
    topQuad(W, lx0, lz0, lx1, lz1, H, 0, col4(0.45f, 0.44f, 0.43f));
    sideFaces(W, lx0, lz0, lx1, lz1, H, H + 0.7f, 0, 0, ledge);
    sideFaces(W, lx0 + 0.3f, lz0 + 0.3f, lx1 - 0.3f, lz1 - 0.3f, H, H + 0.7f, 0, 0, shadeC(ledge, 0.8f));

    // ---- door frame
    Col frame = col4(0.22f, 0.22f, 0.24f);
    boxSolid(W, DX0 - 0.08f, CURB_H, lz0 - 0.02f, DX0, DY, IZ, frame);
    boxSolid(W, DX1, CURB_H, lz0 - 0.02f, DX1 + 0.08f, DY, IZ, frame);
    boxSolid(W, DX0 - 0.08f, DY, lz0 - 0.02f, DX1 + 0.08f, DY + 0.08f, IZ, frame);

    // ---- sign over the door
    boxSolid(W, 94.6f, 2.82f, lz0 - 0.25f, 105.4f, 4.08f, lz0, col4(0.60f, 0.08f, 0.06f));
    float ts = 0.16f, tw = (9 * 6 - 1) * ts;
    textWorld(W, v3(100.0f + tw * 0.5f, 4.0f, lz0 - 0.27f), v3(-1, 0, 0), v3(0, -1, 0), ts, "GUN STORE", col4(1, 1, 1));

    // ---- interior room
    Col wallC = col4(0.80f, 0.76f, 0.68f), floorC = col4(0.50f, 0.38f, 0.27f);
    topQuad(W, RX0, IZ, RX1, RZ1, CURB_H + 0.012f, 0, floorC);
    for (float x = RX0 + 0.6f; x < RX1 - 0.1f; x += 0.6f)
        topQuad(W, x - 0.02f, IZ, x + 0.02f, RZ1, CURB_H + 0.016f, 0, shadeC(floorC, 0.72f));
    topQuad(W, RX0, IZ, RX1, RZ1, CY, 0, col4(0.86f, 0.86f, 0.84f));
    quad(W, v3(RX0, CURB_H, IZ), v3(RX0, CURB_H, RZ1), v3(RX0, CY, RZ1), v3(RX0, CY, IZ), 0, 0, 1, 1, shadeC(wallC, 0.85f));
    quad(W, v3(RX1, CURB_H, RZ1), v3(RX1, CURB_H, IZ), v3(RX1, CY, IZ), v3(RX1, CY, RZ1), 0, 0, 1, 1, shadeC(wallC, 0.78f));
    quad(W, v3(RX0, CURB_H, RZ1), v3(RX1, CURB_H, RZ1), v3(RX1, CY, RZ1), v3(RX0, CY, RZ1), 0, 0, 1, 1, wallC);
    Col fw = shadeC(wallC, 0.92f);
    quad(W, v3(RX0, CURB_H, IZ), v3(DX0, CURB_H, IZ), v3(DX0, CY, IZ), v3(RX0, CY, IZ), 0, 0, 1, 1, fw);
    quad(W, v3(DX1, CURB_H, IZ), v3(RX1, CURB_H, IZ), v3(RX1, CY, IZ), v3(DX1, CY, IZ), 0, 0, 1, 1, fw);
    quad(W, v3(DX0, DY, IZ), v3(DX1, DY, IZ), v3(DX1, CY, IZ), v3(DX0, CY, IZ), 0, 0, 1, 1, fw);
    for (int k = 0; k < 3; k++) { // ceiling light panels
        float cx = 96.5f + k * 3.5f;
        topQuad(W, cx - 0.6f, 252.5f, cx + 0.6f, 253.2f, CY - 0.02f, 0, col4(1, 1, 0.95f));
    }

    // counter + register
    boxSolid(W, 96.0f, CURB_H, 253.6f, 104.0f, 1.0f, 254.4f, col4(0.36f, 0.24f, 0.15f));
    boxSolid(W, 95.9f, 1.0f, 253.5f, 104.1f, 1.06f, 254.5f, col4(0.20f, 0.20f, 0.22f));
    boxSolid(W, 101.6f, 1.06f, 253.8f, 102.2f, 1.3f, 254.2f, col4(0.15f, 0.15f, 0.16f));
    addCol(96.0f, 0, 253.6f, 104.0f, 1.06f, 254.4f);

    // back wall: pegboard with rifles
    quad(W, v3(95.0f, 1.3f, RZ1 - 0.03f), v3(105.0f, 1.3f, RZ1 - 0.03f), v3(105.0f, 3.6f, RZ1 - 0.03f), v3(95.0f, 3.6f, RZ1 - 0.03f), 0, 0, 1, 1, col4(0.55f, 0.45f, 0.33f));
    for (int r = 0; r < 3; r++)
        for (int c = 0; c < 3; c++) {
            float gx = 95.6f + c * 3.2f, gy = 1.7f + r * 0.7f, z = RZ1 - 0.08f;
            boxSolid(W, gx, gy, z - 0.04f, gx + 2.2f, gy + 0.09f, z, col4(0.10f, 0.10f, 0.11f));
            boxSolid(W, gx + 1.3f, gy - 0.18f, z - 0.04f, gx + 1.42f, gy, z, col4(0.10f, 0.10f, 0.11f));
            boxSolid(W, gx + 1.7f, gy - 0.06f, z - 0.04f, gx + 2.2f, gy + 0.12f, z, col4(0.25f, 0.22f, 0.18f));
        }

    // display case (left wall)
    boxSolid(W, 94.0f, CURB_H, 250.5f, 94.9f, 1.0f, 253.0f, col4(0.30f, 0.30f, 0.32f));
    topQuad(W, 94.0f, 250.5f, 94.9f, 253.0f, 1.01f, 0, col4(0.55f, 0.65f, 0.70f));
    addCol(94.0f, 0, 250.5f, 94.9f, 1.0f, 253.0f);

    // gun bench (right wall)
    Col wood = col4(0.52f, 0.36f, 0.20f), leg = shadeC(wood, 0.7f);
    boxSolid(W, 104.6f, 0.85f, 250.3f, 105.95f, 0.95f, 253.0f, wood);
    boxSolid(W, 104.65f, CURB_H, 250.35f, 104.75f, 0.85f, 250.45f, leg);
    boxSolid(W, 104.65f, CURB_H, 252.85f, 104.75f, 0.85f, 252.95f, leg);
    boxSolid(W, 105.8f, CURB_H, 250.35f, 105.9f, 0.85f, 250.45f, leg);
    boxSolid(W, 105.8f, CURB_H, 252.85f, 105.9f, 0.85f, 252.95f, leg);
    boxSolid(W, 104.7f, 0.95f, 250.45f, 105.0f, 1.12f, 250.8f, col4(0.25f, 0.35f, 0.55f));   // vise
    boxSolid(W, 104.98f, 0.95f, 250.95f, 105.14f, 1.02f, 252.7f, col4(0.10f, 0.10f, 0.11f)); // rifle on bench
    boxSolid(W, 104.99f, 0.95f, 252.2f, 105.13f, 1.06f, 252.75f, col4(0.25f, 0.22f, 0.18f));
    quad(W, v3(RX1 - 0.03f, 1.2f, 250.3f), v3(RX1 - 0.03f, 1.2f, 253.0f), v3(RX1 - 0.03f, 2.6f, 253.0f), v3(RX1 - 0.03f, 2.6f, 250.3f), 0, 0, 1, 1, col4(0.62f, 0.52f, 0.38f));
    for (int k = 0; k < 5; k++) {
        float tz = 250.6f + k * 0.48f, ty = 1.6f + (k % 2) * 0.3f;
        boxSolid(W, RX1 - 0.09f, ty, tz, RX1 - 0.03f, ty + 0.4f, tz + 0.12f, col4(0.6f, 0.15f + 0.1f * k, 0.1f));
    }
    textWorld(W, v3(RX1 - 0.04f, 2.95f, 250.45f), v3(0, 0, 1), v3(0, -1, 0), 0.045f, "GUN BENCH", col4(0.95f, 0.85f, 0.3f));
    addCol(104.6f, 0, 250.3f, 105.95f, 0.95f, 253.0f);

    // ---- colliders: everything around the room is solid
    addCol(lx0, 0, lz0, RX0, H + 0.7f, lz1);
    addCol(RX1, 0, lz0, lx1, H + 0.7f, lz1);
    addCol(RX0, 0, RZ1, RX1, H + 0.7f, lz1);
    addCol(RX0, 0, lz0, DX0, CY + 0.2f, IZ);
    addCol(DX1, 0, lz0, RX1, CY + 0.2f, IZ);
    addCol(DX0, DY, lz0, DX1, CY + 0.2f, IZ);
    addCol(RX0, CY, lz0, RX1, H + 0.7f, RZ1);
}

// octagonal STOP sign plate facing drivers heading (hx,hz)
static void addStopSign(Mesh& M, float px, float pz, int hx, int hz) {
    Vec3 u = v3((float)-hz, 0, (float)hx);          // driver's right
    Vec3 n = v3((float)-hx, 0, (float)-hz);         // faces the driver
    Vec3 c = v3(px, CURB_H + 2.25f, pz) + n * 0.12f - u * 0.15f;
    Vec3 up = v3(0, 1, 0);
    for (int ring = 0; ring < 2; ring++) {
        float rad = ring == 0 ? 0.40f : 0.36f;
        Vec3 cc = c + n * (ring == 0 ? 0.0f : 0.01f);
        Col k = ring == 0 ? col4(0.95f, 0.95f, 0.95f) : col4(0.78f, 0.06f, 0.05f);
        for (int s2 = 0; s2 < 8; s2++) {
            float a0 = (22.5f + s2 * 45.0f) * PI_F / 180.0f, a1 = (22.5f + (s2 + 1) * 45.0f) * PI_F / 180.0f;
            Vec3 p0 = cc + u * (cosf(a0) * rad) + up * (sinf(a0) * rad);
            Vec3 p1 = cc + u * (cosf(a1) * rad) + up * (sinf(a1) * rad);
            quad(M, cc, p0, p1, p1, 0, 0, 1, 1, k);
        }
    }
    float ts = 0.02f, tw = (4 * 6 - 1) * ts;
    textWorld(M, c + n * 0.02f - u * (tw * 0.5f) + up * 0.07f, u, v3(0, -1, 0), ts, "STOP", col4(1, 1, 1));
}

static void addMarkings(Mesh& M, int i, int j) {
    const float y = 0.02f;
    const float X = i * CELL, Z = j * CELL;
    const float hx = rh(i), hz = rh(j);             // half widths of the vertical / horizontal road
    Col yel = col4(0.92f, 0.78f, 0.20f), wht = col4(0.92f, 0.92f, 0.90f);
    // center dashes along the vertical road (x = X) and the horizontal road (z = Z)
    for (float s2 = hz + 4.4f; s2 < CELL - rh(j + 1) - 4.4f - 1.9f; s2 += 4.0f)
        topQuad(M, X - 0.08f, Z + s2, X + 0.08f, Z + s2 + 2.0f, y, 0, yel);
    for (float s2 = hx + 4.4f; s2 < CELL - rh(i + 1) - 4.4f - 1.9f; s2 += 4.0f)
        topQuad(M, X + s2, Z - 0.08f, X + s2 + 2.0f, Z + 0.08f, y, 0, yel);
    if (i < 0 || i > 8 || j < 0 || j > 8) return;
    // crosswalks just outside the intersection box
    int nx = (int)hx, nz = (int)hz;
    for (int k = 0; k < nx; k++) {
        float o = -hx + 0.5f + k * 2.0f;
        topQuad(M, X + o, Z + hz, X + o + 1.0f, Z + hz + 3.0f, y, 0, wht);
        topQuad(M, X + o, Z - hz - 3.0f, X + o + 1.0f, Z - hz, y, 0, wht);
    }
    for (int k = 0; k < nz; k++) {
        float o = -hz + 0.5f + k * 2.0f;
        topQuad(M, X + hx, Z + o, X + hx + 3.0f, Z + o + 1.0f, y, 0, wht);
        topQuad(M, X - hx - 3.0f, Z + o, X - hx, Z + o + 1.0f, y, 0, wht);
    }
    // stop lines (+ stop signs) on controlled approaches
    const int hd[4][2] = {{0, -1}, {0, 1}, {1, 0}, {-1, 0}};
    for (int a2 = 0; a2 < 4; a2++) {
        int dx = hd[a2][0], dz = hd[a2][1];
        bool lightI = interCtrl(i, j) == IC_LIGHT, stop = approachHasStop(i, j, dx);
        if (!lightI && !stop) continue;
        if (dz == -1) topQuad(M, X, Z + hz + 3.6f, X + hx, Z + hz + 4.0f, y, 0, wht);
        if (dz == 1)  topQuad(M, X - hx, Z - hz - 4.0f, X, Z - hz - 3.6f, y, 0, wht);
        if (dx == 1)  topQuad(M, X - hx - 4.0f, Z, X - hx - 3.6f, Z + hz, y, 0, wht);
        if (dx == -1) topQuad(M, X + hx + 3.6f, Z - hz, X + hx + 4.0f, Z, y, 0, wht);
        if (stop) {
            float own = dx != 0 ? hz : hx, cross = dx != 0 ? hx : hz;
            int rx = -dz, rz = dx;
            float px = X - dx * (cross + 0.4f) + rx * (own + 0.4f);
            float pz = Z - dz * (cross + 0.4f) + rz * (own + 0.4f);
            addStopSign(M, px, pz, dx, dz);
        }
    }
}

// alley between two buildings: dumpsters, bags, fire escapes
static void addAlley(Chunk& C, Mesh& P, bool alongZ, float m0, float m1, float a0, float a1) {
    Mesh& W = C.base[T_WHITE];
    if (alongZ) topQuad(C.base[T_SIDEWALK], m0, a0, m1, a1, CURB_H + 0.012f, 0.5f, col4(0.55f, 0.53f, 0.50f));
    else        topQuad(C.base[T_SIDEWALK], a0, m0, a1, m1, CURB_H + 0.012f, 0.5f, col4(0.55f, 0.53f, 0.50f));
    int nd = 1 + (int)(xrand() % 2);
    for (int k = 0; k < nd; k++) {
        float t = frange(a0 + 6.0f, a1 - 7.0f);
        Col dc = k == 0 ? col4(0.18f, 0.38f, 0.22f) : col4(0.20f, 0.28f, 0.45f);
        float side = (k % 2 == 0) ? m0 + 0.1f : m1 - 1.3f;
        if (alongZ) { boxSolid(P, side, CURB_H, t, side + 1.2f, CURB_H + 1.15f, t + 1.9f, dc); addCol(side, 0, t, side + 1.2f, CURB_H + 1.15f, t + 1.9f); }
        else        { boxSolid(P, t, CURB_H, side, t + 1.9f, CURB_H + 1.15f, side + 1.2f, dc); addCol(t, 0, side, t + 1.9f, CURB_H + 1.15f, side + 1.2f); }
        for (int b2 = 0; b2 < 3; b2++) { // trash bags
            float bt = t + 2.1f + b2 * 0.45f, bs = side + frange(0.1f, 0.6f);
            if (alongZ) boxSolid(P, bs, CURB_H, bt, bs + 0.45f, CURB_H + 0.4f, bt + 0.42f, col4(0.08f, 0.08f, 0.09f));
            else        boxSolid(P, bt, CURB_H, bs, bt + 0.42f, CURB_H + 0.4f, bs + 0.45f, col4(0.08f, 0.08f, 0.09f));
        }
    }
    // fire escape on one alley wall
    float fe0 = frange(a0 + 5.0f, a1 - 9.0f);
    Col iron = col4(0.12f, 0.12f, 0.13f);
    for (int f = 1; f <= 3; f++) {
        float y = CURB_H + 4.2f + (f - 1) * 3.5f;
        if (alongZ) {
            boxSolid(W, m0, y, fe0, m0 + 1.0f, y + 0.08f, fe0 + 3.0f, iron);
            boxSolid(W, m0 + 0.95f, y, fe0, m0 + 1.0f, y + 0.9f, fe0 + 3.0f, iron);
        } else {
            boxSolid(W, fe0, y, m0, fe0 + 3.0f, y + 0.08f, m0 + 1.0f, iron);
            boxSolid(W, fe0, y, m0 + 0.95f, fe0 + 3.0f, y + 0.9f, m0 + 1.0f, iron);
        }
    }
}

static void genWorld() {
    g_rng = 0xC17C17u;
    g_cols.clear();
    const Col WHITE = col4(1, 1, 1);
    topQuad(g_outerGround, -300, -300, 620, 620, -0.05f, 0.2f, col4(0.85f, 0.85f, 0.85f));

    for (int i = CELL_MIN; i < CELL_MIN + NCELL; i++)
    for (int j = CELL_MIN; j < CELL_MIN + NCELL; j++) {
        Chunk& C = g_chunks[(i - CELL_MIN) / 2][(j - CELL_MIN) / 2];
        Mesh& P = g_props[i - CELL_MIN][j - CELL_MIN].props;
        float x0 = i * CELL, z0 = j * CELL;
        float bx0 = x0 + rh(i), bx1 = x0 + CELL - rh(i + 1);
        float bz0 = z0 + rh(j), bz1 = z0 + CELL - rh(j + 1);
        bool outer = i < 0 || i > 7 || j < 0 || j > 7;
        bool home = (i == HOME_I && j == HOME_J), store = (i == STORE_I && j == STORE_J);
        bool home2 = (i == HOME2_I && j == HOME2_J), cafe = (i == CAFE_I && j == CAFE_J);
        bool park = !outer && !home && !home2 && !store && !cafe && ((i == 3 && j == 4) || (i == 6 && j == 1) || frand() < 0.06f);
        g_cellType[i - CELL_MIN][j - CELL_MIN] = home ? CT_HOME : home2 ? CT_HOME2 : store ? CT_STORE : cafe ? CT_CAFE : park ? CT_PARK : CT_BUILDING;

        // road surface + markings
        topQuad(C.base[T_ASPHALT], x0, z0, x0 + CELL, z0 + CELL, 0.0f, 0.2f, WHITE);
        addMarkings(P, i, j);

        // sidewalk slab + curb
        topQuad(C.base[T_SIDEWALK], bx0, bz0, bx1, bz1, CURB_H, 0.5f, WHITE);
        sideFaces(C.base[T_SIDEWALK], bx0, bz0, bx1, bz1, 0.0f, CURB_H, -2.0f, -2.0f, col4(0.9f, 0.9f, 0.9f));

        float lx0 = bx0 + 3.0f, lx1 = bx1 - 3.0f, lz0 = bz0 + 3.0f, lz1 = bz1 - 3.0f; // 22m lot
        if (home) {
            genHomeBlock(C, P, lx0, lz0, lx1, lz1);
        } else if (home2) {
            genPaintHouse(C, P, lx0, lz0, lx1, lz1);
        } else if (store) {
            genGunStore(C, lx0, lz0, lx1, lz1);
        } else if (cafe) {
            genCafe(C, lx0, lz0, lx1, lz1);
        } else if (park) {
            topQuad(C.base[T_GRASS], lx0, lz0, lx1, lz1, CURB_H + 0.01f, 0.3f, WHITE);
            float cxm = (lx0 + lx1) * 0.5f, czm = (lz0 + lz1) * 0.5f;
            topQuad(C.base[T_SIDEWALK], cxm - 1.2f, lz0, cxm + 1.2f, lz1, CURB_H + 0.02f, 0.5f, WHITE);
            topQuad(C.base[T_SIDEWALK], lx0, czm - 1.2f, lx1, czm + 1.2f, CURB_H + 0.02f, 0.5f, WHITE);
            // fountain
            Mesh& W = C.base[T_WHITE];
            Col stone = col4(0.75f, 0.73f, 0.70f);
            boxSolid(W, cxm - 3.0f, CURB_H, czm - 3.0f, cxm + 3.0f, CURB_H + 0.6f, czm + 3.0f, stone);
            topQuad(W, cxm - 2.6f, czm - 2.6f, cxm + 2.6f, czm + 2.6f, CURB_H + 0.62f, 0, col4(0.30f, 0.50f, 0.70f));
            boxSolid(W, cxm - 0.4f, CURB_H, czm - 0.4f, cxm + 0.4f, CURB_H + 2.2f, czm + 0.4f, stone);
            addCol(cxm - 3.0f, 0, czm - 3.0f, cxm + 3.0f, CURB_H + 0.6f, czm + 3.0f);
            addCol(cxm - 0.4f, 0, czm - 0.4f, cxm + 0.4f, CURB_H + 2.2f, czm + 0.4f);
            for (int t = 0; t < 10; t++) {
                float tx = frange(lx0 + 1.5f, lx1 - 1.5f), tz = frange(lz0 + 1.5f, lz1 - 1.5f);
                if (fabsf(tx - cxm) < 4.0f || fabsf(tz - czm) < 4.0f) continue;
                addTree(P, tx, tz, CURB_H);
            }
        } else {
            // building height: taller downtown, tall skyline wall on the outer ring
            float dc = sqrtf((x0 + 20 - 160) * (x0 + 20 - 160) + (z0 + 20 - 160) * (z0 + 20 - 160));
            float boost = clampf(1.0f - dc / 200.0f, 0.0f, 1.0f);
            float hmin = outer ? 28.0f : 9.0f, hvar = outer ? 30.0f : 18.0f + 34.0f * boost;
            int type = xrand() % (outer ? 4 : 6);
            float mx = (lx0 + lx1) * 0.5f + frange(-3, 3), mz = (lz0 + lz1) * 0.5f + frange(-3, 3);
            #define HGT() (hmin + frand() * hvar)
            if (type == 0) addBuilding(C, lx0, lz0, lx1, lz1, HGT());
            else if (type == 1) { addBuilding(C, lx0, lz0, mx, lz1, HGT()); addBuilding(C, mx, lz0, lx1, lz1, HGT()); }
            else if (type == 2) { addBuilding(C, lx0, lz0, lx1, mz, HGT()); addBuilding(C, lx0, mz, lx1, lz1, HGT()); }
            else if (type == 3) {
                addBuilding(C, lx0, lz0, mx, mz, HGT()); addBuilding(C, mx, lz0, lx1, mz, HGT());
                addBuilding(C, lx0, mz, mx, lz1, HGT()); addBuilding(C, mx, mz, lx1, lz1, HGT());
            } else if (type == 4) { // alley running north-south through the block
                addBuilding(C, lx0, lz0, mx - 1.8f, lz1, HGT()); addBuilding(C, mx + 1.8f, lz0, lx1, lz1, HGT());
                addAlley(C, P, true, mx - 1.8f, mx + 1.8f, bz0, bz1);
            } else {                // alley running east-west
                addBuilding(C, lx0, lz0, lx1, mz - 1.8f, HGT()); addBuilding(C, lx0, mz + 1.8f, lx1, lz1, HGT());
                addAlley(C, P, false, mz - 1.8f, mz + 1.8f, bx0, bx1);
            }
            #undef HGT
        }

        // street lights at block corners, arms reaching over the road
        addStreetLight(P, bx0 + 0.4f, bz0 + 0.4f, -0.707f, -0.707f);
        addStreetLight(P, bx1 - 0.4f, bz0 + 0.4f, 0.707f, -0.707f);
        addStreetLight(P, bx1 - 0.4f, bz1 - 0.4f, 0.707f, 0.707f);
        addStreetLight(P, bx0 + 0.4f, bz1 - 0.4f, -0.707f, 0.707f);

        if (!outer) {
            // street trees along the curb
            for (int s = 0; s < 4; s++)
                for (int k = 1; k <= 3; k++) {
                    if (frand() > 0.55f) continue;
                    if ((home || home2) && s == 0) continue; // keep the front of the houses clear
                    float a = 7.0f * k;
                    if (s == 0) addTree(P, bx0 + a, bz0 + 0.45f, CURB_H);
                    if (s == 1) addTree(P, bx0 + a, bz1 - 0.45f, CURB_H);
                    if (s == 2) addTree(P, bx0 + 0.45f, bz0 + a, CURB_H);
                    if (s == 3) addTree(P, bx1 - 0.45f, bz0 + a, CURB_H);
                }
            // parked cars along curbs (avenues only; side streets are too narrow)
            for (int s = 0; s < 4; s++)
                for (int k = 0; k < 2; k++) {
                    if (frand() > 0.35f) continue;
                    int roadIdx = s == 0 ? j : s == 1 ? j + 1 : s == 2 ? i : i + 1;
                    if (!isAvenue(roadIdx)) continue;
                    float a = (k == 0 ? 9.0f : 19.0f) + frange(0, 1.5f);
                    if (s == 0) addCar(P, bx0 + a, bz0 - 1.3f, true);
                    if (s == 1) addCar(P, bx0 + a, bz1 + 1.3f, true);
                    if (s == 2) addCar(P, bx0 - 1.3f, bz0 + a, false);
                    if (s == 3) addCar(P, bx1 + 1.3f, bz0 + a, false);
                }
        }
    }
}

// ---------------------------------------------------------------------
//  Raycast
// ---------------------------------------------------------------------
static bool rayAabb(Vec3 o, Vec3 d, const float* mn, const float* mx, float maxT, float& tOut, Vec3& nOut) {
    float tmin = 0.0f, tmax = maxT; int axis = -1; float sign = 0;
    const float oo[3] = {o.x, o.y, o.z}, dd[3] = {d.x, d.y, d.z};
    for (int a = 0; a < 3; a++) {
        if (fabsf(dd[a]) < 1e-8f) { if (oo[a] < mn[a] || oo[a] > mx[a]) return false; continue; }
        float inv = 1.0f / dd[a];
        float t1 = (mn[a] - oo[a]) * inv, t2 = (mx[a] - oo[a]) * inv;
        float s = -1.0f;
        if (t1 > t2) { float tmp = t1; t1 = t2; t2 = tmp; s = 1.0f; }
        if (t1 > tmin) { tmin = t1; axis = a; sign = s; }
        if (t2 < tmax) tmax = t2;
        if (tmin > tmax) return false;
    }
    if (axis < 0) return false;
    tOut = tmin;
    nOut = v3(axis == 0 ? sign : 0.0f, axis == 1 ? sign : 0.0f, axis == 2 ? sign : 0.0f);
    return true;
}

// ---------------------------------------------------------------------
//  NPCs
// ---------------------------------------------------------------------
struct Npc {
    float x, z, yaw;
    int node, target, prev;
    float ox, oz, speed, phase, scale;
    Col shirt, pants, skin, hair, shoes;
    bool alive;
    float health, panic, deadT, fall, fallDir, flinch;
};
static Npc g_npcs[NUM_NPCS];

static const Col SKINS[] = {{0.96f, 0.80f, 0.69f, 1}, {0.87f, 0.67f, 0.52f, 1}, {0.66f, 0.46f, 0.32f, 1}, {0.45f, 0.30f, 0.20f, 1}, {0.93f, 0.75f, 0.60f, 1}};
static const Col SHIRTS[] = {{0.80f, 0.15f, 0.15f, 1}, {0.15f, 0.35f, 0.75f, 1}, {0.95f, 0.95f, 0.95f, 1}, {0.15f, 0.15f, 0.15f, 1}, {0.20f, 0.60f, 0.30f, 1}, {0.95f, 0.75f, 0.20f, 1}, {0.55f, 0.30f, 0.65f, 1}, {0.45f, 0.45f, 0.48f, 1}, {0.95f, 0.50f, 0.20f, 1}, {0.50f, 0.75f, 0.90f, 1}};
static const Col PANTS[] = {{0.15f, 0.20f, 0.40f, 1}, {0.10f, 0.10f, 0.11f, 1}, {0.70f, 0.62f, 0.45f, 1}, {0.35f, 0.35f, 0.37f, 1}, {0.25f, 0.30f, 0.20f, 1}};
static const Col HAIRS[] = {{0.08f, 0.06f, 0.05f, 1}, {0.30f, 0.18f, 0.10f, 1}, {0.75f, 0.60f, 0.30f, 1}, {0.45f, 0.45f, 0.45f, 1}, {0.50f, 0.22f, 0.10f, 1}};

static inline Vec3 nodePos(int n) {
    int b = n / 4, c = n % 4;
    int bi = b % 8, bj = b / 8;
    float x = (c == 1 || c == 2) ? (bi + 1) * CELL - rh(bi + 1) - 1.5f : bi * CELL + rh(bi) + 1.5f;
    float z = (c >= 2) ? (bj + 1) * CELL - rh(bj + 1) - 1.5f : bj * CELL + rh(bj) + 1.5f;
    return v3(x, 0, z);
}
static int nodeNeighbors(int n, int* out) {
    int b = n / 4, c = n % 4, bi = b % 8, bj = b / 8, k = 0;
    out[k++] = b * 4 + (c + 1) % 4;
    out[k++] = b * 4 + (c + 3) % 4;
    if ((c == 0 || c == 3) && bi > 0) out[k++] = (bj * 8 + bi - 1) * 4 + (c == 0 ? 1 : 2);
    if ((c == 1 || c == 2) && bi < 7) out[k++] = (bj * 8 + bi + 1) * 4 + (c == 1 ? 0 : 3);
    if ((c == 0 || c == 1) && bj > 0) out[k++] = ((bj - 1) * 8 + bi) * 4 + (c == 0 ? 3 : 2);
    if ((c == 2 || c == 3) && bj < 7) out[k++] = ((bj + 1) * 8 + bi) * 4 + (c == 3 ? 0 : 1);
    return k;
}

static void npcPickNext(Npc& n, float px, float pz) {
    int nb[6]; int k = nodeNeighbors(n.node, nb);
    int choice = -1;
    if (n.panic > 0) {
        float best = -1;
        for (int i = 0; i < k; i++) {
            Vec3 p = nodePos(nb[i]);
            float d = (p.x - px) * (p.x - px) + (p.z - pz) * (p.z - pz) + frand() * 30.0f;
            if (d > best) { best = d; choice = nb[i]; }
        }
    } else {
        for (int tries = 0; tries < 6; tries++) {
            int c = nb[xrand() % k];
            if (c != n.prev || frand() < 0.1f) { choice = c; break; }
        }
        if (choice < 0) choice = nb[0];
    }
    n.prev = n.node;
    n.target = choice;
}

static void npcSpawn(Npc& n, float px, float pz, bool farOnly) {
    for (int tries = 0; tries < 50; tries++) {
        n.node = xrand() % (64 * 4);
        Vec3 p = nodePos(n.node);
        float d = sqrtf((p.x - px) * (p.x - px) + (p.z - pz) * (p.z - pz));
        if (!farOnly || d > 70.0f) break;
    }
    n.ox = frange(-0.7f, 0.7f); n.oz = frange(-0.7f, 0.7f);
    Vec3 p = nodePos(n.node);
    n.x = p.x + n.ox; n.z = p.z + n.oz;
    n.prev = -1; n.panic = 0;
    npcPickNext(n, px, pz);
    n.speed = frange(1.1f, 1.6f);
    n.phase = frand() * 6.28f;
    n.scale = frange(0.92f, 1.08f);
    n.shirt = PICK(SHIRTS); n.pants = PICK(PANTS); n.skin = PICK(SKINS); n.hair = PICK(HAIRS);
    n.shoes = frand() < 0.5f ? col4(0.08f, 0.08f, 0.08f) : col4(0.85f, 0.85f, 0.85f);
    n.alive = true; n.health = 100; n.deadT = 0; n.fall = 0; n.fallDir = 1; n.flinch = 0;
    n.yaw = frand() * 6.28f;
}

static int lightState(int ii, int jj, int ew); // traffic.cpp section below

// pedestrians wait for the walk signal before stepping off the curb
static bool crossingBlocked(const Npc& n) {
    if (n.panic > 0) return false;
    int bA = n.node / 4, bB = n.target / 4;
    if (bA == bB) return false;
    Vec3 a = nodePos(n.node), b = nodePos(n.target);
    float dx = n.x - (a.x + n.ox), dz = n.z - (a.z + n.oz);
    if (dx * dx + dz * dz > 0.36f) return false; // already on the way across
    float mx = (a.x + b.x) * 0.5f, mz = (a.z + b.z) * 0.5f;
    int ii = (int)floorf(mx / CELL + 0.5f), jj = (int)floorf(mz / CELL + 0.5f);
    if (ii < 0 || ii > 8 || jj < 0 || jj > 8 || interCtrl(ii, jj) != IC_LIGHT) return false;
    bool crossesNSRoad = fabsf(a.x - b.x) > 1.0f;      // walking in x across a road that carries N/S traffic
    int st = lightState(ii, jj, crossesNSRoad ? 0 : 1);
    return st != 2;                                    // only walk while that traffic has red
}

static void updateNpcs(float dt, float px, float pz) {
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i];
        if (!n.alive) {
            n.fall = fminf(1.0f, n.fall + dt * 2.2f);
            n.deadT += dt;
            if (n.deadT > 17.0f) npcSpawn(n, px, pz, true); // body sinks away (see buildNpc), person respawns elsewhere
            continue;
        }
        if (n.panic > 0) n.panic -= dt;
        if (n.flinch > 0) n.flinch = fmaxf(0, n.flinch - dt * 4.0f);
        Vec3 t = nodePos(n.target);
        float tx = t.x + n.ox, tz = t.z + n.oz;
        float dx = tx - n.x, dz = tz - n.z;
        float d = sqrtf(dx * dx + dz * dz);
        float spd = n.panic > 0 ? 4.6f : n.speed;
        if (d < 0.15f) { n.node = n.target; npcPickNext(n, px, pz); continue; }
        if (crossingBlocked(n)) { // wait at the curb, facing the street
            float want = atan2f(-dx, -dz);
            n.yaw += wrapAngle(want - n.yaw) * fminf(1.0f, dt * 6.0f);
            continue;
        }
        float step = fminf(d, spd * dt);
        n.x += dx / d * step; n.z += dz / d * step;
        float want = atan2f(-dx, -dz);
        n.yaw += wrapAngle(want - n.yaw) * fminf(1.0f, dt * 8.0f);
        n.phase += dt * spd * 4.0f;
    }
}

static void panicAround(float x, float z, float radius) {
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i];
        if (!n.alive) continue;
        float d2 = (n.x - x) * (n.x - x) + (n.z - z) * (n.z - z);
        if (d2 < radius * radius) {
            bool was = n.panic > 0;
            n.panic = frange(7.0f, 11.0f);
            if (!was) {
                // mid-segment: keep going or turn back, whichever leads away from the threat
                Vec3 a = nodePos(n.node), b = nodePos(n.target);
                float da = (a.x - x) * (a.x - x) + (a.z - z) * (a.z - z);
                float db = (b.x - x) * (b.x - x) + (b.z - z) * (b.z - z);
                if (da > db) { int t = n.node; n.node = n.target; n.target = t; n.prev = -1; }
            }
        }
    }
}

static const Vec3 WORLD_LIGHT = {0.48f, 0.78f, 0.40f};

static void buildNpc(Mesh& m, const Npc& n, int lod) {
    float g = groundHeight(n.x, n.z);
    float fallA = n.alive ? (-0.35f * n.flinch * n.fallDir) : (n.fallDir * n.fall * 1.5708f);
    float lift = n.alive ? 0.0f : 0.13f * n.fall - fmaxf(0.0f, n.deadT - 15.0f) * 0.35f;
    Mat4 B = mMul(mTrans(n.x, g + lift, n.z), mMul(mRotY(n.yaw), mMul(mRotX(fallA), mScale(n.scale))));
    float amp = n.alive ? (n.panic > 0 ? 0.85f : 0.55f) : 0.0f;
    float sw = sinf(n.phase) * amp;
    Vec3 L = WORLD_LIGHT;
    if (lod >= 2) { // far: 3 boxes
        xbox(m, B, v3(-0.18f, 0.0f, -0.10f), v3(0.18f, 0.86f, 0.10f), n.pants, L);
        xbox(m, B, v3(-0.28f, 0.84f, -0.12f), v3(0.28f, 1.46f, 0.12f), n.shirt, L);
        xbox(m, B, v3(-0.11f, 1.47f, -0.12f), v3(0.11f, 1.76f, 0.12f), n.skin, L);
        return;
    }

    Mat4 legL = mMul(B, mMul(mTrans(0, 0.86f, 0), mMul(mRotX(sw), mTrans(0, -0.86f, 0))));
    Mat4 legR = mMul(B, mMul(mTrans(0, 0.86f, 0), mMul(mRotX(-sw), mTrans(0, -0.86f, 0))));
    float armSpread = n.alive ? 0.0f : 0.9f;
    Mat4 armL = mMul(B, mMul(mTrans(0, 1.40f, 0), mMul(mRotZ(-armSpread), mMul(mRotX(-sw * 0.9f), mTrans(0, -1.40f, 0)))));
    Mat4 armR = mMul(B, mMul(mTrans(0, 1.40f, 0), mMul(mRotZ(armSpread), mMul(mRotX(sw * 0.9f), mTrans(0, -1.40f, 0)))));

    xbox(m, legL, v3(-0.18f, 0.06f, -0.09f), v3(-0.02f, 0.88f, 0.09f), n.pants, L);
    xbox(m, legR, v3(0.02f, 0.06f, -0.09f), v3(0.18f, 0.88f, 0.09f), n.pants, L);
    xbox(m, B, v3(-0.21f, 0.84f, -0.12f), v3(0.21f, 1.46f, 0.12f), n.shirt, L);
    xbox(m, armL, v3(-0.31f, 1.10f, -0.07f), v3(-0.21f, 1.44f, 0.07f), n.shirt, L);
    xbox(m, armR, v3(0.21f, 1.10f, -0.07f), v3(0.31f, 1.44f, 0.07f), n.shirt, L);
    xbox(m, armL, v3(-0.30f, 0.80f, -0.06f), v3(-0.22f, 1.10f, 0.06f), n.skin, L);
    xbox(m, armR, v3(0.22f, 0.80f, -0.06f), v3(0.30f, 1.10f, 0.06f), n.skin, L);
    xbox(m, B, v3(-0.11f, 1.47f, -0.12f), v3(0.11f, 1.72f, 0.11f), n.skin, L);
    xbox(m, B, v3(-0.12f, 1.66f, -0.13f), v3(0.12f, 1.77f, 0.13f), n.hair, L);
    if (lod == 0) {
        xbox(m, B, v3(-0.12f, 1.50f, 0.06f), v3(0.12f, 1.70f, 0.13f), n.hair, L);
        xbox(m, legL, v3(-0.18f, 0.0f, -0.14f), v3(-0.02f, 0.07f, 0.09f), n.shoes, L);
        xbox(m, legR, v3(0.02f, 0.0f, -0.14f), v3(0.18f, 0.07f, 0.09f), n.shoes, L);
        Col eye = col4(0.1f, 0.1f, 0.1f);
        xbox(m, B, v3(-0.07f, 1.59f, -0.125f), v3(-0.03f, 1.62f, -0.118f), eye, L);
        xbox(m, B, v3(0.03f, 1.59f, -0.125f), v3(0.07f, 1.62f, -0.118f), eye, L);
    }
}

// ---------------------------------------------------------------------
//  Effects
// ---------------------------------------------------------------------
struct Particle { Vec3 p, v; float life, maxLife, size, grav; Col c; };
static const int MAX_PARTICLES = 300;
static Particle g_parts[MAX_PARTICLES];
static int g_partNext = 0;

static void spawnParticle(Vec3 p, Vec3 v, float life, float size, float grav, Col c) {
    Particle& q = g_parts[g_partNext]; g_partNext = (g_partNext + 1) % MAX_PARTICLES;
    q.p = p; q.v = v; q.life = life; q.maxLife = life; q.size = size; q.grav = grav; q.c = c;
}

struct Decal { Vec3 p, n; float s; bool used; };
static const int MAX_DECALS = 120;
static Decal g_decals[MAX_DECALS];
static int g_decalNext = 0;

static void addDecal(Vec3 p, Vec3 n) {
    Decal& d = g_decals[g_decalNext]; g_decalNext = (g_decalNext + 1) % MAX_DECALS;
    d.p = p + n * 0.025f; d.n = n; d.s = frange(0.06f, 0.09f); d.used = true;
}

// ---------------------------------------------------------------------
//  Font (5x7, column-major, bit0 = top)
// ---------------------------------------------------------------------
static const char FONT_CHARS[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ/:-.+|()%!, ?$><'[]";
static const unsigned char FONT_DATA[][5] = {
    {0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},{0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},
    {0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x30},{0x01,0x71,0x09,0x05,0x03},
    {0x36,0x49,0x49,0x49,0x36},{0x06,0x49,0x49,0x29,0x1E},
    {0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},
    {0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x09,0x01},{0x3E,0x41,0x49,0x49,0x7A},{0x7F,0x08,0x08,0x08,0x7F},
    {0x00,0x41,0x7F,0x41,0x00},{0x20,0x40,0x41,0x3F,0x01},{0x7F,0x08,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
    {0x7F,0x02,0x0C,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},{0x7F,0x09,0x09,0x09,0x06},
    {0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},{0x46,0x49,0x49,0x49,0x31},{0x01,0x01,0x7F,0x01,0x01},
    {0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,0x08,0x14,0x63},
    {0x07,0x08,0x70,0x08,0x07},{0x61,0x51,0x49,0x45,0x43},
    {0x20,0x10,0x08,0x04,0x02},{0x00,0x36,0x36,0x00,0x00},{0x08,0x08,0x08,0x08,0x08},{0x00,0x60,0x60,0x00,0x00},
    {0x08,0x08,0x3E,0x08,0x08},{0x00,0x00,0x7F,0x00,0x00},{0x00,0x1C,0x22,0x41,0x00},{0x00,0x41,0x22,0x1C,0x00},
    {0x23,0x13,0x08,0x64,0x62},{0x00,0x00,0x5F,0x00,0x00},{0x00,0x50,0x30,0x00,0x00},{0x00,0x00,0x00,0x00,0x00},
    {0x02,0x01,0x51,0x09,0x06},{0x24,0x2A,0x7F,0x2A,0x12},{0x00,0x41,0x22,0x14,0x08},{0x08,0x14,0x22,0x41,0x00},
    {0x00,0x05,0x03,0x00,0x00},{0x00,0x7F,0x41,0x41,0x00},{0x00,0x41,0x41,0x7F,0x00}
};

static void rect2(Mesh& m, float x, float y, float w, float h, Col c) {
    quad(m, v3(x, y, 0), v3(x + w, y, 0), v3(x + w, y + h, 0), v3(x, y + h, 0), 0, 0, 1, 1, c);
}

static void text2(Mesh& m, float x, float y, float s, const char* str, Col c, bool shadow = true) {
    for (int pass = shadow ? 0 : 1; pass < 2; pass++) {
        Col k = pass == 0 ? col4(0, 0, 0, c.a * 0.7f) : c;
        float off = pass == 0 ? s * 0.6f : 0.0f;
        float cx = x;
        for (const char* p = str; *p; p++) {
            char ch = *p; if (ch >= 'a' && ch <= 'z') ch -= 32;
            const char* f = strchr(FONT_CHARS, ch);
            if (f && ch) {
                const unsigned char* g = FONT_DATA[f - FONT_CHARS];
                for (int col = 0; col < 5; col++)
                    for (int row = 0; row < 7; row++)
                        if (g[col] & (1 << row)) rect2(m, cx + col * s + off, y + row * s + off, s, s, k);
            }
            cx += 6 * s;
        }
    }
}
static float textWidth(const char* s, float sc) { return strlen(s) * 6 * sc - sc; }
static void textC(Mesh& m, float cx, float y, float s, const char* str, Col c) {
    text2(m, cx - textWidth(str, s) * 0.5f, y, s, str, c);
}

// text built into world geometry (store sign)
static void textWorld(Mesh& m, Vec3 origin, Vec3 right, Vec3 down, float s, const char* str, Col c) {
    float cx = 0;
    for (const char* p = str; *p; p++) {
        const char* f = strchr(FONT_CHARS, *p);
        if (f && *p) {
            const unsigned char* g = FONT_DATA[f - FONT_CHARS];
            for (int col = 0; col < 5; col++)
                for (int row = 0; row < 7; row++)
                    if (g[col] & (1 << row)) {
                        Vec3 a = origin + right * (cx + col * s) + down * (row * s);
                        quad(m, a, a + right * s, a + right * s + down * s, a + down * s, 0, 0, 1, 1, c);
                    }
        }
        cx += 6 * s;
    }
}
static void tri2(Mesh& m, float ax, float ay, float bx, float by, float cx, float cy, Col c) {
    quad(m, v3(ax, ay, 0), v3(bx, by, 0), v3(cx, cy, 0), v3(cx, cy, 0), 0, 0, 1, 1, c);
}

// ---------------------------------------------------------------------
//  Game state
// ---------------------------------------------------------------------
struct Player {
    float x, y, z, vx, vz, vy, yaw, pitch;
    bool ground;
    float bobPhase, moveAmt;
};
static Player P;

static float g_ads = 0, g_sprint = 0, g_fireCD = 0, g_recoil = 0, g_bloom = 0, g_flash = 0;
static float g_reload = -1;            // <0 not reloading, else elapsed time
static int   g_ammo = 30;
static float g_hitMarker = 0; static bool g_hitKill = false;
static float g_swayX = 0, g_swayY = 0;
enum { UI_NONE = 0, UI_PAUSE, UI_PHONE, UI_DIALOG, UI_BENCH, UI_BARISTA };
static int   g_ui = UI_NONE;
static float g_helpT = 10.0f;
static float g_time = 0;

// progression
static int   g_money = 0;
static bool  g_hasGun = false;
static int   g_q1 = 0;   // Lawn Care: 0 not offered, 1 active, 2 done
static int   g_q2 = 0;   // Gear Up:   0 hidden, 1 active, 2 done
static int   g_q3 = 0;   // Paint Job: 0 not offered, 1 active, 2 done
static bool  g_hired = false;               // Barista job (repeatable)
static int   g_shifts = 0, g_bestShift = 0;
static char  g_toast[2][48]; static float g_toastT = 0;
static const char* g_prompt = 0;

// story NPCs (never die)
static Npc g_walt, g_clerk, g_rosa, g_mgr;

// lawn + mower
static unsigned char g_lawn[LAWN_H][LAWN_W]; // 0 = path (not grass), 1 = tall, 2 = cut
static int  g_lawnTotal = 0, g_lawnCut = 0;
static bool g_lawnDirty = true;
static Mesh g_lawnMesh;
static Vec3 g_mowerPos = {185.5f, 0.15f, 180.6f};
static float g_mowerYaw = 0.4f;
static bool g_mowing = false;

// phone
static int g_phoneApp = -1, g_phoneSel = 0;

// dialog
enum { DLG_WALT_OFFER, DLG_WALT_ACTIVE, DLG_WALT_DONE, DLG_STORE_BUY, DLG_STORE_BROKE, DLG_STORE_OWNED,
       DLG_ROSA_OFFER, DLG_ROSA_ACTIVE, DLG_ROSA_DONE, DLG_CAFE_APPLY, DLG_CAFE_WORK };
static int g_dlg = 0;

static void toast(const char* a, const char* b) {
    strncpy(g_toast[0], a, 47); g_toast[0][47] = 0;
    strncpy(g_toast[1], b ? b : "", 47); g_toast[1][47] = 0;
    g_toastT = 3.5f;
}
static float g_flashRot = 0;

static Vec3 camForward() {
    return v3(-sinf(P.yaw) * cosf(P.pitch), sinf(P.pitch), -cosf(P.yaw) * cosf(P.pitch));
}

static bool inView(float cx, float cz, float radius, float hfov);
// ---------------------------------------------------------------------
//  Traffic: signals + cars
// ---------------------------------------------------------------------
static const int   TR_N = 9;          // intersections 0..8 on each axis (roads at multiples of 40)
static const float LANE = 2.6f;       // lane center offset from road center (drive on the right)
static const float CAR_HL = 2.15f, CAR_HW = 0.9f;
static const int   NUM_CARS = 56;
static const float CYCLE = 26.0f;

// 0 green, 1 yellow, 2 red. ew = 0 for N/S traffic, 1 for E/W traffic
static int lightState(int ii, int jj, int ew) {
    float t = fmodf(g_time + (float)((ii * 7 + jj * 11) % 26), CYCLE);
    if (!ew) return t < 9.0f ? 0 : (t < 11.5f ? 1 : 2);
    return (t >= 13.0f && t < 22.0f) ? 0 : ((t >= 22.0f && t < 24.5f) ? 1 : 2);
}

struct Car {
    float x, z, yaw, speed;
    int dx, dz;          // heading on the current segment / into the intersection
    int ii, jj;          // the intersection we are approaching (or crossing)
    int turn;            // plan at that intersection: 0 straight, 1 right, 2 left
    int mode;            // 0 driving a segment, 1 crossing the intersection
    int ndx, ndz;        // exit heading while crossing
    float t, tlen;       // bezier param + length while crossing
    Vec3 bE, bC, bX;
    float stuck, ghost;
    float stopT, arrive;  // stop-sign bookkeeping
    bool cleared;
    bool braking;
    Col col;
};
static Car g_cars[NUM_CARS];

static inline bool trIn(int i, int j) { return i >= 0 && i < TR_N && j >= 0 && j < TR_N; }
static inline void turnDir(int dx, int dz, int turn, int& ox, int& oz) {
    if (turn == 0) { ox = dx; oz = dz; }
    else if (turn == 1) { ox = -dz; oz = dx; }   // right
    else { ox = dz; oz = -dx; }                   // left
}
static void planTurn(Car& c) {
    int opts[3], w[3], n = 0, tot = 0;
    const int weight[3] = {55, 25, 20};
    for (int k = 0; k < 3; k++) {
        int ox, oz; turnDir(c.dx, c.dz, k, ox, oz);
        if (trIn(c.ii + ox, c.jj + oz)) { opts[n] = k; w[n] = weight[k]; tot += weight[k]; n++; }
    }
    int r = (int)(xrand() % (unsigned)tot);
    for (int k = 0; k < n; k++) { if (r < w[k]) { c.turn = opts[k]; return; } r -= w[k]; }
    c.turn = opts[0];
}
static inline float laneOff(int ii, int jj, int dx) { return rh(dx != 0 ? jj : ii) > 5.0f ? LANE : 2.0f; }
static inline float crossHalf(int ii, int jj, int dx) { return rh(dx != 0 ? ii : jj); }
static inline Vec3 laneEntry(int ii, int jj, int dx, int dz) { // where a lane meets the intersection box
    float ch = crossHalf(ii, jj, dx), lo = laneOff(ii, jj, dx);
    return v3(ii * CELL - dx * ch + (-dz) * lo, 0, jj * CELL - dz * ch + dx * lo);
}
static inline Vec3 laneExit(int ii, int jj, int dx, int dz) {
    float ch = crossHalf(ii, jj, dx), lo = laneOff(ii, jj, dx);
    return v3(ii * CELL + dx * ch + (-dz) * lo, 0, jj * CELL + dz * ch + dx * lo);
}

static void spawnCar(Car& c) {
    for (int tries = 0; tries < 60; tries++) {
        c.ii = xrand() % TR_N; c.jj = xrand() % TR_N;
        int h = xrand() % 4;
        c.dx = h == 0 ? 1 : h == 1 ? -1 : 0; c.dz = h == 2 ? 1 : h == 3 ? -1 : 0;
        if (!trIn(c.ii - c.dx, c.jj - c.dz)) continue;
        Vec3 e = laneEntry(c.ii, c.jj, c.dx, c.dz);
        float back = frange(6.0f, 26.0f);
        c.x = e.x - c.dx * back; c.z = e.z - c.dz * back;
        bool ok = true;
        for (int k = 0; k < NUM_CARS; k++) {
            Car& o = g_cars[k];
            if (&o == &c || o.speed < 0) continue;
            if ((o.x - c.x) * (o.x - c.x) + (o.z - c.z) * (o.z - c.z) < 81.0f) { ok = false; break; }
        }
        if (ok) break;
    }
    c.mode = 0; c.speed = frange(3, 8); c.yaw = atan2f((float)-c.dx, (float)-c.dz);
    c.stuck = 0; c.ghost = 0; c.braking = false; c.stopT = 0; c.arrive = -1; c.cleared = false;
    c.col = PICK(CAR_COLS);
    planTurn(c);
}

static void initTraffic() {
    for (int i = 0; i < NUM_CARS; i++) g_cars[i].speed = -1; // mark unspawned for spacing test
    for (int i = 0; i < NUM_CARS; i++) spawnCar(g_cars[i]);
}

// nearest obstacle ahead (meters of free road), or 99
static int g_blocker = -1;
static float carObstacleGap(const Car& c, float hx, float hz, bool& byCar) {
    float best = 99.0f; byCar = false; g_blocker = -1;
    float rx = -hz, rz = hx;
    if (c.ghost <= 0) {
        for (int k = 0; k < NUM_CARS; k++) {
            const Car& o = g_cars[k];
            if (&o == &c) continue;
            float vx = o.x - c.x, vz = o.z - c.z;
            float f = vx * hx + vz * hz; if (f <= 0 || f > 24.0f) continue;
            float l = fabsf(vx * rx + vz * rz); if (l > 1.9f) continue;
            float g = f - 2 * CAR_HL - 1.2f;
            if (g < best) { best = g; byCar = true; g_blocker = k; }
        }
    }
    { // player
        float vx = P.x - c.x, vz = P.z - c.z;
        float f = vx * hx + vz * hz, l = fabsf(vx * rx + vz * rz);
        if (f > 0 && f < 24.0f && l < 1.5f && P.y < 1.5f) { float g = f - CAR_HL - 1.5f; if (g < best) { best = g; byCar = false; } }
    }
    for (int k = 0; k < NUM_NPCS; k++) { // pedestrians on the road
        const Npc& n = g_npcs[k];
        if (!n.alive || inBlock(n.x, n.z)) continue;
        float vx = n.x - c.x, vz = n.z - c.z;
        float f = vx * hx + vz * hz; if (f <= 0 || f > 20.0f) continue;
        float l = fabsf(vx * rx + vz * rz); if (l > 1.4f) continue;
        float g = f - CAR_HL - 1.5f;
        if (g < best) { best = g; byCar = false; }
    }
    return best;
}

// left turners wait for oncoming traffic (opposing left turners take turns)
static bool oncomingTraffic(const Car& c) {
    for (int k = 0; k < NUM_CARS; k++) {
        const Car& o = g_cars[k];
        if (&o == &c || o.ii != c.ii || o.jj != c.jj) continue;
        if (o.dx != -c.dx || o.dz != -c.dz) continue;
        if (o.mode == 1) return true;
        Vec3 e = laneEntry(o.ii, o.jj, o.dx, o.dz);
        float d = (e.x - o.x) * o.dx + (e.z - o.z) * o.dz;
        if (d < 22.0f && o.speed > 1.0f) return true;
        if (d < 4.5f && (o.turn != 2 || &o < &c)) return true;
    }
    return false;
}
// may a car that has stopped at a stop sign go now?
static bool stopClear(const Car& c) {
    int ctrl = interCtrl(c.ii, c.jj);
    for (int k = 0; k < NUM_CARS; k++) {
        const Car& o = g_cars[k];
        if (&o == &c || o.ii != c.ii || o.jj != c.jj) continue;
        if (o.mode == 1) return false;                                   // box occupied
        Vec3 e = laneEntry(o.ii, o.jj, o.dx, o.dz);
        float d = (e.x - o.x) * o.dx + (e.z - o.z) * o.dz;
        if (o.cleared && d < 8.0f && !(o.dx == -c.dx && o.dz == -c.dz && o.turn != 2 && c.turn != 2))
            return false;                                                // someone already has the go-ahead
        if (ctrl == IC_ALLWAY && !o.cleared && o.arrive >= 0 && o.arrive == c.arrive && &o < &c) return false;
        if (ctrl == IC_TWOWAY && !approachHasStop(o.ii, o.jj, o.dx)) {   // cross traffic on the avenue has priority
            if (d < 28.0f && (o.speed > 0.5f || d < 8.0f)) return false;
        }
        if (ctrl == IC_ALLWAY && !o.cleared && o.arrive >= 0 && o.arrive < c.arrive) return false; // first come, first served
    }
    return true;
}

// straight/right traffic yields to an oncoming left turner already in the box
static bool leftTurnerInBox(const Car& c) {
    for (int k = 0; k < NUM_CARS; k++) {
        const Car& o = g_cars[k];
        if (&o == &c || o.mode != 1 || o.turn != 2 || o.ii != c.ii || o.jj != c.jj) continue;
        if (o.dx == -c.dx && o.dz == -c.dz) return true;
    }
    return false;
}

static void updateTraffic(float dt) {
    for (int i = 0; i < NUM_CARS; i++) {
        Car& c = g_cars[i];
        if (c.ghost > 0) c.ghost -= dt;
        float hx, hz, vmax, vtarget;
        bool stopLine = false;
        if (c.mode == 0) {
            hx = (float)c.dx; hz = (float)c.dz; vmax = 9.5f;
            Vec3 e = laneEntry(c.ii, c.jj, c.dx, c.dz);
            float dEntry = (e.x - c.x) * c.dx + (e.z - c.z) * c.dz;
            float dStop = dEntry - 3.6f;
            bool mustStop = false;
            if (interCtrl(c.ii, c.jj) == IC_LIGHT) {
                int st = lightState(c.ii, c.jj, c.dx != 0 ? 1 : 0);
                // yellow: stop if we can do it comfortably, otherwise clear the intersection
                bool canStop = dStop - 0.2f > (c.speed * c.speed) / (2.0f * 6.0f);
                mustStop = (st == 2 && dStop > -0.3f) || (st == 1 && canStop);
            } else if (approachHasStop(c.ii, c.jj, c.dx) && !c.cleared && dStop > -0.6f) {
                mustStop = true;                       // full stop at the sign, then go when clear
                if (dStop < 1.2f && c.speed < 0.3f) {
                    c.stopT += dt;
                    if (c.arrive < 0) c.arrive = g_time;
                    if (c.stopT > 0.8f && stopClear(c)) { c.cleared = true; mustStop = false; }
                }
            }
            // at stop signs the stop-sign order decides; elsewhere left turners yield
            if (!mustStop && !c.cleared && c.turn == 2 && dStop > -0.3f && oncomingTraffic(c)) mustStop = true;
            if (!mustStop && !c.cleared && c.turn != 2 && dStop > -0.3f && dStop < 12.0f && leftTurnerInBox(c)) mustStop = true;
            vtarget = vmax;
            if (mustStop) { vtarget = fminf(vtarget, sqrtf(2.0f * 5.0f * fmaxf(0.0f, dStop - 0.2f))); stopLine = true; }
            if (c.turn != 0 && dEntry < 14.0f) vtarget = fminf(vtarget, 6.0f);
            if (dEntry <= 0.0f) { // enter the intersection
                int ox, oz; turnDir(c.dx, c.dz, c.turn, ox, oz);
                c.ndx = ox; c.ndz = oz;
                c.bE = e; c.bX = laneExit(c.ii, c.jj, ox, oz);
                if (c.turn == 0) { c.bC = (c.bE + c.bX) * 0.5f; c.tlen = len3(c.bX - c.bE); }
                else {
                    // corner of the two lane lines
                    c.bC = v3(c.dx != 0 ? c.bX.x : c.bE.x, 0, c.dz != 0 ? c.bX.z : c.bE.z);
                    c.tlen = 0.8f * (len3(c.bC - c.bE) + len3(c.bX - c.bC));
                }
                c.stopT = 0; c.arrive = -1; c.cleared = false;
                c.t = 0; c.mode = 1;
            }
        } else {
            float t = c.t;
            Vec3 tg = (c.bC - c.bE) * (2 * (1 - t)) + (c.bX - c.bC) * (2 * t);
            Vec3 tn = norm3(v3(tg.x, 0, tg.z));
            hx = tn.x; hz = tn.z;
            vmax = c.turn == 0 ? 9.5f : 5.5f;
            vtarget = vmax;
        }
        bool byCar;
        float gap = carObstacleGap(c, hx, hz, byCar);
        float vgap = gap <= 0.3f ? 0.0f : sqrtf(2.0f * 7.0f * (gap - 0.3f));
        vtarget = fminf(vtarget, vgap);
        if (c.speed > vtarget) c.speed = fmaxf(vtarget, c.speed - 9.0f * dt);
        else c.speed = fminf(vtarget, c.speed + 3.5f * dt);
        c.braking = c.speed < 0.5f || vtarget < c.speed - 0.1f;
        // deadlock breaker: if another car has blocked us for a while, squeeze past
        bool boxJam = byCar && g_blocker >= 0 && (c.mode == 1 || g_cars[g_blocker].mode == 1) && g_cars[g_blocker].speed < 0.3f;
        if (c.speed < 0.3f && boxJam && !stopLine) { c.stuck += dt; if (c.stuck > 5.0f) { c.ghost = 2.5f; c.stuck = 0; } }
        else c.stuck = 0;

        if (c.mode == 0) {
            c.x += hx * c.speed * dt; c.z += hz * c.speed * dt;
        } else {
            c.t += c.speed * dt / c.tlen;
            if (c.t >= 1.0f) {
                c.x = c.bX.x; c.z = c.bX.z;
                c.dx = c.ndx; c.dz = c.ndz;
                c.ii += c.dx; c.jj += c.dz;
                c.mode = 0;
                planTurn(c);
                hx = (float)c.dx; hz = (float)c.dz;
            } else {
                float t = c.t, a = (1 - t) * (1 - t), b = 2 * (1 - t) * t, d = t * t;
                Vec3 p = c.bE * a + c.bC * b + c.bX * d;
                c.x = p.x; c.z = p.z;
            }
        }
        float want = atan2f(-hx, -hz);
        c.yaw += wrapAngle(want - c.yaw) * fminf(1.0f, dt * 12.0f);
    }
}

// world-space point -> car-local (car forward = -z)
static inline void carLocal(const Car& c, float wx, float wz, float& lx, float& lz) {
    float dx = wx - c.x, dz = wz - c.z, cs = cosf(c.yaw), sn = sinf(c.yaw);
    lx = cs * dx - sn * dz; lz = sn * dx + cs * dz;
}

static void buildCar(Mesh& m, const Car& c, bool lod) {
    const Vec3 L = WORLD_LIGHT;
    Mat4 M = mMul(mTrans(c.x, 0, c.z), mRotY(c.yaw));
    Col glass = col4(0.12f, 0.16f, 0.20f), tire = col4(0.07f, 0.07f, 0.07f);
    xbox(m, M, v3(-CAR_HW, 0.32f, -CAR_HL), v3(CAR_HW, 0.95f, CAR_HL), c.col, L);
    xbox(m, M, v3(-CAR_HW * 0.88f, 0.95f, -0.85f), v3(CAR_HW * 0.88f, 1.42f, 1.15f), glass, L);
    xbox(m, M, v3(-CAR_HW * 0.84f, 1.42f, -0.75f), v3(CAR_HW * 0.84f, 1.50f, 1.05f), c.col, L);
    if (lod) return;
    for (int k = 0; k < 4; k++) {
        float wz = (k & 1) ? 1.4f : -1.4f, wx = (k & 2) ? 0.72f : -0.95f;
        xbox(m, M, v3(wx, 0.0f, wz - 0.32f), v3(wx + 0.23f, 0.62f, wz + 0.32f), tire, L);
    }
    Col head = col4(1, 1, 0.85f), tail = c.braking ? col4(1, 0.08f, 0.05f) : col4(0.55f, 0.05f, 0.05f);
    xbox(m, M, v3(-0.78f, 0.62f, -CAR_HL - 0.03f), v3(-0.42f, 0.80f, -CAR_HL + 0.02f), head, L);
    xbox(m, M, v3(0.42f, 0.62f, -CAR_HL - 0.03f), v3(0.78f, 0.80f, -CAR_HL + 0.02f), head, L);
    xbox(m, M, v3(-0.78f, 0.62f, CAR_HL - 0.02f), v3(-0.45f, 0.78f, CAR_HL + 0.03f), tail, L);
    xbox(m, M, v3(0.45f, 0.62f, CAR_HL - 0.02f), v3(0.78f, 0.78f, CAR_HL + 0.03f), tail, L);
    // turn signal
    bool sig = c.turn != 0 && fmodf(g_time, 0.8f) < 0.4f;
    if (sig) {
        float sx = c.turn == 1 ? 1.0f : -1.0f;
        Col org = col4(1, 0.6f, 0.05f);
        xbox(m, M, v3(sx > 0 ? 0.80f : -0.92f, 0.62f, -CAR_HL - 0.04f), v3(sx > 0 ? 0.92f : -0.80f, 0.76f, -CAR_HL + 0.02f), org, L);
        xbox(m, M, v3(sx > 0 ? 0.80f : -0.92f, 0.62f, CAR_HL - 0.02f), v3(sx > 0 ? 0.92f : -0.80f, 0.76f, CAR_HL + 0.04f), org, L);
    }
}

// signal heads on the corner poles (the street light poles at each corner)
static void buildSignals(Mesh& m, float hfov) {
    const Vec3 L = WORLD_LIGHT;
    for (int ii = 0; ii < TR_N; ii++)
        for (int jj = 0; jj < TR_N; jj++) {
            float X = ii * CELL, Z = jj * CELL;
            float dx = X - P.x, dz = Z - P.z;
            if (dx * dx + dz * dz > 75.0f * 75.0f) continue;
            if (interCtrl(ii, jj) != IC_LIGHT) continue;
            if (!inView(X, Z, 12.0f, hfov)) continue;
            // approach headings: northbound(-z), southbound(+z), eastbound(+x), westbound(-x)
            const int hd[4][2] = {{0, -1}, {0, 1}, {1, 0}, {-1, 0}};
            for (int a = 0; a < 4; a++) {
                int hx = hd[a][0], hz = hd[a][1];
                int rx = -hz, rz = hx;
                // pole at the near-right corner of the approach
                float own = hx != 0 ? rh(jj) : rh(ii), cross = hx != 0 ? rh(ii) : rh(jj);
                float px = X - hx * (cross + 0.4f) + rx * (own + 0.4f);
                float pz = Z - hz * (cross + 0.4f) + rz * (own + 0.4f);
                float faceYaw = atan2f((float)hx, (float)hz); // local -z faces oncoming drivers
                Mat4 M = mMul(mTrans(px - rx * 0.25f, CURB_H, pz - rz * 0.25f), mRotY(faceYaw));
                int st = lightState(ii, jj, hx != 0 ? 1 : 0);
                xbox(m, M, v3(-0.17f, 2.9f, -0.12f), v3(0.17f, 3.95f, 0.12f), col4(0.12f, 0.12f, 0.10f), L);
                Col rc = st == 2 ? col4(1, 0.12f, 0.08f) : col4(0.22f, 0.05f, 0.05f);
                Col yc = st == 1 ? col4(1, 0.8f, 0.1f) : col4(0.22f, 0.18f, 0.05f);
                Col gc = st == 0 ? col4(0.25f, 1, 0.4f) : col4(0.05f, 0.2f, 0.08f);
                Vec3 LF = norm3(v3((float)-hx, 0.3f, (float)-hz)); // lamps lit from the front so they read bright
                xbox(m, M, v3(-0.1f, 3.62f, -0.16f), v3(0.1f, 3.82f, -0.12f), rc, LF);
                xbox(m, M, v3(-0.1f, 3.32f, -0.16f), v3(0.1f, 3.52f, -0.12f), yc, LF);
                xbox(m, M, v3(-0.1f, 3.02f, -0.16f), v3(0.1f, 3.22f, -0.12f), gc, LF);
            }
        }
}

static void collidePlayer() {
    float feet = P.y;
    for (size_t i = 0; i < g_cols.size(); i++) {
        const AABB& a = g_cols[i];
        if (a.mx[1] < feet + 0.35f || a.mn[1] > feet + 1.8f) continue;
        if (P.x < a.mn[0] - 1 || P.x > a.mx[0] + 1 || P.z < a.mn[2] - 1 || P.z > a.mx[2] + 1) continue;
        float cx = clampf(P.x, a.mn[0], a.mx[0]);
        float cz = clampf(P.z, a.mn[2], a.mx[2]);
        float dx = P.x - cx, dz = P.z - cz;
        float d2 = dx * dx + dz * dz;
        if (d2 >= PLAYER_RAD * PLAYER_RAD) continue;
        if (d2 > 1e-8f) {
            float d = sqrtf(d2), push = PLAYER_RAD - d;
            P.x += dx / d * push; P.z += dz / d * push;
        } else {
            float pl = P.x - a.mn[0], pr = a.mx[0] - P.x, pb = P.z - a.mn[2], pf = a.mx[2] - P.z;
            float mn = fminf(fminf(pl, pr), fminf(pb, pf));
            if (mn == pl) P.x = a.mn[0] - PLAYER_RAD;
            else if (mn == pr) P.x = a.mx[0] + PLAYER_RAD;
            else if (mn == pb) P.z = a.mn[2] - PLAYER_RAD;
            else P.z = a.mx[2] + PLAYER_RAD;
        }
    }
    // NPC bodies push the player gently
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i]; if (!n.alive) continue;
        float dx = P.x - n.x, dz = P.z - n.z, d2 = dx * dx + dz * dz;
        float r = PLAYER_RAD + 0.3f;
        if (d2 < r * r && d2 > 1e-6f) { float d = sqrtf(d2); P.x += dx / d * (r - d); P.z += dz / d * (r - d); }
    }
    for (int i = 0; i < NUM_CARS; i++) { // moving cars (oriented boxes)
        const Car& c = g_cars[i];
        if (fabsf(c.x - P.x) > 4 || fabsf(c.z - P.z) > 4) continue;
        float lx, lz; carLocal(c, P.x, P.z, lx, lz);
        float ex = CAR_HW + PLAYER_RAD, ez = CAR_HL + PLAYER_RAD;
        if (fabsf(lx) >= ex || fabsf(lz) >= ez) continue;
        if (ex - fabsf(lx) < ez - fabsf(lz)) lx = lx < 0 ? -ex : ex; else lz = lz < 0 ? -ez : ez;
        float cs = cosf(c.yaw), sn = sinf(c.yaw);
        P.x = c.x + cs * lx + sn * lz; P.z = c.z - sn * lx + cs * lz;
    }
    Npc* sp[4] = {&g_walt, &g_clerk, &g_rosa, &g_mgr};
    for (int i = 0; i < 4; i++) {
        float dx = P.x - sp[i]->x, dz = P.z - sp[i]->z, d2 = dx * dx + dz * dz;
        float r = PLAYER_RAD + 0.3f;
        if (d2 < r * r && d2 > 1e-6f) { float d = sqrtf(d2); P.x += dx / d * (r - d); P.z += dz / d * (r - d); }
    }
    P.x = clampf(P.x, WORLD_MIN, WORLD_MAX);
    P.z = clampf(P.z, WORLD_MIN, WORLD_MAX);
}

// ---------------------------------------------------------------------
//  Gun modifications
// ---------------------------------------------------------------------
enum { CAT_BARREL = 0, CAT_MUZZLE, CAT_SIGHT, CAT_MAG, CAT_UNDER, NCAT };
static const int NPARTS = 4;
struct PartDef { const char* name; int price; const char* desc; };
static const char* CAT_NAMES[NCAT] = {"BARREL", "MUZZLE", "SIGHT", "MAGAZINE", "UNDERBARREL"};
static const PartDef PARTS[NCAT][NPARTS] = {
    {{"STANDARD", 0, "FACTORY 16 INCH BARREL."},
     {"SHORT CARBINE", 15, "FASTER AIM. WORSE AIMED ACCURACY."},
     {"LONG MARKSMAN", 35, "+50% DAMAGE, TIGHT AIM, SLOW AIM."},
     {"HEAVY FLUTED", 30, "-25% RECOIL, LESS SPREAD BLOOM."}},
    {{"MUZZLE BRAKE", 0, "FACTORY BRAKE."},
     {"FLASH HIDER", 10, "SMALLER MUZZLE FLASH."},
     {"COMPENSATOR", 20, "-30% RECOIL, BIGGER FLASH."},
     {"SUPPRESSOR", 45, "NO FLASH. PEOPLE PANIC LESS."}},
    {{"IRON SIGHTS", 0, "FRONT POST AND REAR NOTCH."},
     {"RED DOT", 20, "CLEAN RED DOT. 1X."},
     {"HOLOGRAPHIC", 25, "RING AND DOT RETICLE. 1.1X."},
     {"4X SCOPE", 50, "4X ZOOM. SLOWER TO AIM."}},
    {{"STANDARD 30", 0, "30 ROUNDS."},
     {"COUPLED 30", 15, "30 ROUNDS. MUCH FASTER RELOAD."},
     {"EXTENDED 40", 20, "40 ROUNDS. SLOWER RELOAD."},
     {"DRUM 60", 45, "60 ROUNDS. SLOW RELOAD AND AIM."}},
    {{"NONE", 0, "BARE HANDGUARD."},
     {"VERTICAL GRIP", 15, "-20% RECOIL."},
     {"ANGLED GRIP", 15, "FASTER AIM. -8% RECOIL."},
     {"LASER", 25, "TIGHTER HIP FIRE. LASER DOT."}}
};
static const PartDef PARTS_P[NCAT][NPARTS] = {
    {{"STANDARD 4 INCH", 0, "FACTORY SLIDE AND BARREL."},
     {"SNUB 3 INCH", 8, "FASTER AIM. WORSE AIMED ACCURACY."},
     {"LONG SLIDE 6 INCH", 20, "+50% DAMAGE, TIGHT AIM, SLOW AIM."},
     {"PORTED SLIDE", 15, "-25% RECOIL, LESS SPREAD BLOOM."}},
    {{"THREAD PROTECTOR", 0, "FACTORY THREAD CAP."},
     {"MINI FLASH HIDER", 6, "SMALLER MUZZLE FLASH."},
     {"COMPENSATOR", 12, "-30% RECOIL, BIGGER FLASH."},
     {"SUPPRESSOR", 25, "NO FLASH. PEOPLE PANIC LESS."}},
    {{"IRON SIGHTS", 0, "THREE DOT FRONT AND REAR."},
     {"MINI RED DOT", 12, "SLIDE MOUNTED RED DOT."},
     {"MINI HOLO", 15, "RING AND DOT RETICLE."},
     {"2X PISTOL SCOPE", 25, "2X ZOOM. SLOWER TO AIM."}},
    {{"STANDARD 12", 0, "12 ROUNDS."},
     {"FLARED WELL 12", 8, "12 ROUNDS. MUCH FASTER RELOAD."},
     {"EXTENDED 20", 12, "20 ROUNDS. SLOWER RELOAD."},
     {"DRUM 40", 28, "40 ROUNDS. SLOW RELOAD AND AIM."}},
    {{"NONE", 0, "BARE FRAME RAIL."},
     {"MINI GRIP", 8, "-20% RECOIL."},
     {"HAND STOP", 8, "FASTER AIM. -8% RECOIL."},
     {"LASER", 12, "TIGHTER HIP FIRE. LASER DOT."}}
};
enum { W_RIFLE = 0, W_PISTOL = 1 };
static const char* WEAPON_NAMES[2] = {"RIFLE", "PISTOL"};
static const int WEAPON_PRICE[2] = {25, 15};
static int g_weapon = W_RIFLE;
static bool g_ownW[2] = {false, false};
static int g_equipW[2][NCAT] = {{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}};
static unsigned g_ownedW[2][NCAT] = {{1, 1, 1, 1, 1}, {1, 1, 1, 1, 1}}; // bit per part
static int g_ammoW[2] = {30, 12};
#define g_equip (g_equipW[g_weapon])
#define g_owned (g_ownedW[g_weapon])
#define CURPARTS (g_weapon == W_PISTOL ? PARTS_P : PARTS)

struct GunStats {
    float recoil, spreadHip, spreadAds, bloom, adsSpeed, adsFov, reload, flash, panic, dmg, sightY, adsZ, fireDelay;
    int mag;
    bool semi;
};
static GunStats computeStatsW(const int* e, int w) {
    GunStats s;
    s.recoil = 1; s.spreadHip = 1; s.spreadAds = 1; s.bloom = 1; s.adsSpeed = 1; s.adsFov = FOV_ADS;
    s.reload = 1.75f; s.flash = 1; s.panic = 1; s.dmg = 1; s.sightY = 0.042f; s.adsZ = -0.21f; s.mag = 30;
    s.fireDelay = FIRE_DELAY; s.semi = false;
    if (w == W_PISTOL) { // pistol base: semi-auto, quick handling, lighter hitting
        s.recoil = 1.2f; s.spreadHip = 0.75f; s.adsSpeed = 1.5f; s.adsFov = 58.0f; s.reload = 1.35f;
        s.flash = 0.8f; s.dmg = 0.8f; s.sightY = 0.037f; s.adsZ = -0.30f; s.mag = 12; s.fireDelay = 0.13f; s.semi = true;
    }
    switch (e[CAT_BARREL]) {
    case 1: s.adsSpeed *= 1.25f; s.spreadHip *= 0.9f; s.spreadAds *= 1.8f; s.recoil *= 1.1f; break;
    case 2: s.spreadAds *= 0.45f; s.spreadHip *= 1.15f; s.adsSpeed *= 0.8f; s.dmg *= 1.5f; break;
    case 3: s.recoil *= 0.75f; s.bloom *= 0.7f; s.adsSpeed *= 0.88f; break;
    }
    switch (e[CAT_MUZZLE]) {
    case 1: s.flash *= 0.4f; s.recoil *= 0.95f; break;
    case 2: s.recoil *= 0.7f; s.flash *= 1.3f; break;
    case 3: s.flash = 0; s.recoil *= 0.9f; s.panic *= 0.35f; s.dmg *= 0.9f; break;
    }
    if (w == W_PISTOL) {
        switch (e[CAT_SIGHT]) {
        case 1: s.sightY = 0.047f; s.adsFov = 55.0f; break;
        case 2: s.sightY = 0.0485f; s.adsFov = 52.0f; break;
        case 3: s.sightY = 0.066f; s.adsZ = -0.24f; s.adsFov = 30.0f; s.adsSpeed *= 0.75f; break;
        }
        switch (e[CAT_MAG]) {
        case 1: s.reload = 0.8f; break;
        case 2: s.mag = 20; s.reload = 1.55f; s.adsSpeed *= 0.95f; break;
        case 3: s.mag = 40; s.reload = 2.4f; s.adsSpeed *= 0.8f; break;
        }
    } else {
        switch (e[CAT_SIGHT]) {
        case 1: s.sightY = 0.063f; s.adsZ = -0.20f; s.adsFov = 44.0f; break;
        case 2: s.sightY = 0.063f; s.adsZ = -0.20f; s.adsFov = 41.0f; break;
        case 3: s.sightY = 0.068f; s.adsZ = -0.235f; s.adsFov = 17.0f; s.adsSpeed *= 0.75f; break;
        }
        switch (e[CAT_MAG]) {
        case 1: s.reload = 1.1f; break;
        case 2: s.mag = 40; s.reload = 2.0f; s.adsSpeed *= 0.95f; break;
        case 3: s.mag = 60; s.reload = 2.8f; s.adsSpeed *= 0.8f; break;
        }
    }
    switch (e[CAT_UNDER]) {
    case 1: s.recoil *= 0.8f; break;
    case 2: s.adsSpeed *= 1.3f; s.recoil *= 0.92f; break;
    case 3: s.spreadHip *= 0.55f; break;
    }
    return s;
}
static GunStats computeStats(const int* e) { return computeStatsW(e, g_weapon); }
static GunStats g_gs;

static float pistolSlideFront(const int* e) { return e[CAT_BARREL] == 1 ? -0.13f : e[CAT_BARREL] == 2 ? -0.23f : -0.17f; }
static float partsTipZW(const int* e, int w) {
    if (w == W_PISTOL) {
        static const float pm[NPARTS] = {0.008f, 0.04f, 0.045f, 0.13f};
        return pistolSlideFront(e) - 0.012f - pm[e[CAT_MUZZLE]];
    }
    float tip = e[CAT_BARREL] == 1 ? -0.40f : e[CAT_BARREL] == 2 ? -0.60f : e[CAT_BARREL] == 3 ? -0.48f : -0.46f;
    static const float mlen[NPARTS] = {0.045f, 0.055f, 0.065f, 0.17f};
    return tip - mlen[e[CAT_MUZZLE]];
}
static float partsTipZ(const int* e) { return partsTipZW(e, g_weapon); }

static void selectWeapon(int w) {
    if (w == g_weapon) return;
    g_ammoW[g_weapon] = g_ammo;
    g_weapon = w;
    g_ammo = g_ammoW[w];
    g_reload = -1; g_ads = 0;
    g_gs = computeStats(g_equip);
    if (g_ammo > g_gs.mag) g_ammo = g_gs.mag;
    g_hasGun = g_ownW[w];
}
static void buyWeapon(int w) {
    g_money -= WEAPON_PRICE[w];
    g_ownW[w] = true;
    g_weapon = 1 - w; selectWeapon(w);  // force switch even if already "selected"
    g_ammo = g_gs.mag;
    g_hasGun = true;
}

static void equipPart(int cat, int idx) {
    g_equip[cat] = idx;
    g_gs = computeStats(g_equip);
    if (cat == CAT_MAG) { g_ammo = g_gs.mag; g_reload = -1; }
    if (g_ammo > g_gs.mag) g_ammo = g_gs.mag;
}

// ---------------------------------------------------------------------
//  Shared hitscan trace
// ---------------------------------------------------------------------
struct TraceHit { float t; Vec3 n; int type; int npc; bool head; }; // type 0 none, 1 world, 2 npc, 3 story npc
static TraceHit traceRay(Vec3 eye, Vec3 dir, float maxT) {
    TraceHit h; h.t = maxT; h.n = v3(0, 1, 0); h.type = 0; h.npc = -1; h.head = false;
    for (size_t i = 0; i < g_cols.size(); i++) {
        float t; Vec3 n;
        if (rayAabb(eye, dir, g_cols[i].mn, g_cols[i].mx, h.t, t, n) && t < h.t) { h.t = t; h.n = n; h.type = 1; }
    }
    if (dir.y < -1e-4f) {
        float t = (CURB_H - eye.y) / dir.y;
        Vec3 p = eye + dir * t;
        if (!inBlock(p.x, p.z)) t = (0.0f - eye.y) / dir.y;
        if (t > 0 && t < h.t) { h.t = t; h.n = v3(0, 1, 0); h.type = 1; }
    }
    for (int i = 0; i < NUM_CARS; i++) { // cars: slab test in car space
        const Car& c = g_cars[i];
        float dx0 = c.x - eye.x, dz0 = c.z - eye.z;
        if (dx0 * dx0 + dz0 * dz0 > h.t * h.t + 25.0f) continue;
        float cs = cosf(c.yaw), sn = sinf(c.yaw);
        float lox, loz; carLocal(c, eye.x, eye.z, lox, loz);
        Vec3 lo = v3(lox, eye.y, loz), ld = v3(cs * dir.x - sn * dir.z, dir.y, sn * dir.x + cs * dir.z);
        float mn[3] = {-CAR_HW, 0.0f, -CAR_HL}, mx[3] = {CAR_HW, 1.5f, CAR_HL};
        float t; Vec3 nl;
        if (rayAabb(lo, ld, mn, mx, h.t, t, nl) && t < h.t) {
            h.t = t; h.type = 4; h.npc = i;
            h.n = v3(cs * nl.x + sn * nl.z, nl.y, -sn * nl.x + cs * nl.z);
        }
    }
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i]; if (!n.alive) continue;
        float g = groundHeight(n.x, n.z), hh = 1.78f * n.scale;
        float mn[3] = {n.x - 0.27f, g, n.z - 0.27f}, mx[3] = {n.x + 0.27f, g + hh, n.z + 0.27f};
        float t; Vec3 nn;
        if (rayAabb(eye, dir, mn, mx, h.t, t, nn) && t < h.t) {
            h.t = t; h.n = nn; h.type = 2; h.npc = i;
            h.head = (eye.y + dir.y * t) > g + 1.46f * n.scale;
        }
    }
    Npc* sp[4] = {&g_walt, &g_clerk, &g_rosa, &g_mgr};
    for (int i = 0; i < 4; i++) {
        Npc& n = *sp[i];
        float g = groundHeight(n.x, n.z);
        float mn[3] = {n.x - 0.27f, g, n.z - 0.27f}, mx[3] = {n.x + 0.27f, g + 1.78f, n.z + 0.27f};
        float t; Vec3 nn;
        if (rayAabb(eye, dir, mn, mx, h.t, t, nn) && t < h.t) { h.t = t; h.n = nn; h.type = 3; h.npc = i; }
    }
    return h;
}

// ---------------------------------------------------------------------
//  Cash drops (from downed pedestrians)
// ---------------------------------------------------------------------
struct Cash { float x, z; int amt; float t; bool used; };
static const int MAX_CASH = 32;
static Cash g_cash[MAX_CASH];
static int g_cashNext = 0;
static float g_cashPopT = 0; static int g_cashPopAmt = 0;

static void spawnCash(float x, float z) {
    Cash& c = g_cash[g_cashNext]; g_cashNext = (g_cashNext + 1) % MAX_CASH;
    c.x = x + frange(-0.4f, 0.4f); c.z = z + frange(-0.4f, 0.4f);
    c.amt = 4 + (int)(xrand() % 9); c.t = 0; c.used = true;
}
static void updateCash(float dt) {
    for (int i = 0; i < MAX_CASH; i++) {
        Cash& c = g_cash[i]; if (!c.used) continue;
        c.t += dt;
        if (c.t > 120.0f) { c.used = false; continue; }
        float dx = c.x - P.x, dz = c.z - P.z;
        if (dx * dx + dz * dz < 1.1f * 1.1f && c.t > 0.4f) {
            g_money += c.amt; g_cashPopAmt = c.amt; g_cashPopT = 1.4f; c.used = false;
        }
    }
}

static void fireShot() {
    g_ammo--;
    g_fireCD = g_gs.fireDelay;
    g_flash = 0.05f; g_flashRot = frand() * 6.28f;
    g_recoil = fminf(g_recoil + 1.0f * g_gs.recoil, 2.5f);

    Vec3 eye = v3(P.x, P.y + EYE_HEIGHT, P.z);
    Vec3 f = camForward();
    Vec3 right = v3(cosf(P.yaw), 0, -sinf(P.yaw));
    Vec3 up = cross3(right, f);
    float moving = clampf(sqrtf(P.vx * P.vx + P.vz * P.vz) / WALK_SPEED, 0, 1);
    float spread = lerpf(0.028f * g_gs.spreadHip, 0.0015f * g_gs.spreadAds, g_ads) + g_bloom
                 + moving * 0.02f * (1.0f - g_ads * 0.8f) + (P.ground ? 0 : 0.04f);
    float ang = frand() * 6.28f, rad = sqrtf(frand()) * spread;
    Vec3 dir = norm3(f + right * (cosf(ang) * rad) + up * (sinf(ang) * rad));
    g_bloom = fminf(g_bloom + lerpf(0.006f, 0.0025f, g_ads) * g_gs.bloom, 0.05f);

    // view kick
    P.pitch += lerpf(0.016f, 0.009f, g_ads) * g_gs.recoil;
    P.yaw += frange(-1, 1) * lerpf(0.006f, 0.003f, g_ads) * g_gs.recoil;

    // trace
    TraceHit th = traceRay(eye, dir, 300.0f);
    float bestT = th.t; Vec3 bestN = th.n; int hitType = th.type, hitNpc = th.npc; bool head = th.head;
    Npc* sp[4] = {&g_walt, &g_clerk, &g_rosa, &g_mgr};
    Vec3 hp = eye + dir * bestT;
    if (hitType == 3) {
        sp[hitNpc]->flinch = 1.0f;
        for (int k = 0; k < 6; k++)
            spawnParticle(hp, v3(frange(-1, 1), frange(0.2f, 1.5f), frange(-1, 1)), 0.3f, 0.05f, 6.0f, col4(0.55f, 0.02f, 0.02f, 1));
        g_hitMarker = 0.18f; g_hitKill = false;
    } else if (hitType == 2) {
        Npc& n = g_npcs[hitNpc];
        n.health -= head ? 100.0f : 34.0f * g_gs.dmg;
        Vec3 fwd = v3(-sinf(n.yaw), 0, -cosf(n.yaw));
        n.fallDir = dot3(dir, fwd) < 0 ? 1.0f : -1.0f;
        n.flinch = 1.0f;
        for (int k = 0; k < 10; k++)
            spawnParticle(hp, v3(frange(-1.2f, 1.2f), frange(0.2f, 2.0f), frange(-1.2f, 1.2f)) - dir * 1.5f,
                          frange(0.25f, 0.5f), frange(0.04f, 0.09f), 6.0f, col4(0.55f, 0.02f, 0.02f, 1));
        g_hitMarker = 0.18f;
        g_hitKill = n.health <= 0;
        if (n.health <= 0) { n.alive = false; n.deadT = 0; n.fall = 0; spawnCash(n.x, n.z); }
        panicAround(n.x, n.z, 45.0f * fmaxf(g_gs.panic, 0.5f));
    } else if (hitType == 4) { // car: sparks, no decal (it moves)
        for (int k = 0; k < 6; k++)
            spawnParticle(hp + bestN * 0.05f, bestN * frange(1.0f, 3.0f) + v3(frange(-1.5f, 1.5f), frange(0.5f, 2.0f), frange(-1.5f, 1.5f)),
                          frange(0.15f, 0.35f), 0.03f, 9.0f, col4(1.0f, 0.8f, 0.35f, 1));
    } else if (hitType == 1) {
        addDecal(hp, bestN);
        for (int k = 0; k < 7; k++) {
            Vec3 v = bestN * frange(1.0f, 3.0f) + v3(frange(-1.5f, 1.5f), frange(0.0f, 1.5f), frange(-1.5f, 1.5f));
            float g = 0.55f + frand() * 0.2f;
            spawnParticle(hp + bestN * 0.05f, v, frange(0.25f, 0.6f), frange(0.04f, 0.1f), 7.0f, col4(g, g * 0.97f, g * 0.9f, 0.9f));
        }
        spawnParticle(hp + bestN * 0.05f, bestN * 3.0f, 0.06f, 0.12f, 0, col4(1.0f, 0.85f, 0.4f, 1));
    }
    panicAround(P.x, P.z, 32.0f * g_gs.panic);
}

// ---------------------------------------------------------------------
//  Lawn mowing quest
// ---------------------------------------------------------------------
static void initLawn() {
    g_lawnTotal = 0; g_lawnCut = 0;
    for (int y = 0; y < LAWN_H; y++)
        for (int x = 0; x < LAWN_W; x++) {
            float cx = LAWN_X0 + (x + 0.5f) * LAWN_CS;
            bool path = cx > 179.0f && cx < 181.0f;
            g_lawn[y][x] = path ? 0 : 1;
            if (!path) g_lawnTotal++;
        }
    g_lawnDirty = true;
}

static void buildLawnMesh() {
    g_lawnMesh.clear();
    const float yT = CURB_H + 0.24f, yC = CURB_H + 0.025f;
    Col tall = col4(0.60f, 0.78f, 0.52f);
    for (int y = 0; y < LAWN_H; y++) {
        float z0 = LAWN_Z0 + y * LAWN_CS, z1 = z0 + LAWN_CS;
        int x = 0;
        while (x < LAWN_W) {
            int st = g_lawn[y][x], e = x;
            while (e < LAWN_W && g_lawn[y][e] == st) e++;
            float x0 = LAWN_X0 + x * LAWN_CS, x1 = LAWN_X0 + e * LAWN_CS;
            if (st == 1) {
                topQuad(g_lawnMesh, x0, z0, x1, z1, yT, 0.3f, tall);
                sideFaces(g_lawnMesh, x0, z0, x1, z1, CURB_H, yT, -3.3f, -3.3f, tall);
            } else if (st == 2) {
                Col cut = ((y / 2) % 2) ? col4(1.0f, 1.0f, 0.92f) : col4(0.86f, 0.92f, 0.80f);
                topQuad(g_lawnMesh, x0, z0, x1, z1, yC, 0.3f, cut);
            }
            x = e;
        }
    }
    g_lawnDirty = false;
}

static int cutLawn(float cx, float cz, float r) {
    int gx0 = (int)floorf((cx - r - LAWN_X0) / LAWN_CS), gx1 = (int)floorf((cx + r - LAWN_X0) / LAWN_CS);
    int gz0 = (int)floorf((cz - r - LAWN_Z0) / LAWN_CS), gz1 = (int)floorf((cz + r - LAWN_Z0) / LAWN_CS);
    if (gx0 < 0) gx0 = 0;
    if (gz0 < 0) gz0 = 0;
    if (gx1 >= LAWN_W) gx1 = LAWN_W - 1;
    if (gz1 >= LAWN_H) gz1 = LAWN_H - 1;
    int n = 0;
    for (int y = gz0; y <= gz1; y++)
        for (int x = gx0; x <= gx1; x++) {
            if (g_lawn[y][x] != 1) continue;
            float px = LAWN_X0 + (x + 0.5f) * LAWN_CS - cx, pz = LAWN_Z0 + (y + 0.5f) * LAWN_CS - cz;
            if (px * px + pz * pz <= r * r) { g_lawn[y][x] = 2; n++; }
        }
    g_lawnCut += n;
    if (n) g_lawnDirty = true;
    return n;
}

static float lawnPercent() { return g_lawnTotal ? 100.0f * g_lawnCut / g_lawnTotal : 0.0f; }

static void updateMower(float dt) {
    if (!g_mowing) return;
    float fx = -sinf(P.yaw), fz = -cosf(P.yaw);
    g_mowerPos = v3(P.x + fx * 1.0f, 0, P.z + fz * 1.0f);
    g_mowerPos.y = groundHeight(g_mowerPos.x, g_mowerPos.z);
    g_mowerYaw = P.yaw;
    int n = cutLawn(g_mowerPos.x, g_mowerPos.z, 0.42f);
    for (int k = 0; k < n * 2 && k < 8; k++)
        spawnParticle(v3(g_mowerPos.x + frange(-0.3f, 0.3f), g_mowerPos.y + 0.25f, g_mowerPos.z + frange(-0.3f, 0.3f)),
                      v3(frange(-1.5f, 1.5f), frange(0.8f, 2.2f), frange(-1.5f, 1.5f)), frange(0.3f, 0.6f), 0.035f, 8.0f,
                      col4(0.35f, 0.62f, 0.25f, 1));
    (void)dt;
    if (g_q1 == 1 && lawnPercent() >= 90.0f) {
        // finish the job: whole lawn shows as cut
        for (int y = 0; y < LAWN_H; y++) for (int x = 0; x < LAWN_W; x++) if (g_lawn[y][x] == 1) g_lawn[y][x] = 2;
        g_lawnCut = g_lawnTotal; g_lawnDirty = true;
        g_q1 = 2; g_money += 25; g_mowing = false;
        if (g_q2 == 0) g_q2 = 1;
        toast("LAWN MOWED!  +$25", "NEW QUEST: GEAR UP");
    }
}

static void buildMower(Mesh& m) {
    const Vec3 L = WORLD_LIGHT;
    Mat4 M = mMul(mTrans(g_mowerPos.x, g_mowerPos.y, g_mowerPos.z), mRotY(g_mowerYaw));
    Col red = col4(0.78f, 0.12f, 0.08f), blk = col4(0.12f, 0.12f, 0.12f), metal = col4(0.55f, 0.56f, 0.58f);
    xbox(m, M, v3(-0.30f, 0.08f, -0.36f), v3(0.30f, 0.24f, 0.30f), red, L);        // deck
    xbox(m, M, v3(-0.15f, 0.24f, -0.20f), v3(0.15f, 0.46f, 0.08f), blk, L);        // engine
    xbox(m, M, v3(-0.06f, 0.46f, -0.12f), v3(0.06f, 0.50f, 0.0f), metal, L);       // cap
    xbox(m, M, v3(-0.19f, 0.14f, 0.30f), v3(0.19f, 0.46f, 0.70f), col4(0.22f, 0.32f, 0.18f), L); // grass bag
    for (int i = 0; i < 4; i++) {
        float sx = (i & 1) ? 1.0f : -1.0f, z = (i & 2) ? 0.24f : -0.28f;
        xbox(m, M, v3(sx > 0 ? 0.30f : -0.36f, 0.0f, z - 0.09f), v3(sx > 0 ? 0.36f : -0.30f, 0.18f, z + 0.09f), blk, L);
    }
    Vec3 hl0 = mApply(M, v3(-0.22f, 0.24f, 0.28f)), hl1 = mApply(M, v3(-0.22f, 0.95f, 0.92f));
    Vec3 hr0 = mApply(M, v3(0.22f, 0.24f, 0.28f)), hr1 = mApply(M, v3(0.22f, 0.95f, 0.92f));
    beam(m, hl0, hl1, 0.016f, metal, L);
    beam(m, hr0, hr1, 0.016f, metal, L);
    beam(m, mApply(M, v3(-0.24f, 0.95f, 0.92f)), mApply(M, v3(0.24f, 0.95f, 0.92f)), 0.02f, blk, L);
    if (g_mowing) { // gloved hands on the bar
        Col glove = col4(0.12f, 0.11f, 0.10f);
        xbox(m, M, v3(-0.21f, 0.92f, 0.88f), v3(-0.13f, 0.99f, 0.96f), glove, L);
        xbox(m, M, v3(0.13f, 0.92f, 0.88f), v3(0.21f, 0.99f, 0.96f), glove, L);
    }
}

// ---------------------------------------------------------------------
//  Paint job: Rosa's living room walls
// ---------------------------------------------------------------------
static const int PW_NU_MAX = 31, PW_NV = 6;
struct PaintWall { float ox, oz, ux, uz, nx, nz, shade; int nu; };
static const PaintWall PWALLS[4] = {
    {RM_X0, RM_Z0, 1, 0, 0, 1, 0.88f, 31},   // front (has the door)
    {RM_X0, RM_Z1, 1, 0, 0, -1, 1.00f, 31},  // back
    {RM_X0, RM_Z0, 0, 1, 1, 0, 0.82f, 23},   // left
    {RM_X1, RM_Z0, 0, 1, -1, 0, 0.94f, 23},  // right
};
static unsigned char g_paint[4][PW_NU_MAX][PW_NV]; // 255 none, 0 old, 1..N painted color
static int g_paintTotal = 0, g_paintDone = 0;
static bool g_paintDirty = true;
static Mesh g_paintMesh;
static int g_paintColor = 1;
static bool g_rolling = false, g_rollHit = false;
static float g_rollAnim = 0;
static const int NPAINT = 6;
static const char* PAINT_NAMES[NPAINT + 1] = {"", "SKY BLUE", "SAGE", "BUTTER", "CORAL", "LAVENDER", "WHITE"};
static const Col PAINT_COLS[NPAINT + 1] = {
    {0.72f, 0.66f, 0.55f, 1}, {0.56f, 0.76f, 0.95f, 1}, {0.62f, 0.78f, 0.60f, 1}, {0.98f, 0.90f, 0.56f, 1},
    {0.98f, 0.62f, 0.52f, 1}, {0.76f, 0.66f, 0.93f, 1}, {0.97f, 0.97f, 0.95f, 1}
};

static void initPaint() {
    g_paintTotal = 0; g_paintDone = 0;
    for (int w = 0; w < 4; w++)
        for (int u = 0; u < PW_NU_MAX; u++)
            for (int v = 0; v < PW_NV; v++) {
                unsigned char st = 0;
                if (u >= PWALLS[w].nu) st = 255;
                float uc = (u + 0.5f) * PAINT_CS, vc = CURB_H + (v + 0.5f) * PAINT_CS;
                if (w == 0 && RM_X0 + uc > RDOOR_X0 && RM_X0 + uc < RDOOR_X1 && vc < RDOOR_Y) st = 255;
                g_paint[w][u][v] = st;
                if (st == 0) g_paintTotal++;
            }
    g_paintDirty = true;
}

static float paintPercent() { return g_paintTotal ? 100.0f * g_paintDone / g_paintTotal : 0.0f; }

static void buildPaintMesh() {
    g_paintMesh.clear();
    for (int w = 0; w < 4; w++) {
        const PaintWall& pw = PWALLS[w];
        for (int v = 0; v < PW_NV; v++) {
            float y0 = CURB_H + v * PAINT_CS, y1 = y0 + PAINT_CS;
            int u = 0;
            while (u < pw.nu) {
                int st = g_paint[w][u][v], e = u + 1;
                if (st != 0 && st != 255) while (e < pw.nu && g_paint[w][e][v] == st) e++; // merge runs of fresh paint
                if (st != 255) {
                    Col c;
                    if (st == 0) { // old, grimy wall: per-cell variation and stains
                        float hsh = hash2(w * 64 + u, v, 77);
                        c = shadeC(PAINT_COLS[0], 0.82f + 0.18f * hsh);
                        if (hsh > 0.86f) c = shadeC(c, 0.78f);
                    } else c = PAINT_COLS[st];
                    c = shadeC(c, pw.shade);
                    float a0 = u * PAINT_CS, a1 = e * PAINT_CS, off = 0.006f;
                    Vec3 o = v3(pw.ox + pw.nx * off, 0, pw.oz + pw.nz * off);
                    Vec3 p0 = v3(o.x + pw.ux * a0, y0, o.z + pw.uz * a0), p1 = v3(o.x + pw.ux * a1, y0, o.z + pw.uz * a1);
                    quad(g_paintMesh, p0, p1, v3(p1.x, y1, p1.z), v3(p0.x, y1, p0.z), 0, 0, 1, 1, c);
                }
                u = e;
            }
        }
    }
    g_paintDirty = false;
}

static inline bool inPaintRoom(float x, float z) { return x > RM_X0 && x < RM_X1 && z > RM_Z0 && z < RM_Z1; }

// find the wall point the camera is aiming at (within reach)
static bool paintAim(Vec3 eye, Vec3 dir, int& wOut, float& uOut, float& yOut, Vec3& hitOut) {
    const float REACH = 2.8f;
    float best = REACH; int bw = -1; float bu = 0, by = 0;
    for (int w = 0; w < 4; w++) {
        const PaintWall& pw = PWALLS[w];
        float dn = dir.x * pw.nx + dir.z * pw.nz;
        if (dn >= -1e-4f) continue;
        float t = ((pw.ox - eye.x) * pw.nx + (pw.oz - eye.z) * pw.nz) / dn;
        if (t <= 0 || t >= best) continue;
        Vec3 h = eye + dir * t;
        float u = (h.x - pw.ox) * pw.ux + (h.z - pw.oz) * pw.uz;
        if (u < 0 || u > pw.nu * PAINT_CS || h.y < CURB_H || h.y > CURB_H + PW_NV * PAINT_CS) continue;
        best = t; bw = w; bu = u; by = h.y;
    }
    if (bw < 0) return false;
    if (dir.y < -1e-4f && (CURB_H - eye.y) / dir.y < best) return false; // floor in the way
    if (dir.y > 1e-4f && (RM_CEIL - eye.y) / dir.y < best) return false;  // ceiling in the way
    wOut = bw; uOut = bu; yOut = by; hitOut = eye + dir * best;
    return true;
}

static void paintAt(int w, float u, float y, float r) {
    const PaintWall& pw = PWALLS[w];
    int newly = 0;
    for (int iu = 0; iu < pw.nu; iu++)
        for (int iv = 0; iv < PW_NV; iv++) {
            unsigned char& c = g_paint[w][iu][iv];
            if (c == 255) continue;
            float du = (iu + 0.5f) * PAINT_CS - u, dv = CURB_H + (iv + 0.5f) * PAINT_CS - y;
            if (du * du + dv * dv > r * r) continue;
            if (c != g_paintColor) { if (c == 0) newly++; c = (unsigned char)g_paintColor; g_paintDirty = true; }
        }
    g_paintDone += newly;
    if (g_q3 == 1 && paintPercent() >= 90.0f) {
        for (int ww = 0; ww < 4; ww++) for (int iu = 0; iu < PW_NU_MAX; iu++) for (int iv = 0; iv < PW_NV; iv++)
            if (g_paint[ww][iu][iv] == 0) g_paint[ww][iu][iv] = (unsigned char)g_paintColor;
        g_paintDone = g_paintTotal; g_paintDirty = true;
        g_q3 = 2; g_money += 40;
        toast("WALLS PAINTED!  +$40", "ROSA LOVES IT");
    }
}

static void updatePainting(float dt, uint32_t btn, uint32_t pressed) {
    g_rolling = (g_q3 == 1) && inPaintRoom(P.x, P.z) && !g_mowing;
    g_rollHit = false;
    if (!g_rolling) { g_rollAnim = approach(g_rollAnim, 0, 10.0f, dt); return; }
    if (pressed & SCE_CTRL_LEFT)  g_paintColor = (g_paintColor + NPAINT - 2) % NPAINT + 1;
    if (pressed & SCE_CTRL_RIGHT) g_paintColor = g_paintColor % NPAINT + 1;
    Vec3 eye = v3(P.x, P.y + EYE_HEIGHT, P.z);
    int w; float u, y; Vec3 hp;
    g_rollHit = paintAim(eye, camForward(), w, u, y, hp);
    bool painting = g_rollHit && (btn & SCE_CTRL_RTRIGGER);
    g_rollAnim = approach(g_rollAnim, painting ? 1.0f : 0.0f, 12.0f, dt);
    if (painting) {
        paintAt(w, u, y, 0.46f);
        if (frand() < 0.3f) {
            const PaintWall& pw = PWALLS[w];
            spawnParticle(hp + v3(pw.nx, 0, pw.nz) * 0.05f, v3(frange(-0.3f, 0.3f), frange(-0.5f, 0.2f), frange(-0.3f, 0.3f)),
                          0.5f, 0.025f, 5.0f, PAINT_COLS[g_paintColor]);
        }
    }
}

static void buildRoller(Mesh& m) {
    const Vec3 L = norm3(v3(0.35f, 0.85f, 0.45f));
    float bob = P.moveAmt;
    float bx = sinf(P.bobPhase) * 0.012f * bob, byb = -fabsf(cosf(P.bobPhase)) * 0.01f * bob;
    float stroke = sinf(g_time * 9.0f) * 0.05f * g_rollAnim;
    Vec3 C = v3(0.06f + bx, -0.10f + byb + stroke, -0.56f + 0.06f - g_rollAnim * 0.08f);
    Vec3 grip = v3(0.24f + bx, -0.42f + byb + stroke * 0.5f, -0.22f);
    Vec3 elbow = v3(C.x + 0.15f, C.y - 0.02f, C.z + 0.05f);
    Col metal = col4(0.6f, 0.6f, 0.62f);
    beam(m, grip, elbow, 0.009f, metal, L);
    beam(m, elbow, v3(C.x + 0.13f, C.y, C.z), 0.008f, metal, L);
    beam(m, grip, grip + v3(0.05f, -0.14f, 0.12f), 0.02f, col4(0.75f, 0.2f, 0.15f), L); // handle
    Mat4 RC = mTrans(C.x, C.y, C.z);
    xbox(m, RC, v3(-0.12f, -0.035f, -0.035f), v3(0.12f, 0.035f, 0.035f), PAINT_COLS[g_paintColor], L);
    Mat4 RCr = mMul(RC, mRotX(0.785f));
    xbox(m, RCr, v3(-0.12f, -0.035f, -0.035f), v3(0.12f, 0.035f, 0.035f), shadeC(PAINT_COLS[g_paintColor], 0.92f), L);
    // gloved hand + sleeve
    xbox(m, mTrans(grip.x, grip.y, grip.z), v3(-0.03f, -0.035f, -0.04f), v3(0.03f, 0.035f, 0.04f), col4(0.12f, 0.11f, 0.10f), L);
    beam(m, grip, grip + v3(0.12f, -0.3f, 0.3f), 0.042f, col4(0.24f, 0.28f, 0.20f), L);
}

// ---------------------------------------------------------------------
//  Barista job: hold X to pour, release at the line
// ---------------------------------------------------------------------
struct DrinkDef { const char* name; float w, h; };
static const DrinkDef DRINKS[5] = {{"ESPRESSO", 92, 104}, {"AMERICANO", 120, 160}, {"LATTE", 100, 205}, {"CAPPUCCINO", 140, 140}, {"MOCHA", 112, 176}};
static const int SHIFT_CUPS = 8;
struct BaristaState {
    int cup, drink, phase;           // phase 0 ready, 1 pouring, 2 showing result, 3 shift summary
    float level, line, rate, rateTarget, rateTimer, resultT;
    int earned, perfects, misses, lastPay, tips;
    const char* resultText;
    bool spilled;
};
static BaristaState g_bar;

static void baristaNewCup() {
    g_bar.drink = (int)(xrand() % 5);
    g_bar.line = frange(0.45f, 0.86f);
    g_bar.level = 0; g_bar.phase = 0; g_bar.spilled = false;
    g_bar.rate = 0.3f; g_bar.rateTarget = 0.3f; g_bar.rateTimer = 0;
}
static void baristaStart() {
    memset(&g_bar, 0, sizeof(g_bar));
    g_bar.cup = 1;
    baristaNewCup();
    g_ui = UI_BARISTA;
}
static void baristaFinishShift(bool quit) {
    int pay = g_bar.earned + (quit ? 0 : g_bar.tips);
    g_money += pay;
    if (!quit) { g_shifts++; if (pay > g_bestShift) g_bestShift = pay; }
    char a[48]; snprintf(a, sizeof(a), quit ? "SHIFT ENDED EARLY  +$%d" : "SHIFT DONE  +$%d", pay);
    toast(a, quit ? "NO TIPS FOR QUITTING" : "COME BACK ANY TIME");
    g_ui = UI_NONE;
}
static void baristaScore() {
    float d = (g_bar.level - g_bar.line) * 100.0f, ad = fabsf(d);
    if (g_bar.spilled)      { g_bar.resultText = "SPILLED!"; g_bar.lastPay = 0; g_bar.misses++; }
    else if (ad <= 3.0f)    { g_bar.resultText = "PERFECT!"; g_bar.lastPay = 3; g_bar.perfects++; }
    else if (ad <= 7.0f)    { g_bar.resultText = "GREAT"; g_bar.lastPay = 2; }
    else if (ad <= 12.0f)   { g_bar.resultText = "OKAY"; g_bar.lastPay = 1; }
    else                    { g_bar.resultText = d > 0 ? "TOO MUCH" : "TOO LITTLE"; g_bar.lastPay = 0; g_bar.misses++; }
    g_bar.earned += g_bar.lastPay;
    g_bar.phase = 2; g_bar.resultT = 1.4f;
}
static void baristaUpdate(float dt, uint32_t btn, uint32_t pressed) {
    bool holdX = (btn & SCE_CTRL_CROSS) != 0;
    if (g_bar.phase == 3) { // summary
        if (pressed & (SCE_CTRL_CROSS | SCE_CTRL_CIRCLE)) baristaFinishShift(false);
        return;
    }
    if ((pressed & SCE_CTRL_CIRCLE) && g_bar.phase != 1) { baristaFinishShift(true); return; }
    if (g_bar.phase == 0 && (pressed & SCE_CTRL_CROSS)) g_bar.phase = 1;
    if (g_bar.phase == 1) {
        // the machine speeds up and slows down at random
        g_bar.rateTimer -= dt;
        if (g_bar.rateTimer <= 0) { g_bar.rateTarget = 0.30f * frange(0.3f, 2.2f); g_bar.rateTimer = frange(0.2f, 0.7f); }
        g_bar.rate = approach(g_bar.rate, g_bar.rateTarget, 9.0f, dt);
        g_bar.level += g_bar.rate * dt;
        if (g_bar.level >= 1.0f) { g_bar.level = 1.0f; g_bar.spilled = true; baristaScore(); }
        else if (!holdX) baristaScore();
    } else if (g_bar.phase == 2) {
        g_bar.resultT -= dt;
        if (g_bar.resultT <= 0) {
            if (g_bar.cup >= SHIFT_CUPS) {
                g_bar.tips = g_bar.perfects + (g_bar.misses == 0 ? 3 : 0);
                g_bar.phase = 3;
            } else { g_bar.cup++; baristaNewCup(); }
        }
    }
}
static void drawBarista(Mesh& h) {
    char buf[64];
    // backdrop: tiled wall, counter
    for (int b = 0; b < 14; b++) {
        float t = b / 13.0f;
        rect2(h, 0, SCR_H * b / 14.0f, SCR_W, SCR_H / 14.0f + 1, col4(lerpf(0.30f, 0.22f, t), lerpf(0.24f, 0.17f, t), lerpf(0.18f, 0.12f, t)));
    }
    rect2(h, 0, 452, SCR_W, 92, col4(0.42f, 0.28f, 0.17f));
    rect2(h, 0, 446, SCR_W, 8, col4(0.82f, 0.80f, 0.76f));
    // espresso machine
    const float cx = SCR_W * 0.5f;
    rect2(h, cx - 170, 40, 340, 120, col4(0.72f, 0.73f, 0.75f));
    rect2(h, cx - 170, 40, 340, 14, col4(0.15f, 0.15f, 0.16f));
    rect2(h, cx - 150, 70, 60, 34, col4(0.15f, 0.15f, 0.16f));
    text2(h, cx - 144, 80, 2, g_bar.phase == 1 ? "BREW" : "READY", g_bar.phase == 1 ? col4(1, 0.5f, 0.2f) : col4(0.4f, 1, 0.5f), false);
    rect2(h, cx - 30, 160, 60, 22, col4(0.20f, 0.20f, 0.21f));  // group head
    rect2(h, cx - 8, 182, 16, 14, col4(0.35f, 0.35f, 0.37f));   // spout
    if (g_bar.phase == 3) {
        rect2(h, cx - 260, 210, 520, 210, col4(0, 0, 0, 0.7f));
        textC(h, cx, 226, 4, "SHIFT COMPLETE", col4(1, 0.85f, 0.3f));
        snprintf(buf, sizeof(buf), "CUPS PAY      $%d", g_bar.earned); text2(h, cx - 200, 280, 3, buf, col4(1, 1, 1));
        snprintf(buf, sizeof(buf), "TIPS          $%d", g_bar.tips);   text2(h, cx - 200, 312, 3, buf, col4(1, 1, 1));
        snprintf(buf, sizeof(buf), "PERFECT POURS %d / %d", g_bar.perfects, SHIFT_CUPS); text2(h, cx - 200, 344, 3, buf, col4(0.8f, 0.9f, 1));
        textC(h, cx, 390, 2, "X  COLLECT PAY", col4(1, 1, 1, 0.8f));
        return;
    }
    // cup
    const DrinkDef& d = DRINKS[g_bar.drink];
    float cw = d.w, ch = d.h, bot = 444, top = bot - ch, x0 = cx - cw * 0.5f;
    Col cer = col4(0.97f, 0.96f, 0.93f);
    rect2(h, x0 - 8, top, 8, ch, cer); rect2(h, x0 + cw, top, 8, ch, cer); rect2(h, x0 - 8, bot - 8, cw + 16, 8, cer);
    rect2(h, x0 + cw + 8, top + ch * 0.25f, 26, 8, cer); rect2(h, x0 + cw + 26, top + ch * 0.25f, 8, ch * 0.4f, cer);
    rect2(h, x0 + cw + 8, top + ch * 0.65f - 8, 26, 8, cer);
    rect2(h, x0, top, cw, ch - 8, col4(0.20f, 0.18f, 0.17f));          // empty inside
    float inner = ch - 8, lv = clampf(g_bar.level, 0, 1);
    float fy = bot - 8 - inner * lv;
    if (lv > 0) {
        rect2(h, x0, fy, cw, inner * lv, col4(0.33f, 0.18f, 0.08f));
        rect2(h, x0, fy, cw, fminf(6.0f, inner * lv), col4(0.78f, 0.55f, 0.32f)); // crema
    }
    if (g_bar.spilled) rect2(h, x0 - 50, bot - 4, cw + 100, 6, col4(0.33f, 0.18f, 0.08f));
    // the fill line
    float ly = bot - 8 - inner * g_bar.line;
    for (float lx = x0 - 18; lx < x0 + cw + 18; lx += 12) rect2(h, lx, ly - 1.5f, 8, 3, col4(1, 0.25f, 0.2f));
    text2(h, x0 + cw + 44, ly - 7, 2, "FILL LINE", col4(1, 0.4f, 0.35f));
    // stream (thicker when the machine runs fast)
    if (g_bar.phase == 1) {
        float sw = 3 + g_bar.rate * 14, wob = sinf(g_time * 40.0f) * 1.5f;
        rect2(h, cx - sw * 0.5f + wob, 196, sw, fy - 196, col4(0.38f, 0.21f, 0.09f));
    }
    // header + footer
    snprintf(buf, sizeof(buf), "CUP %d/%d   %s", g_bar.cup, SHIFT_CUPS, d.name);
    text2(h, 24, 14, 3, buf, col4(1, 1, 1));
    snprintf(buf, sizeof(buf), "EARNED $%d", g_bar.earned);
    text2(h, SCR_W - 24 - textWidth(buf, 3), 14, 3, buf, col4(0.45f, 1.0f, 0.55f));
    if (g_bar.phase == 2) {
        snprintf(buf, sizeof(buf), "%s  +$%d", g_bar.resultText, g_bar.lastPay);
        Col rc = g_bar.lastPay >= 3 ? col4(0.4f, 1, 0.5f) : (g_bar.lastPay > 0 ? col4(1, 0.9f, 0.4f) : col4(1, 0.35f, 0.3f));
        textC(h, cx, 230, 5, buf, rc);
    }
    textC(h, cx, SCR_H - 30, 2, g_bar.phase == 1 ? "LET GO OF X AT THE LINE!" : "HOLD X TO POUR - RELEASE AT THE LINE     O  END SHIFT",
          col4(1, 1, 1, 0.85f));
}

// ---------------------------------------------------------------------
//  Story NPCs, dialog, interaction
// ---------------------------------------------------------------------
static void initStoryNpcs() {
    Npc* sp[4] = {&g_walt, &g_clerk, &g_rosa, &g_mgr};
    for (int i = 0; i < 4; i++) {
        Npc& n = *sp[i];
        memset(&n, 0, sizeof(n));
        n.alive = true; n.health = 100; n.scale = 1.0f; n.fallDir = 1; n.node = 0; n.target = 0;
        n.shoes = col4(0.1f, 0.1f, 0.1f);
    }
    g_walt.x = WALT_X; g_walt.z = WALT_Z; g_walt.yaw = 0;
    g_walt.shirt = col4(0.62f, 0.16f, 0.14f); g_walt.pants = col4(0.66f, 0.58f, 0.42f);
    g_walt.skin = col4(0.93f, 0.76f, 0.63f); g_walt.hair = col4(0.62f, 0.62f, 0.62f); g_walt.scale = 1.02f;
    g_rosa.x = ROSA_X; g_rosa.z = ROSA_Z; g_rosa.yaw = 0;
    g_rosa.shirt = col4(0.20f, 0.55f, 0.60f); g_rosa.pants = col4(0.18f, 0.18f, 0.30f);
    g_rosa.skin = col4(0.80f, 0.60f, 0.45f); g_rosa.hair = col4(0.20f, 0.10f, 0.06f); g_rosa.scale = 0.96f;
    g_clerk.x = CLERK_X; g_clerk.z = CLERK_Z; g_clerk.yaw = 0;
    g_mgr.x = MGR_X; g_mgr.z = MGR_Z; g_mgr.yaw = 0;
    g_mgr.shirt = col4(0.15f, 0.40f, 0.28f); g_mgr.pants = col4(0.12f, 0.12f, 0.12f);
    g_mgr.skin = col4(0.93f, 0.78f, 0.66f); g_mgr.hair = col4(0.55f, 0.30f, 0.12f); g_mgr.scale = 0.98f;
    g_clerk.shirt = col4(0.12f, 0.12f, 0.13f); g_clerk.pants = col4(0.30f, 0.30f, 0.26f);
    g_clerk.skin = col4(0.66f, 0.46f, 0.32f); g_clerk.hair = col4(0.08f, 0.06f, 0.05f);
}

static void faceStoryNpc(Npc& n, float dt) {
    float dx = P.x - n.x, dz = P.z - n.z;
    if (dx * dx + dz * dz < 64.0f) {
        float want = atan2f(-dx, -dz);
        n.yaw += wrapAngle(want - n.yaw) * fminf(1.0f, dt * 5.0f);
    }
    if (n.flinch > 0) n.flinch = fmaxf(0, n.flinch - dt * 4.0f);
}

static void openDialog(int d) { g_dlg = d; g_ui = UI_DIALOG; }

static void dialogText(const char** name, const char** lines, int* n, const char** opts) {
    static char buf[2][48];
    *n = 0;
    switch (g_dlg) {
    case DLG_WALT_OFFER:
        *name = "WALT";
        lines[(*n)++] = "HEY NEIGHBOR! MY BACK IS SHOT AND";
        lines[(*n)++] = "THE YARD IS A JUNGLE. COULD YOU";
        lines[(*n)++] = "MOW MY LAWN? I'LL PAY YOU $25.";
        *opts = "X  SURE THING        O  NO THANKS"; break;
    case DLG_WALT_ACTIVE:
        *name = "WALT";
        lines[(*n)++] = "THE MOWER IS BY THE HOUSE.";
        lines[(*n)++] = "GET AT LEAST 90% OF THE GRASS";
        lines[(*n)++] = "AND THE $25 IS YOURS.";
        *opts = "X  OK"; break;
    case DLG_WALT_DONE:
        *name = "WALT";
        lines[(*n)++] = "LOOKS GREAT, THANKS AGAIN!";
        lines[(*n)++] = "IF THAT CASH IS BURNING A HOLE";
        lines[(*n)++] = "IN YOUR POCKET, THE GUN STORE";
        lines[(*n)++] = "IS ON YOUR PHONE MAP.";
        *opts = "X  OK"; break;
    case DLG_STORE_BUY: {
        static char l1[48], l2[48], o[64];
        *name = "GUN STORE CLERK";
        lines[(*n)++] = "WELCOME IN. WHAT CAN I GET YOU?";
        snprintf(l1, sizeof(l1), "RIFLE   30 RD AUTO     %s", g_ownW[0] ? "OWNED" : "$25");
        snprintf(l2, sizeof(l2), "PISTOL  12 RD SEMI     %s", g_ownW[1] ? "OWNED" : "$15");
        lines[(*n)++] = l1; lines[(*n)++] = l2;
        snprintf(buf[0], sizeof(buf[0]), "YOU HAVE $%d.", g_money);
        lines[(*n)++] = buf[0];
        snprintf(o, sizeof(o), "%s%sO  LEAVE", g_ownW[0] ? "" : "X  RIFLE   ", g_ownW[1] ? "" : "SQUARE  PISTOL   ");
        *opts = o; break; }
    case DLG_STORE_BROKE:
        *name = "GUN STORE CLERK";
        lines[(*n)++] = "THE RIFLE IS $25.";
        snprintf(buf[1], sizeof(buf[1]), "YOU'VE GOT $%d. COME BACK", g_money);
        lines[(*n)++] = buf[1];
        lines[(*n)++] = "WHEN YOU HAVE THE CASH.";
        *opts = "X  OK"; break;
    case DLG_CAFE_APPLY:
        *name = "CAFE MANAGER";
        lines[(*n)++] = "WE'RE HIRING BARISTAS. YOU GET PAID";
        lines[(*n)++] = "PER CUP: POUR RIGHT TO THE LINE.";
        lines[(*n)++] = "THE MACHINE IS MOODY. WANT THE JOB?";
        *opts = "X  APPLY        O  NO THANKS"; break;
    case DLG_CAFE_WORK:
        *name = "CAFE MANAGER";
        lines[(*n)++] = "THE MACHINE IS ALL YOURS. WORK A";
        lines[(*n)++] = "SHIFT WHENEVER YOU NEED CASH.";
        lines[(*n)++] = "PERFECT POURS EARN TIPS.";
        *opts = "X  OK"; break;
    case DLG_ROSA_OFFER:
        *name = "ROSA";
        lines[(*n)++] = "HI! I JUST MOVED IN AND THE LIVING";
        lines[(*n)++] = "ROOM WALLS ARE GROSS. COULD YOU";
        lines[(*n)++] = "PAINT THEM FOR ME? I'LL PAY $40.";
        *opts = "X  HAPPY TO HELP      O  NOT NOW"; break;
    case DLG_ROSA_ACTIVE:
        *name = "ROSA";
        lines[(*n)++] = "THE ROLLER AND PAINT ARE INSIDE.";
        lines[(*n)++] = "PICK ANY COLOR YOU LIKE. COVER";
        lines[(*n)++] = "AT LEAST 90% OF THE WALLS.";
        *opts = "X  OK"; break;
    case DLG_ROSA_DONE:
        *name = "ROSA";
        lines[(*n)++] = "IT LOOKS AMAZING IN THERE!";
        lines[(*n)++] = "THANK YOU SO MUCH.";
        *opts = "X  OK"; break;
    default:
        *name = "GUN STORE CLERK";
        lines[(*n)++] = "AMMO'S ON THE HOUSE. WANT MORE";
        lines[(*n)++] = "FROM THAT RIFLE? USE THE GUN BENCH";
        lines[(*n)++] = "BY THE RIGHT WALL. PARTS COST CASH.";
        *opts = "X  OK"; break;
    }
}

static void dialogInput(uint32_t pressed) {
    if (pressed & SCE_CTRL_CROSS) {
        if (g_dlg == DLG_WALT_OFFER) { g_q1 = 1; toast("QUEST STARTED: LAWN CARE", "CHECK YOUR PHONE  (SELECT)"); }
        else if (g_dlg == DLG_ROSA_OFFER) { g_q3 = 1; toast("QUEST STARTED: PAINT JOB", "THE LIVING ROOM IS INSIDE"); }
        else if (g_dlg == DLG_CAFE_APPLY) { g_hired = true; toast("YOU'RE HIRED!", "USE THE ESPRESSO MACHINE TO WORK A SHIFT"); }
        else if (g_dlg == DLG_STORE_BUY && !g_ownW[W_RIFLE]) {
            if (g_money >= WEAPON_PRICE[W_RIFLE]) {
                buyWeapon(W_RIFLE);
                if (g_q2 == 1) g_q2 = 2;
                toast("RIFLE PURCHASED", "UPGRADE IT AT THE GUN BENCH");
            } else toast("NOT ENOUGH CASH", "THE RIFLE IS $25");
        }
        g_ui = UI_NONE;
    } else if ((pressed & SCE_CTRL_SQUARE) && g_dlg == DLG_STORE_BUY && !g_ownW[W_PISTOL]) {
        if (g_money >= WEAPON_PRICE[W_PISTOL]) {
            buyWeapon(W_PISTOL);
            if (g_q2 == 1) g_q2 = 2;
            toast("PISTOL PURCHASED", "UPGRADE IT AT THE GUN BENCH");
        } else toast("NOT ENOUGH CASH", "THE PISTOL IS $15");
        g_ui = UI_NONE;
    } else if (pressed & SCE_CTRL_CIRCLE) {
        g_ui = UI_NONE;
    }
}

void openBenchExt();
static inline float dist2D(float ax, float az, float bx, float bz) {
    return sqrtf((ax - bx) * (ax - bx) + (az - bz) * (az - bz));
}

static void updateInteraction(uint32_t pressed) {
    g_prompt = 0;
    bool tri = (pressed & SCE_CTRL_TRIANGLE) != 0;
    if (g_rolling) {
        g_prompt = g_rollHit ? "HOLD R  PAINT      LEFT/RIGHT  COLOR" : "AIM AT A WALL (GET CLOSER)";
        return;
    }
    if (dist2D(P.x, P.z, g_mgr.x, g_mgr.z) < 3.3f && dist2D(P.x, P.z, MACHINE_X, MACHINE_Z) > 1.4f) {
        g_prompt = "TRIANGLE  TALK TO THE MANAGER";
        if (tri) openDialog(g_hired ? DLG_CAFE_WORK : DLG_CAFE_APPLY);
        return;
    }
    if (dist2D(P.x, P.z, MACHINE_X, MACHINE_Z) < 1.4f) {
        if (g_hired) {
            g_prompt = "TRIANGLE  START A SHIFT (8 CUPS)";
            if (tri) { g_ads = 0; baristaStart(); }
        } else g_prompt = "TALK TO THE MANAGER TO APPLY";
        return;
    }
    if (dist2D(P.x, P.z, g_rosa.x, g_rosa.z) < 2.6f) {
        g_prompt = "TRIANGLE  TALK TO ROSA";
        if (tri) openDialog(g_q3 == 0 ? DLG_ROSA_OFFER : g_q3 == 1 ? DLG_ROSA_ACTIVE : DLG_ROSA_DONE);
        return;
    }
    if (g_mowing) {
        g_prompt = "TRIANGLE  LET GO OF THE MOWER";
        if (tri) g_mowing = false;
        return;
    }
    if (dist2D(P.x, P.z, g_walt.x, g_walt.z) < 2.6f) {
        g_prompt = "TRIANGLE  TALK TO WALT";
        if (tri) openDialog(g_q1 == 0 ? DLG_WALT_OFFER : g_q1 == 1 ? DLG_WALT_ACTIVE : DLG_WALT_DONE);
        return;
    }
    if (g_q1 == 1 && dist2D(P.x, P.z, g_mowerPos.x, g_mowerPos.z) < 1.9f) {
        g_prompt = "TRIANGLE  USE THE MOWER";
        if (tri) { g_mowing = true; g_ads = 0; g_reload = -1; if (P.pitch > -0.45f) P.pitch = -0.6f; }
        return;
    }
    if (dist2D(P.x, P.z, BENCH_X, BENCH_Z) < 1.9f) {
        if (g_hasGun) {
            g_prompt = "TRIANGLE  USE GUN BENCH";
            if (tri) { g_ads = 0; g_reload = -1; openBenchExt(); }
        } else g_prompt = "GUN BENCH - BUY A GUN FIRST";
        return;
    }
    if (dist2D(P.x, P.z, g_clerk.x, g_clerk.z) < 2.6f) {
        g_prompt = "TRIANGLE  GUN STORE";
        if (tri) openDialog((g_ownW[0] && g_ownW[1]) ? DLG_STORE_OWNED : DLG_STORE_BUY);
        return;
    }
}

// ---------------------------------------------------------------------
//  Phone (Select): Map, Quests, Wallet
// ---------------------------------------------------------------------
static const int PH_X = 330, PH_Y = 12, PH_W = 300, PH_H = 520;
static const int SC_X = PH_X + 12, SC_Y = PH_Y + 44, SC_W = PH_W - 24, SC_H = PH_H - 92;

static void phoneInput(uint32_t pressed) {
    if (pressed & SCE_CTRL_SELECT) { g_ui = UI_NONE; return; }
    if (g_phoneApp < 0) {
        if (pressed & SCE_CTRL_LEFT)  g_phoneSel = (g_phoneSel + 2) % 3;
        if (pressed & SCE_CTRL_RIGHT) g_phoneSel = (g_phoneSel + 1) % 3;
        if (pressed & SCE_CTRL_CROSS) g_phoneApp = g_phoneSel;
        if (pressed & SCE_CTRL_CIRCLE) g_ui = UI_NONE;
    } else {
        if (pressed & (SCE_CTRL_CIRCLE | SCE_CTRL_START)) g_phoneApp = -1;
    }
}


static void drawPhoneMap(Mesh& h) {
    const float WX0 = -8.0f, WSPAN = 336.0f;
    const float MS = 252.0f, mx0 = SC_X + (SC_W - MS) * 0.5f, my0 = SC_Y + 40;
    const float sc = MS / WSPAN;
    rect2(h, mx0, my0, MS, MS, col4(0.24f, 0.24f, 0.26f));
    for (int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++) {
            int ct = g_cellType[i - CELL_MIN][j - CELL_MIN];
            float bx = (i * CELL + rh(i) - WX0) * sc, bz = (j * CELL + rh(j) - WX0) * sc;
            float bw = (CELL - rh(i) - rh(i + 1)) * sc, bwz = (CELL - rh(j) - rh(j + 1)) * sc;
            Col c = ct == CT_PARK ? col4(0.35f, 0.62f, 0.32f) : ct == CT_HOME ? col4(0.45f, 0.70f, 0.40f)
                  : ct == CT_STORE ? col4(0.80f, 0.20f, 0.16f) : ct == CT_HOME2 ? col4(0.85f, 0.62f, 0.40f)
                  : ct == CT_CAFE ? col4(0.25f, 0.55f, 0.40f)
                  : col4(0.62f, 0.62f, 0.64f);
            rect2(h, mx0 + bx, my0 + bz, bw, bwz, c);
        }
    // home icon + store icon
    float hx = mx0 + (180.0f - WX0) * sc, hz = my0 + (186.0f - WX0) * sc;
    tri2(h, hx - 7, hz, hx + 7, hz, hx, hz - 7, col4(0.25f, 0.45f, 0.95f));
    rect2(h, hx - 5, hz, 10, 6, col4(0.25f, 0.45f, 0.95f));
    float gx = mx0 + (100.0f - WX0) * sc, gz = my0 + (260.0f - WX0) * sc;
    textC(h, gx, gz - 5, 2, "G", col4(1, 1, 1));
    textC(h, mx0 + (261.0f - WX0) * sc, my0 + (181.0f - WX0) * sc - 5, 2, "C", col4(1, 1, 1));
    // objective pings
    float pulse = 0.5f + 0.5f * sinf(g_time * 6.0f);
    float ox[5], oz[5]; int no = 0;
    if (g_q1 == 0) { ox[no] = WALT_X; oz[no++] = WALT_Z; }
    else if (g_q1 == 1) { ox[no] = 180.0f; oz[no++] = 175.0f; }
    if (g_q2 == 1) { ox[no] = STORE_DOOR_X; oz[no++] = STORE_DOOR_Z; }
    if (g_q3 == 0) { ox[no] = ROSA_X; oz[no++] = ROSA_Z; }
    else if (g_q3 == 1) { ox[no] = 220.0f; oz[no++] = 182.0f; }
    for (int k = 0; k < no; k++) {
        float px = mx0 + (ox[k] - WX0) * sc, pz = my0 + (oz[k] - WX0) * sc, r = 5 + pulse * 5;
        Col yc = col4(1, 0.85f, 0.1f, 0.5f + 0.5f * pulse);
        rect2(h, px - r, pz - 1, r * 2, 2, yc); rect2(h, px - 1, pz - r, 2, r * 2, yc);
    }
    // player arrow
    float px = mx0 + (clampf(P.x, WX0, WX0 + WSPAN) - WX0) * sc, pz = my0 + (clampf(P.z, WX0, WX0 + WSPAN) - WX0) * sc;
    float fx = -sinf(P.yaw), fz = -cosf(P.yaw), rx = -fz, rz = fx;
    tri2(h, px + fx * 9, pz + fz * 9, px - fx * 5 + rx * 6, pz - fz * 5 + rz * 6, px - fx * 5 - rx * 6, pz - fz * 5 - rz * 6, col4(1, 0.9f, 0.1f));
    textC(h, mx0 + MS * 0.5f, my0 - 2 - 16, 2, "N", col4(1, 1, 1, 0.8f));
    // legend
    float ly = my0 + MS + 14;
    rect2(h, SC_X + 16, ly, 12, 12, col4(0.25f, 0.45f, 0.95f)); text2(h, SC_X + 34, ly, 2, "HOME", col4(1, 1, 1));
    rect2(h, SC_X + 120, ly, 12, 12, col4(0.80f, 0.20f, 0.16f)); text2(h, SC_X + 138, ly, 2, "GUN STORE", col4(1, 1, 1));
    rect2(h, SC_X + 16, ly + 22, 12, 12, col4(1, 0.9f, 0.1f)); text2(h, SC_X + 34, ly + 22, 2, "YOU", col4(1, 1, 1));
    text2(h, SC_X + 120, ly + 22, 2, "+ OBJECTIVE", col4(1, 0.85f, 0.1f));
}

static void drawPhoneQuests(Mesh& h) {
    float x = SC_X + 14, y = SC_Y + 44;
    Col title = col4(1, 0.8f, 0.3f), done = col4(0.5f, 0.85f, 0.5f), txt = col4(1, 1, 1), dim = col4(0.7f, 0.7f, 0.75f);
    char buf[48];
    if (g_q1 == 0 && g_q3 == 0) {
        text2(h, x, y, 2, "NO QUESTS YET.", txt);
        text2(h, x, y + 24, 2, "LOOK FOR PEOPLE WITH", dim);
        text2(h, x, y + 44, 2, "A ! OVER THEIR HEAD.", dim);
        y += 80;
    }
    // finished quests collapse to one line
    if (g_q1 == 2) { text2(h, x, y, 2, "LAWN CARE  - DONE", done); y += 22; }
    if (g_q2 == 2) { text2(h, x, y, 2, "GEAR UP    - DONE", done); y += 22; }
    if (g_q3 == 2) { text2(h, x, y, 2, "PAINT JOB  - DONE", done); y += 22; }
    if (g_q1 == 2 || g_q2 == 2 || g_q3 == 2) y += 8;
    if (g_q1 == 1) {
        text2(h, x, y, 3, "LAWN CARE", title); y += 28;
        snprintf(buf, sizeof(buf), "[ ] MOW LAWN %d%%", (int)lawnPercent());
        text2(h, x, y, 2, buf, txt); y += 20;
        text2(h, x, y, 2, "    NEED 90%  REWARD $25", dim); y += 30;
    }
    if (g_q2 == 1) {
        text2(h, x, y, 3, "GEAR UP", title); y += 28;
        text2(h, x, y, 2, "[ ] BUY A GUN", txt); y += 20;
        text2(h, x, y, 2, "    GUN STORE ON MAP", dim); y += 30;
    }
    if (g_q3 == 1) {
        text2(h, x, y, 3, "PAINT JOB", title); y += 28;
        snprintf(buf, sizeof(buf), "[ ] PAINT WALLS %d%%", (int)paintPercent());
        text2(h, x, y, 2, buf, txt); y += 20;
        text2(h, x, y, 2, "    NEED 90%  REWARD $40", dim); y += 30;
    }
    text2(h, x, y, 3, "BARISTA JOB", col4(0.6f, 0.85f, 1)); y += 28;
    if (!g_hired) { text2(h, x, y, 2, "[ ] APPLY AT THE CAFE (C)", txt); y += 20; }
    else {
        text2(h, x, y, 2, "WORK SHIFTS AT THE CAFE", txt); y += 20;
        snprintf(buf, sizeof(buf), "SHIFTS %d   BEST $%d", g_shifts, g_bestShift);
        text2(h, x, y, 2, buf, dim);
    }
}

static void drawPhoneWallet(Mesh& h) {
    char buf[32];
    snprintf(buf, sizeof(buf), "$%d", g_money);
    textC(h, SC_X + SC_W * 0.5f, SC_Y + 70, 7, buf, col4(0.4f, 0.95f, 0.5f));
    textC(h, SC_X + SC_W * 0.5f, SC_Y + 140, 2, "CASH", col4(0.8f, 0.8f, 0.85f));
    text2(h, SC_X + 14, SC_Y + 190, 3, "ITEMS", col4(1, 0.8f, 0.3f));
    if (!g_hasGun) {
        text2(h, SC_X + 14, SC_Y + 226, 2, "- PHONE", col4(1, 1, 1));
        return;
    }
    float wy = SC_Y + 222;
    for (int w = 0; w < 2; w++) {
        if (!g_ownW[w]) continue;
        text2(h, SC_X + 14, wy, 2, w == 0 ? "- RIFLE" : "- PISTOL", col4(1, 1, 1)); wy += 19;
        const PartDef (*tbl)[NPARTS] = w == W_PISTOL ? PARTS_P : PARTS;
        for (int i = 0; i < NCAT; i++) {
            if (g_equipW[w][i] == 0) continue; // only list upgrades
            char pb[40];
            snprintf(pb, sizeof(pb), "  %s", tbl[i][g_equipW[w][i]].name);
            text2(h, SC_X + 14, wy, 2, pb, col4(0.75f, 0.8f, 0.85f)); wy += 17;
        }
    }
    text2(h, SC_X + 14, wy + 4, 2, "- PHONE", col4(1, 1, 1));
}

static void drawPhone(Mesh& h) {
    rect2(h, 0, 0, SCR_W, SCR_H, col4(0, 0, 0, 0.45f));
    rect2(h, PH_X - 3, PH_Y - 3, PH_W + 6, PH_H + 6, col4(0.35f, 0.35f, 0.38f));
    rect2(h, PH_X, PH_Y, PH_W, PH_H, col4(0.06f, 0.06f, 0.07f));
    rect2(h, PH_X + PH_W * 0.5f - 30, PH_Y + 14, 60, 8, col4(0.15f, 0.15f, 0.16f)); // speaker
    // screen wallpaper
    for (int b = 0; b < 16; b++) {
        float t = b / 15.0f;
        rect2(h, SC_X, SC_Y + SC_H * b / 16.0f, SC_W, SC_H / 16.0f + 1,
              col4(lerpf(0.10f, 0.32f, t), lerpf(0.16f, 0.12f, t), lerpf(0.36f, 0.40f, t)));
    }
    // status bar
    char buf[32];
    snprintf(buf, sizeof(buf), "$%d", g_money);
    text2(h, SC_X + 8, SC_Y + 8, 2, buf, col4(1, 1, 1), false);
    rect2(h, SC_X + SC_W - 40, SC_Y + 8, 28, 13, col4(1, 1, 1, 0.9f));
    rect2(h, SC_X + SC_W - 12, SC_Y + 11, 3, 7, col4(1, 1, 1, 0.9f));
    rect2(h, SC_X + SC_W - 38, SC_Y + 10, 18, 9, col4(0.3f, 0.85f, 0.4f));
    const char* names[3] = {"MAP", "QUESTS", "WALLET"};
    Col cols[3] = {col4(0.20f, 0.55f, 0.95f), col4(0.95f, 0.58f, 0.15f), col4(0.20f, 0.72f, 0.35f)};
    if (g_phoneApp < 0) {
        textC(h, SC_X + SC_W * 0.5f, SC_Y + 52, 4, "12:00", col4(1, 1, 1));
        for (int i = 0; i < 3; i++) {
            float ix = SC_X + 24 + i * 82, iy = SC_Y + 150;
            if (i == g_phoneSel) rect2(h, ix - 5, iy - 5, 70, 70, col4(1, 1, 1, 0.9f));
            rect2(h, ix, iy, 60, 60, cols[i]);
            if (i == 0) { // map glyph
                rect2(h, ix + 10, iy + 10, 40, 40, col4(0.85f, 0.92f, 1));
                rect2(h, ix + 10, iy + 27, 40, 6, cols[0]); rect2(h, ix + 27, iy + 10, 6, 40, cols[0]);
            } else textC(h, ix + 30, iy + 13, 5, i == 1 ? "!" : "$", col4(1, 1, 1));
            textC(h, ix + 30, iy + 70, 2, names[i], col4(1, 1, 1));
        }
        if (g_q1 == 1 || g_q2 == 1 || g_q3 == 1) rect2(h, SC_X + 24 + 82 + 52, SC_Y + 144, 14, 14, col4(0.95f, 0.15f, 0.15f)); // badge
        textC(h, SC_X + SC_W * 0.5f, SC_Y + SC_H - 26, 2, "X OPEN   O CLOSE", col4(1, 1, 1, 0.75f));
    } else {
        rect2(h, SC_X, SC_Y + 30, SC_W, 2, col4(1, 1, 1, 0.3f));
        textC(h, SC_X + SC_W * 0.5f, SC_Y + 8, 2, names[g_phoneApp], col4(1, 1, 1));
        if (g_phoneApp == 0) drawPhoneMap(h);
        else if (g_phoneApp == 1) drawPhoneQuests(h);
        else drawPhoneWallet(h);
        textC(h, SC_X + SC_W * 0.5f, SC_Y + SC_H - 26, 2, "O BACK", col4(1, 1, 1, 0.75f));
    }
    rect2(h, PH_X + PH_W * 0.5f - 22, PH_Y + PH_H - 30, 44, 18, col4(0.2f, 0.2f, 0.22f)); // home button
}

static void drawDialog(Mesh& h) {
    const char* name; const char* lines[6]; int n; const char* opts;
    dialogText(&name, lines, &n, &opts);
    float x = 60, y = SCR_H - 200, w = SCR_W - 120, hh = 180;
    rect2(h, x, y, w, hh, col4(0.03f, 0.04f, 0.06f, 0.86f));
    rect2(h, x, y, w, 3, col4(1, 0.8f, 0.3f));
    text2(h, x + 20, y + 16, 3, name, col4(1, 0.8f, 0.3f));
    for (int i = 0; i < n; i++) text2(h, x + 20, y + 52 + i * 22, 3, lines[i], col4(1, 1, 1));
    text2(h, x + 20, y + hh - 26, 2, opts, col4(0.75f, 0.85f, 1));
}

// ---------------------------------------------------------------------
//  Rendering helpers
// ---------------------------------------------------------------------
static Mesh g_dyn, g_blend, g_gun, g_hud, g_sky;

static bool inView(float cx, float cz, float radius, float hfov) {
    float dx = cx - P.x, dz = cz - P.z;
    float d = sqrtf(dx * dx + dz * dz);
    if (d < radius + 2.0f) return true;
    if (d - radius > FAR_PLANE) return false;
    float fx = -sinf(P.yaw), fz = -cosf(P.yaw);
    float ca = (dx * fx + dz * fz) / d;
    float allowed = hfov + asinf(fminf(1.0f, radius / d)) + 0.12f + fabsf(P.pitch) * 0.6f;
    if (allowed >= PI_F) return true;
    return ca >= cosf(allowed);
}

static void buildSky(Vec3 eye) {
    g_sky.clear();
    Col hz = col4(0.78f, 0.84f, 0.90f), mid = col4(0.60f, 0.74f, 0.90f), top = col4(0.36f, 0.56f, 0.86f);
    const int SEG = 24; const float R = 100.0f;
    float ys[4] = {-40.0f, 8.0f, 45.0f, 85.0f};
    Col cs[4] = {hz, hz, mid, top};
    for (int s = 0; s < SEG; s++) {
        float a0 = s * 2 * PI_F / SEG, a1 = (s + 1) * 2 * PI_F / SEG;
        float rf[4] = {1.0f, 1.0f, 0.85f, 0.45f};
        for (int r = 0; r < 3; r++) {
            Vec3 p00 = eye + v3(cosf(a0) * R * rf[r], ys[r], sinf(a0) * R * rf[r]);
            Vec3 p10 = eye + v3(cosf(a1) * R * rf[r], ys[r], sinf(a1) * R * rf[r]);
            Vec3 p11 = eye + v3(cosf(a1) * R * rf[r + 1], ys[r + 1], sinf(a1) * R * rf[r + 1]);
            Vec3 p01 = eye + v3(cosf(a0) * R * rf[r + 1], ys[r + 1], sinf(a0) * R * rf[r + 1]);
            g_sky.v(p00, 0, 0, cs[r]); g_sky.v(p10, 0, 0, cs[r]); g_sky.v(p11, 0, 0, cs[r + 1]);
            g_sky.v(p00, 0, 0, cs[r]); g_sky.v(p11, 0, 0, cs[r + 1]); g_sky.v(p01, 0, 0, cs[r + 1]);
        }
        Vec3 c0 = eye + v3(cosf(a0) * R * rf[3], ys[3], sinf(a0) * R * rf[3]);
        Vec3 c1 = eye + v3(cosf(a1) * R * rf[3], ys[3], sinf(a1) * R * rf[3]);
        g_sky.v(c0, 0, 0, top); g_sky.v(c1, 0, 0, top); g_sky.v(eye + v3(0, 95.0f, 0), 0, 0, top);
    }
    // sun
    Vec3 sd = norm3(v3(0.48f, 0.55f, 0.40f)) * 90.0f;
    Vec3 sc = eye + sd;
    Vec3 sr = norm3(cross3(sd, v3(0, 1, 0))), su = norm3(cross3(sr, sd));
    float S = 6.0f;
    quad(g_sky, sc - sr * S - su * S, sc + sr * S - su * S, sc + sr * S + su * S, sc - sr * S + su * S, 0, 0, 1, 1, col4(1.0f, 0.97f, 0.85f));
}

static void billboard(Mesh& m, Vec3 p, Vec3 r, Vec3 u, float s, Col c) {
    quad(m, p - r * s - u * s, p + r * s - u * s, p + r * s + u * s, p - r * s + u * s, 0, 0, 1, 1, c);
}

// ---------------------------------------------------------------------
//  Modular rifle model (gun-local: forward = -z, receiver at origin)
// ---------------------------------------------------------------------
struct GunAnchors { Mat4 GR, MG; Vec3 lHand; float tipZ; };

static GunAnchors buildGunModel(Mesh& m, const Mat4& G, const int* e, float magDrop, Vec3 L) {
    GunAnchors A;
    Col metal = col4(0.16f, 0.16f, 0.17f), dark = col4(0.08f, 0.08f, 0.09f), poly = col4(0.22f, 0.21f, 0.19f);
    Col steel = col4(0.34f, 0.34f, 0.36f);
    // core
    xbox(m, G, v3(-0.021f, -0.030f, -0.10f), v3(0.021f, 0.022f, 0.14f), metal, L);     // receiver
    xbox(m, G, v3(-0.016f, 0.022f, -0.09f), v3(0.016f, 0.030f, 0.12f), dark, L);       // top rail
    xbox(m, G, v3(-0.024f, -0.036f, -0.34f), v3(0.024f, 0.016f, -0.10f), poly, L);     // handguard
    xbox(m, G, v3(-0.0245f, -0.012f, -0.33f), v3(0.0245f, -0.006f, -0.12f), dark, L);  // handguard slots

    // ---- barrel
    float tip = -0.46f, bw = 0.008f;
    if (e[CAT_BARREL] == 1) tip = -0.40f;
    else if (e[CAT_BARREL] == 2) { tip = -0.60f; bw = 0.0075f; }
    else if (e[CAT_BARREL] == 3) { tip = -0.48f; bw = 0.012f; }
    const float by = -0.006f;
    xbox(m, G, v3(-bw, by - bw, tip), v3(bw, by + bw, -0.33f), dark, L);
    if (e[CAT_BARREL] == 3) { // flutes
        xbox(m, G, v3(-0.003f, by + bw - 0.001f, tip + 0.01f), v3(0.003f, by + bw + 0.0008f, -0.345f), steel, L);
        xbox(m, G, v3(bw - 0.001f, by - 0.003f, tip + 0.01f), v3(bw + 0.0008f, by + 0.003f, -0.345f), steel, L);
        xbox(m, G, v3(-bw - 0.0008f, by - 0.003f, tip + 0.01f), v3(-bw + 0.001f, by + 0.003f, -0.345f), steel, L);
    }
    if (e[CAT_BARREL] == 2) // gas block further out on the long barrel
        xbox(m, G, v3(-0.011f, by - 0.011f, -0.50f), v3(0.011f, by + 0.013f, -0.48f), metal, L);

    // ---- muzzle device
    float mz = tip;
    switch (e[CAT_MUZZLE]) {
    case 0: // brake
        xbox(m, G, v3(-0.013f, by - 0.011f, mz - 0.045f), v3(0.013f, by + 0.011f, mz), metal, L);
        xbox(m, G, v3(-0.0135f, by - 0.004f, mz - 0.034f), v3(0.0135f, by + 0.004f, mz - 0.026f), dark, L);
        xbox(m, G, v3(-0.0135f, by - 0.004f, mz - 0.020f), v3(0.0135f, by + 0.004f, mz - 0.012f), dark, L);
        mz -= 0.045f; break;
    case 1: // flash hider prongs
        xbox(m, G, v3(-0.012f, by - 0.012f, mz - 0.015f), v3(0.012f, by + 0.012f, mz), metal, L);
        for (int k = 0; k < 4; k++) {
            float an = 0.785f + k * 1.5708f, px = cosf(an) * 0.009f, py = sinf(an) * 0.009f;
            xbox(m, G, v3(px - 0.003f, by + py - 0.003f, mz - 0.055f), v3(px + 0.003f, by + py + 0.003f, mz - 0.014f), metal, L);
        }
        mz -= 0.055f; break;
    case 2: // compensator with top ports
        xbox(m, G, v3(-0.016f, by - 0.016f, mz - 0.065f), v3(0.016f, by + 0.014f, mz), steel, L);
        for (int k = 0; k < 3; k++)
            xbox(m, G, v3(-0.009f, by + 0.014f, mz - 0.016f - k * 0.017f), v3(0.009f, by + 0.0165f, mz - 0.008f - k * 0.017f), dark, L);
        mz -= 0.065f; break;
    default: { // suppressor (octagonal can)
        Mat4 R = mMul(G, mMul(mTrans(0, by, 0), mMul(mRotZ(0.785f), mTrans(0, -by, 0))));
        xbox(m, G, v3(-0.021f, by - 0.021f, mz - 0.17f), v3(0.021f, by + 0.021f, mz + 0.012f), dark, L);
        xbox(m, R, v3(-0.021f, by - 0.021f, mz - 0.17f), v3(0.021f, by + 0.021f, mz + 0.012f), dark, L);
        xbox(m, G, v3(-0.019f, by - 0.019f, mz - 0.175f), v3(0.019f, by + 0.019f, mz - 0.168f), steel, L);
        mz -= 0.17f; break; }
    }
    A.tipZ = mz;

    // ---- sights
    int sg = e[CAT_SIGHT];
    if (sg == 0) {
        xbox(m, G, v3(-0.010f, 0.016f, -0.335f), v3(0.010f, 0.024f, -0.315f), metal, L);
        xbox(m, G, v3(-0.0022f, 0.024f, -0.330f), v3(0.0022f, 0.042f, -0.323f), dark, L);
        xbox(m, G, v3(-0.013f, 0.024f, -0.332f), v3(-0.010f, 0.047f, -0.320f), metal, L);
        xbox(m, G, v3(0.010f, 0.024f, -0.332f), v3(0.013f, 0.047f, -0.320f), metal, L);
        xbox(m, G, v3(-0.013f, 0.030f, 0.090f), v3(0.013f, 0.042f, 0.106f), metal, L);
        xbox(m, G, v3(-0.013f, 0.042f, 0.090f), v3(-0.005f, 0.055f, 0.106f), metal, L);
        xbox(m, G, v3(0.005f, 0.042f, 0.090f), v3(0.013f, 0.055f, 0.106f), metal, L);
    } else {
        xbox(m, G, v3(-0.010f, 0.016f, -0.335f), v3(0.010f, 0.022f, -0.315f), metal, L); // low gas block
    }
    if (sg == 1) { // red dot: square window centered at y 0.063
        xbox(m, G, v3(-0.012f, 0.030f, -0.025f), v3(0.012f, 0.040f, 0.045f), metal, L);
        xbox(m, G, v3(-0.017f, 0.040f, -0.012f), v3(0.017f, 0.047f, 0.032f), dark, L);
        xbox(m, G, v3(-0.017f, 0.047f, -0.012f), v3(-0.012f, 0.080f, 0.032f), dark, L);
        xbox(m, G, v3(0.012f, 0.047f, -0.012f), v3(0.017f, 0.080f, 0.032f), dark, L);
        xbox(m, G, v3(-0.017f, 0.080f, -0.012f), v3(0.017f, 0.086f, 0.032f), dark, L);
        xbox(m, G, v3(0.017f, 0.055f, 0.0f), v3(0.022f, 0.068f, 0.014f), metal, L); // knob
    } else if (sg == 2) { // holographic: wide hood, battery box at the back
        xbox(m, G, v3(-0.015f, 0.030f, -0.035f), v3(0.015f, 0.042f, 0.075f), dark, L);
        xbox(m, G, v3(-0.015f, 0.042f, 0.035f), v3(0.015f, 0.060f, 0.075f), dark, L);
        xbox(m, G, v3(-0.021f, 0.042f, -0.030f), v3(-0.016f, 0.088f, 0.030f), dark, L);
        xbox(m, G, v3(0.016f, 0.042f, -0.030f), v3(0.021f, 0.088f, 0.030f), dark, L);
        xbox(m, G, v3(-0.021f, 0.084f, -0.030f), v3(0.021f, 0.090f, 0.030f), dark, L);
        xbox(m, G, v3(-0.006f, 0.060f, 0.055f), v3(0.006f, 0.066f, 0.068f), col4(0.5f, 0.1f, 0.1f), L); // buttons
    } else if (sg == 3) { // 4x scope, axis at y 0.068
        Mat4 R = mMul(G, mMul(mTrans(0, 0.068f, 0), mMul(mRotZ(0.785f), mTrans(0, -0.068f, 0))));
        xbox(m, G, v3(-0.012f, 0.030f, -0.05f), v3(0.012f, 0.058f, -0.03f), metal, L);
        xbox(m, G, v3(-0.012f, 0.030f, 0.06f), v3(0.012f, 0.058f, 0.08f), metal, L);
        xbox(m, G, v3(-0.0125f, 0.0555f, -0.10f), v3(0.0125f, 0.0805f, 0.12f), dark, L);
        xbox(m, R, v3(-0.0125f, 0.0555f, -0.10f), v3(0.0125f, 0.0805f, 0.12f), dark, L);
        xbox(m, G, v3(-0.021f, 0.047f, -0.17f), v3(0.021f, 0.089f, -0.10f), dark, L);
        xbox(m, R, v3(-0.021f, 0.047f, -0.17f), v3(0.021f, 0.089f, -0.10f), dark, L);
        xbox(m, G, v3(-0.018f, 0.050f, 0.12f), v3(0.018f, 0.086f, 0.17f), dark, L);
        xbox(m, G, v3(-0.008f, 0.0805f, 0.0f), v3(0.008f, 0.095f, 0.02f), metal, L);
        xbox(m, G, v3(0.0125f, 0.060f, 0.0f), v3(0.026f, 0.076f, 0.02f), metal, L);
        xbox(m, G, v3(-0.016f, 0.053f, -0.1705f), v3(0.016f, 0.083f, -0.169f), col4(0.25f, 0.35f, 0.45f), L); // lens
    }

    // ---- magazine (drops during reload)
    Mat4 MG = mMul(G, mMul(mTrans(0, -magDrop, magDrop * 0.3f), mRotX(0.12f)));
    switch (e[CAT_MAG]) {
    case 0:
        xbox(m, MG, v3(-0.014f, -0.16f, -0.075f), v3(0.014f, -0.028f, -0.018f), dark, L); break;
    case 1: // coupled pair
        xbox(m, MG, v3(-0.014f, -0.16f, -0.075f), v3(0.014f, -0.028f, -0.018f), dark, L);
        xbox(m, MG, v3(0.016f, -0.165f, -0.075f), v3(0.044f, -0.07f, -0.018f), dark, L);
        xbox(m, MG, v3(-0.016f, -0.12f, -0.08f), v3(0.046f, -0.10f, -0.013f), col4(0.6f, 0.15f, 0.1f), L);
        break;
    case 2: // extended
        xbox(m, MG, v3(-0.014f, -0.215f, -0.08f), v3(0.014f, -0.028f, -0.018f), dark, L);
        xbox(m, MG, v3(-0.016f, -0.224f, -0.083f), v3(0.016f, -0.213f, -0.015f), metal, L);
        break;
    default: { // drum
        xbox(m, MG, v3(-0.014f, -0.09f, -0.075f), v3(0.014f, -0.028f, -0.018f), dark, L);
        Mat4 D = mMul(MG, mMul(mTrans(0, -0.14f, -0.045f), mRotX(0.785f)));
        xbox(m, MG, v3(-0.036f, -0.195f, -0.10f), v3(0.036f, -0.085f, 0.01f), poly, L);
        xbox(m, D, v3(-0.035f, -0.055f, -0.055f), v3(0.035f, 0.055f, 0.055f), poly, L);
        xbox(m, MG, v3(-0.038f, -0.15f, -0.055f), v3(0.038f, -0.13f, -0.035f), metal, L);
        break; }
    }

    // ---- grip, trigger guard, stock
    Mat4 GR = mMul(G, mMul(mTrans(0, -0.03f, 0.085f), mRotX(-0.3f)));
    xbox(m, GR, v3(-0.015f, -0.10f, -0.02f), v3(0.015f, 0.0f, 0.022f), poly, L);
    xbox(m, G, v3(-0.004f, -0.052f, 0.02f), v3(0.004f, -0.046f, 0.07f), metal, L);
    xbox(m, G, v3(-0.017f, -0.045f, 0.14f), v3(0.017f, 0.015f, 0.34f), poly, L);
    xbox(m, G, v3(-0.019f, -0.075f, 0.30f), v3(0.019f, 0.018f, 0.36f), dark, L);

    // ---- underbarrel
    A.lHand = v3(0.0f, -0.045f, -0.26f);
    switch (e[CAT_UNDER]) {
    case 1: // vertical grip
        xbox(m, G, v3(-0.013f, -0.13f, -0.25f), v3(0.013f, -0.036f, -0.215f), poly, L);
        xbox(m, G, v3(-0.014f, -0.136f, -0.252f), v3(0.014f, -0.128f, -0.213f), dark, L);
        A.lHand = v3(0.0f, -0.10f, -0.232f); break;
    case 2: { // angled grip
        Mat4 AG = mMul(G, mMul(mTrans(0, -0.036f, -0.25f), mRotX(-0.45f)));
        xbox(m, AG, v3(-0.012f, -0.04f, -0.035f), v3(0.012f, 0.0f, 0.045f), poly, L);
        A.lHand = v3(0.0f, -0.07f, -0.235f); break; }
    case 3: // laser module
        xbox(m, G, v3(-0.010f, -0.044f, -0.30f), v3(0.010f, -0.036f, -0.22f), metal, L);
        xbox(m, G, v3(-0.016f, -0.074f, -0.30f), v3(0.016f, -0.044f, -0.225f), dark, L);
        xbox(m, G, v3(-0.005f, -0.066f, -0.303f), v3(0.005f, -0.054f, -0.299f), col4(1.0f, 0.15f, 0.1f), L);
        xbox(m, G, v3(0.016f, -0.064f, -0.27f), v3(0.020f, -0.056f, -0.25f), col4(0.6f, 0.1f, 0.1f), L);
        A.lHand = v3(0.0f, -0.045f, -0.19f); break;
    }
    A.GR = GR; A.MG = MG;
    return A;
}

// ---------------------------------------------------------------------
//  Modular pistol model (gun-local: forward = -z, bore axis y = 0.0145)
// ---------------------------------------------------------------------
static GunAnchors buildPistolModel(Mesh& m, const Mat4& G, const int* e, float magDrop, Vec3 L, float slideBack) {
    GunAnchors A;
    Col slideC = col4(0.13f, 0.13f, 0.14f), frameC = col4(0.20f, 0.19f, 0.17f), dark = col4(0.07f, 0.07f, 0.08f);
    Col steel = col4(0.38f, 0.38f, 0.40f);
    const float by = 0.0145f;
    float sf = pistolSlideFront(e);
    Mat4 S = mMul(G, mTrans(0, 0, slideBack)); // slide moves back when firing
    // slide
    xbox(m, S, v3(-0.0135f, 0.0f, sf), v3(0.0135f, 0.030f, 0.035f), slideC, L);
    for (int k = 0; k < 4; k++) // rear serrations
        xbox(m, S, v3(-0.0138f, 0.004f, 0.008f + k * 0.006f), v3(0.0138f, 0.026f, 0.010f + k * 0.006f), dark, L);
    xbox(m, S, v3(0.0136f, 0.012f, -0.05f), v3(0.0139f, 0.026f, -0.01f), dark, L); // ejection port
    if (e[CAT_BARREL] == 3) // ported slide: cuts on top
        for (int k = 0; k < 3; k++)
            xbox(m, S, v3(-0.006f, 0.0295f, sf + 0.012f + k * 0.016f), v3(0.006f, 0.0305f, sf + 0.022f + k * 0.016f), dark, L);
    if (e[CAT_BARREL] == 2) // long slide: lightening cut
        xbox(m, S, v3(-0.0137f, 0.016f, sf + 0.02f), v3(0.0137f, 0.024f, sf + 0.07f), dark, L);
    // barrel nose
    xbox(m, G, v3(-0.0065f, by - 0.0065f, sf - 0.012f), v3(0.0065f, by + 0.0065f, sf + 0.004f), steel, L);
    // frame, dust cover rail, trigger, guard, hammer, beavertail
    float ff = fmaxf(sf + 0.025f, -0.17f);
    xbox(m, G, v3(-0.0125f, -0.022f, ff), v3(0.0125f, 0.0f, 0.03f), frameC, L);
    xbox(m, G, v3(-0.0035f, -0.046f, -0.065f), v3(0.0035f, -0.041f, -0.004f), frameC, L);
    xbox(m, G, v3(-0.0035f, -0.046f, -0.07f), v3(0.0035f, -0.022f, -0.062f), frameC, L);
    xbox(m, G, v3(-0.002f, -0.036f, -0.024f), v3(0.002f, -0.022f, -0.016f), dark, L);
    xbox(m, S, v3(-0.004f, 0.016f, 0.035f), v3(0.004f, 0.030f, 0.045f), dark, L);
    xbox(m, G, v3(-0.011f, -0.012f, 0.03f), v3(0.011f, 0.004f, 0.052f), frameC, L);
    // grip
    Mat4 GR = mMul(G, mMul(mTrans(0, -0.02f, 0.016f), mRotX(-0.28f)));
    xbox(m, GR, v3(-0.014f, -0.105f, -0.016f), v3(0.014f, 0.0f, 0.03f), frameC, L);
    xbox(m, GR, v3(-0.0145f, -0.09f, -0.008f), v3(0.0145f, -0.015f, 0.024f), dark, L); // grip texture panels

    // ---- muzzle device on the barrel nose
    float mz = sf - 0.012f;
    switch (e[CAT_MUZZLE]) {
    case 0: xbox(m, G, v3(-0.0068f, by - 0.0068f, mz - 0.008f), v3(0.0068f, by + 0.0068f, mz), steel, L); mz -= 0.008f; break;
    case 1:
        xbox(m, G, v3(-0.008f, by - 0.008f, mz - 0.012f), v3(0.008f, by + 0.008f, mz), dark, L);
        for (int k = 0; k < 4; k++) {
            float an = 0.785f + k * 1.5708f, px = cosf(an) * 0.0055f, py = sinf(an) * 0.0055f;
            xbox(m, G, v3(px - 0.002f, by + py - 0.002f, mz - 0.04f), v3(px + 0.002f, by + py + 0.002f, mz - 0.011f), dark, L);
        }
        mz -= 0.04f; break;
    case 2:
        xbox(m, G, v3(-0.0135f, 0.0f, mz - 0.045f), v3(0.0135f, 0.030f, mz + 0.002f), slideC, L);
        for (int k = 0; k < 2; k++)
            xbox(m, G, v3(-0.006f, 0.0295f, mz - 0.014f - k * 0.016f), v3(0.006f, 0.0305f, mz - 0.006f - k * 0.016f), dark, L);
        mz -= 0.045f; break;
    default: {
        Mat4 Rr = mMul(G, mMul(mTrans(0, by, 0), mMul(mRotZ(0.785f), mTrans(0, -by, 0))));
        xbox(m, G, v3(-0.016f, by - 0.016f, mz - 0.13f), v3(0.016f, by + 0.016f, mz + 0.004f), dark, L);
        xbox(m, Rr, v3(-0.016f, by - 0.016f, mz - 0.13f), v3(0.016f, by + 0.016f, mz + 0.004f), dark, L);
        xbox(m, G, v3(-0.014f, by - 0.014f, mz - 0.134f), v3(0.014f, by + 0.014f, mz - 0.128f), steel, L);
        mz -= 0.13f; break; }
    }
    A.tipZ = mz;

    // ---- sights (irons always present: co-witness)
    xbox(m, S, v3(-0.009f, 0.030f, 0.018f), v3(-0.003f, 0.040f, 0.028f), dark, L);
    xbox(m, S, v3(0.003f, 0.030f, 0.018f), v3(0.009f, 0.040f, 0.028f), dark, L);
    xbox(m, S, v3(-0.0015f, 0.030f, sf + 0.008f), v3(0.0015f, 0.037f, sf + 0.014f), dark, L);
    xbox(m, S, v3(-0.0008f, 0.0335f, sf + 0.0075f), v3(0.0008f, 0.0355f, sf + 0.008f), col4(0.9f, 1.0f, 0.5f), L); // dot
    int sg = e[CAT_SIGHT];
    if (sg == 1) { // mini red dot on the slide, window center y 0.047
        xbox(m, S, v3(-0.011f, 0.030f, -0.03f), v3(0.011f, 0.036f, 0.012f), dark, L);
        xbox(m, S, v3(-0.011f, 0.036f, -0.022f), v3(-0.008f, 0.058f, 0.004f), dark, L);
        xbox(m, S, v3(0.008f, 0.036f, -0.022f), v3(0.011f, 0.058f, 0.004f), dark, L);
        xbox(m, S, v3(-0.011f, 0.058f, -0.022f), v3(0.011f, 0.062f, 0.004f), dark, L);
    } else if (sg == 2) { // mini holo, center 0.0485
        xbox(m, S, v3(-0.012f, 0.030f, -0.04f), v3(0.012f, 0.036f, 0.015f), dark, L);
        xbox(m, S, v3(-0.013f, 0.036f, -0.032f), v3(-0.010f, 0.061f, 0.0f), dark, L);
        xbox(m, S, v3(0.010f, 0.036f, -0.032f), v3(0.013f, 0.061f, 0.0f), dark, L);
        xbox(m, S, v3(-0.013f, 0.061f, -0.032f), v3(0.013f, 0.065f, 0.0f), dark, L);
        xbox(m, S, v3(-0.010f, 0.036f, 0.0f), v3(0.010f, 0.046f, 0.015f), dark, L);
    } else if (sg == 3) { // 2x scope on a frame mount, axis y 0.066
        Mat4 Rr = mMul(G, mMul(mTrans(0, 0.066f, 0), mMul(mRotZ(0.785f), mTrans(0, -0.066f, 0))));
        xbox(m, G, v3(-0.006f, 0.030f, -0.075f), v3(0.006f, 0.058f, -0.06f), steel, L);
        xbox(m, G, v3(-0.006f, 0.040f, 0.01f), v3(0.006f, 0.058f, 0.025f), steel, L);
        xbox(m, G, v3(-0.009f, 0.057f, -0.12f), v3(0.009f, 0.075f, 0.06f), dark, L);
        xbox(m, Rr, v3(-0.009f, 0.057f, -0.12f), v3(0.009f, 0.075f, 0.06f), dark, L);
        xbox(m, G, v3(-0.013f, 0.053f, -0.15f), v3(0.013f, 0.079f, -0.12f), dark, L);
        xbox(m, G, v3(-0.012f, 0.054f, 0.06f), v3(0.012f, 0.078f, 0.10f), dark, L);
        xbox(m, G, v3(-0.011f, 0.056f, -0.1505f), v3(0.011f, 0.076f, -0.149f), col4(0.25f, 0.35f, 0.45f), L);
    }

    // ---- magazine (in the grip; drops out of the bottom on reload)
    Mat4 MG = mMul(GR, mTrans(0, -magDrop, 0));
    switch (e[CAT_MAG]) {
    case 0:
        xbox(m, MG, v3(-0.011f, -0.103f, -0.01f), v3(0.011f, -0.01f, 0.025f), dark, L);
        xbox(m, MG, v3(-0.015f, -0.113f, -0.017f), v3(0.015f, -0.105f, 0.032f), dark, L); break;
    case 1: // flared magwell (stays on the gun) + bumper plate
        xbox(m, GR, v3(-0.018f, -0.116f, -0.022f), v3(0.018f, -0.1f, 0.036f), col4(0.6f, 0.15f, 0.1f), L);
        xbox(m, MG, v3(-0.011f, -0.103f, -0.01f), v3(0.011f, -0.01f, 0.025f), dark, L);
        xbox(m, MG, v3(-0.016f, -0.124f, -0.018f), v3(0.016f, -0.116f, 0.034f), dark, L); break;
    case 2:
        xbox(m, MG, v3(-0.011f, -0.165f, -0.01f), v3(0.011f, -0.01f, 0.025f), dark, L);
        xbox(m, MG, v3(-0.014f, -0.172f, -0.015f), v3(0.014f, -0.164f, 0.03f), steel, L); break;
    default: {
        xbox(m, MG, v3(-0.011f, -0.13f, -0.01f), v3(0.011f, -0.01f, 0.025f), dark, L);
        Mat4 D = mMul(MG, mMul(mTrans(0, -0.165f, 0.008f), mRotX(0.785f)));
        xbox(m, MG, v3(-0.026f, -0.205f, -0.032f), v3(0.026f, -0.125f, 0.048f), frameC, L);
        xbox(m, D, v3(-0.025f, -0.04f, -0.04f), v3(0.025f, 0.04f, 0.04f), frameC, L);
        break; }
    }

    // ---- underbarrel on the frame rail
    A.lHand = v3(-0.024f, -0.07f, 0.03f); // support hand wraps the grip
    switch (e[CAT_UNDER]) {
    case 1:
        xbox(m, G, v3(-0.009f, -0.072f, -0.125f), v3(0.009f, -0.022f, -0.098f), frameC, L);
        A.lHand = v3(0.0f, -0.06f, -0.11f); break;
    case 2:
        xbox(m, G, v3(-0.009f, -0.04f, -0.14f), v3(0.009f, -0.022f, -0.118f), frameC, L);
        A.lHand = v3(-0.006f, -0.045f, -0.105f); break;
    case 3:
        xbox(m, G, v3(-0.012f, -0.046f, -0.145f), v3(0.012f, -0.022f, -0.075f), dark, L);
        xbox(m, G, v3(-0.004f, -0.04f, -0.148f), v3(0.004f, -0.032f, -0.144f), col4(1.0f, 0.15f, 0.1f), L);
        break;
    }
    A.GR = GR; A.MG = MG;
    return A;
}

static GunAnchors buildWeaponModel(Mesh& m, const Mat4& G, const int* e, int w, float magDrop, Vec3 L, float slideBack) {
    if (w == W_PISTOL) return buildPistolModel(m, G, e, magDrop, L, slideBack);
    return buildGunModel(m, G, e, magDrop, L);
}

static void reloadAnim(float& rl, float& mag) {
    rl = 0; mag = 0;
    if (g_reload >= 0) {
        float t = clampf(g_reload / g_gs.reload, 0, 1);
        rl = sinf(t * PI_F);
        if (t > 0.22f && t < 0.78f) mag = sinf((t - 0.22f) / 0.56f * PI_F) * 0.22f;
    }
}

static Mat4 gunMatrix(float& yawO, float& pitchO) {
    float ads = g_ads, rl, mag;
    reloadAnim(rl, mag);
    float sp = g_sprint * (1.0f - ads);
    float swayMul = 1.0f - ads * 0.8f;
    float bob = P.moveAmt * (1.0f - ads * 0.85f);
    float bx = sinf(P.bobPhase) * 0.011f * bob * (1.0f + sp);
    float byb = -fabsf(cosf(P.bobPhase)) * 0.010f * bob * (1.0f + sp);
    Vec3 hip = g_weapon == W_PISTOL ? v3(0.12f, -0.13f, -0.32f) : v3(0.15f, -0.155f, -0.23f);
    Vec3 aim = v3(0.0f, -g_gs.sightY, g_gs.adsZ);
    Vec3 off = hip * (1.0f - ads) + aim * ads;
    off = off + v3(g_swayX * swayMul + bx, g_swayY * swayMul + byb - rl * 0.05f - sp * 0.03f, g_recoil * 0.028f + sp * 0.02f);
    yawO = 0.035f * (1 - ads) + sp * 0.55f;
    pitchO = g_recoil * 0.05f * (1.0f - ads * 0.4f) + rl * 0.25f - sp * 0.25f;
    float rollO = rl * 0.55f + sp * 0.2f;
    return mMul(mTrans(off.x, off.y, off.z), mMul(mRotY(yawO), mMul(mRotX(pitchO), mRotZ(rollO))));
}

static void buildGunAndArms(Mesh& m, float dt, float lookX, float lookY) {
    g_swayX = approach(g_swayX, -lookX * 0.018f, 8.0f, dt);
    g_swayY = approach(g_swayY, lookY * 0.014f, 8.0f, dt);
    const Vec3 L = norm3(v3(0.35f, 0.85f, 0.45f));
    float yawO, pitchO, rl, mag;
    Mat4 G = gunMatrix(yawO, pitchO);
    reloadAnim(rl, mag);
    float slideBack = (g_weapon == W_PISTOL && g_flash > 0) ? 0.022f * (g_flash / 0.05f) : 0.0f;
    GunAnchors A = buildWeaponModel(m, G, g_equip, g_weapon, mag, L, slideBack);

    Col sleeve = col4(0.24f, 0.28f, 0.20f), glove = col4(0.12f, 0.11f, 0.10f);
    bool pis = g_weapon == W_PISTOL;
    Vec3 rHand = mApply(A.GR, v3(0, -0.05f, 0.0f));
    Vec3 rElbow = mApply(G, pis ? v3(0.10f, -0.21f, 0.24f) : v3(0.11f, -0.20f, 0.28f));
    Vec3 lHand = mApply(G, A.lHand);
    if (g_reload >= 0 && mag > 0.02f) lHand = mApply(A.MG, pis ? v3(0.0f, -0.12f, 0.0f) : v3(0.0f, -0.16f, -0.05f)); // left hand follows the mag
    Vec3 lElbow = mApply(G, pis ? v3(-0.13f, -0.22f, 0.22f) : v3(-0.17f, -0.24f, A.lHand.z + 0.20f));
    beam(m, rHand, rElbow, 0.032f, sleeve, L);
    beam(m, rElbow, rElbow + v3(0.10f, -0.25f, 0.25f), 0.042f, sleeve, L);
    beam(m, lHand, lElbow, 0.030f, sleeve, L);
    beam(m, lElbow, lElbow + v3(-0.12f, -0.25f, 0.25f), 0.042f, sleeve, L);
    Mat4 RH = mMul(mTrans(rHand.x, rHand.y, rHand.z), mMul(mRotY(yawO), mRotX(pitchO)));
    Mat4 LH = mMul(mTrans(lHand.x, lHand.y, lHand.z), mMul(mRotY(yawO), mRotX(pitchO)));
    xbox(m, RH, v3(-0.028f, -0.03f, -0.035f), v3(0.028f, 0.03f, 0.035f), glove, L);
    xbox(m, LH, v3(-0.03f, -0.025f, -0.04f), v3(0.03f, 0.03f, 0.04f), glove, L);
}

static void buildMuzzleFlash(Mesh& m) {
    if (g_flash <= 0 || g_gs.flash <= 0) return;
    float yawO, pitchO;
    Mat4 G = gunMatrix(yawO, pitchO);
    Vec3 tip = mApply(G, v3(0, g_weapon == W_PISTOL ? 0.0145f : -0.006f, partsTipZ(g_equip) - 0.01f));
    float fs = g_gs.flash;
    Col c = col4(1.0f, 0.75f, 0.35f, 0.95f);
    for (int k = 0; k < 3; k++) {
        float a = g_flashRot + k * PI_F / 3.0f;
        Vec3 d = v3(cosf(a), sinf(a), 0), pp = v3(-sinf(a), cosf(a), 0);
        float l = (0.07f + 0.03f * k) * fs, w = 0.012f * fs;
        quad(m, tip - d * l - pp * w, tip + d * l - pp * w, tip + d * l + pp * w, tip - d * l + pp * w, 0, 0, 1, 1, c);
    }
    billboard(m, tip, v3(1, 0, 0), v3(0, 1, 0), 0.035f * fs, col4(1, 0.95f, 0.8f, 1));
}

// ---------------------------------------------------------------------
//  Gun bench UI
// ---------------------------------------------------------------------
static int g_benchCol = 0, g_benchCat = 0, g_benchSel = 0;
static char g_benchMsg[48] = ""; static float g_benchMsgT = 0;

static void benchMsg(const char* m) { strncpy(g_benchMsg, m, 47); g_benchMsg[47] = 0; g_benchMsgT = 2.5f; }

static void openBench() { g_ui = UI_BENCH; g_benchCol = 0; g_benchSel = g_equip[g_benchCat]; g_benchMsgT = 0; }

static void benchInput(uint32_t pressed) {
    if (pressed & SCE_CTRL_SELECT) { g_ui = UI_NONE; return; }
    if ((pressed & (SCE_CTRL_LTRIGGER | SCE_CTRL_RTRIGGER)) && g_ownW[0] && g_ownW[1]) {
        selectWeapon(1 - g_weapon);
        g_benchSel = g_equip[g_benchCat];
        return;
    }
    if (g_benchCol == 0) {
        if (pressed & SCE_CTRL_UP)   { g_benchCat = (g_benchCat + NCAT - 1) % NCAT; }
        if (pressed & SCE_CTRL_DOWN) { g_benchCat = (g_benchCat + 1) % NCAT; }
        if (pressed & (SCE_CTRL_RIGHT | SCE_CTRL_CROSS)) { g_benchCol = 1; g_benchSel = g_equip[g_benchCat]; }
        else if (pressed & SCE_CTRL_CIRCLE) g_ui = UI_NONE;
    } else {
        if (pressed & SCE_CTRL_UP)   g_benchSel = (g_benchSel + NPARTS - 1) % NPARTS;
        if (pressed & SCE_CTRL_DOWN) g_benchSel = (g_benchSel + 1) % NPARTS;
        if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_CIRCLE)) { g_benchCol = 0; return; }
        if (pressed & SCE_CTRL_CROSS) {
            int c = g_benchCat, i = g_benchSel;
            const PartDef& pd = CURPARTS[c][i];
            char buf[48];
            if (g_owned[c] & (1u << i)) {
                if (g_equip[c] == i) benchMsg("ALREADY EQUIPPED");
                else { equipPart(c, i); snprintf(buf, sizeof(buf), "EQUIPPED %s", pd.name); benchMsg(buf); }
            } else if (g_money >= pd.price) {
                g_money -= pd.price; g_owned[c] |= (1u << i); equipPart(c, i);
                snprintf(buf, sizeof(buf), "BOUGHT %s  -$%d", pd.name, pd.price); benchMsg(buf);
            } else {
                snprintf(buf, sizeof(buf), "NEED $%d MORE", pd.price - g_money); benchMsg(buf);
            }
        }
    }
}

static void benchPreviewCfg(int* cfg) {
    for (int i = 0; i < NCAT; i++) cfg[i] = g_equip[i];
    if (g_benchCol == 1) cfg[g_benchCat] = g_benchSel;
}

static const float BP_X = 280, BP_Y = 56, BP_W = 660, BP_H = 236; // preview panel

// 3D part of the bench screen (drawn before the HUD layer)
static void drawBenchPreview(float aspect) {
    Mat4 ortho = mOrtho(0, SCR_W, SCR_H, 0, -1, 1), id = mIdent();
    glMatrixMode(GL_PROJECTION); glLoadMatrixf(ortho.m);
    glMatrixMode(GL_MODELVIEW); glLoadMatrixf(id.m);
    glDisable(GL_DEPTH_TEST); glEnable(GL_BLEND);
    g_blend.clear();
    rect2(g_blend, 0, 0, SCR_W, SCR_H, col4(0.05f, 0.06f, 0.07f, 0.94f));
    for (int b = 0; b < 12; b++) { // panel gradient
        float t = b / 11.0f;
        rect2(g_blend, BP_X, BP_Y + BP_H * b / 12.0f, BP_W, BP_H / 12.0f + 1, col4(lerpf(0.20f, 0.10f, t), lerpf(0.22f, 0.11f, t), lerpf(0.25f, 0.13f, t), 1));
    }
    drawMesh(g_blend);
    glDisable(GL_BLEND); glEnable(GL_DEPTH_TEST);
    glClear(GL_DEPTH_BUFFER_BIT);

    const float FOV = 40.0f, D = g_weapon == W_PISTOL ? 0.85f : 1.6f;
    Mat4 proj = mPerspective(FOV, aspect, 0.05f, 10.0f);
    glMatrixMode(GL_PROJECTION); glLoadMatrixf(proj.m);
    glMatrixMode(GL_MODELVIEW); glLoadMatrixf(id.m);
    float hh = D * tanf(FOV * PI_F / 360.0f), hw = hh * aspect;
    float cxp = BP_X + BP_W * 0.5f, cyp = BP_Y + BP_H * 0.5f;
    float wx = ((cxp - SCR_W * 0.5f) / (SCR_W * 0.5f)) * hw, wy = ((SCR_H * 0.5f - cyp) / (SCR_H * 0.5f)) * hh;
    int cfg[NCAT]; benchPreviewCfg(cfg);
    float yaw = PI_F * 0.5f + 0.32f * sinf(g_time * 0.6f);
    Mat4 G = mMul(mTrans(wx, wy, -D), mMul(mRotX(0.22f), mMul(mRotY(yaw),
                  g_weapon == W_PISTOL ? mTrans(0, 0.03f, 0.06f) : mTrans(0, 0.02f, 0.19f))));
    g_gun.clear();
    buildWeaponModel(g_gun, G, cfg, g_weapon, 0, norm3(v3(0.3f, 0.8f, 0.6f)), 0);
    glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
    drawMesh(g_gun);
}

static void statBar(Mesh& h, float x, float y, const char* label, float cur, float prev) {
    cur = clampf(cur, 0, 1); prev = clampf(prev, 0, 1);
    text2(h, x, y, 2, label, col4(0.8f, 0.8f, 0.85f));
    float bx = x + 110, bw = 120;
    rect2(h, bx, y + 2, bw, 10, col4(0.2f, 0.2f, 0.22f));
    Col pc = prev > cur + 0.01f ? col4(0.35f, 0.9f, 0.4f) : (prev < cur - 0.01f ? col4(0.95f, 0.3f, 0.25f) : col4(0.85f, 0.85f, 0.88f));
    rect2(h, bx, y + 2, bw * prev, 10, pc);
    rect2(h, bx + bw * cur - 1, y, 2, 14, col4(1, 1, 1));
}

static void drawBenchHud(Mesh& h) {
    char buf[64];
    text2(h, 30, 18, 4, "GUN BENCH", col4(1, 0.8f, 0.3f));
    for (int w = 0; w < 2; w++) { // weapon tabs
        if (!g_ownW[w]) continue;
        float tx = 280 + w * 150;
        bool on = w == g_weapon;
        rect2(h, tx, 14, 140, 34, on ? col4(1, 0.8f, 0.3f, 0.9f) : col4(1, 1, 1, 0.15f));
        textC(h, tx + 70, 22, 3, WEAPON_NAMES[w], on ? col4(0.08f, 0.08f, 0.1f) : col4(1, 1, 1));
    }
    if (g_ownW[0] && g_ownW[1]) text2(h, 590, 26, 2, "L/R SWITCH", col4(1, 1, 1, 0.6f));
    snprintf(buf, sizeof(buf), "$%d", g_money);
    text2(h, SCR_W - 30 - textWidth(buf, 4), 18, 4, buf, col4(0.45f, 1.0f, 0.55f));
    // categories
    for (int i = 0; i < NCAT; i++) {
        float y = 66 + i * 54;
        bool sel = i == g_benchCat;
        if (sel) rect2(h, 22, y - 6, 240, 50, g_benchCol == 0 ? col4(1, 0.8f, 0.3f, 0.9f) : col4(1, 1, 1, 0.25f));
        Col tc = sel && g_benchCol == 0 ? col4(0.08f, 0.08f, 0.1f) : col4(1, 1, 1);
        text2(h, 32, y, 3, CAT_NAMES[i], tc, false);
        text2(h, 32, y + 25, 2, CURPARTS[i][g_equip[i]].name, sel && g_benchCol == 0 ? col4(0.2f, 0.2f, 0.2f) : col4(0.65f, 0.7f, 0.75f), false);
    }
    // preview frame
    Col fc = col4(1, 1, 1, 0.25f);
    rect2(h, BP_X, BP_Y, BP_W, 2, fc); rect2(h, BP_X, BP_Y + BP_H - 2, BP_W, 2, fc);
    rect2(h, BP_X, BP_Y, 2, BP_H, fc); rect2(h, BP_X + BP_W - 2, BP_Y, 2, BP_H, fc);
    text2(h, BP_X + 10, BP_Y + 10, 2, g_benchCol == 1 ? "PREVIEW" : "YOUR RIFLE", col4(1, 1, 1, 0.7f));
    // parts list for the current category
    for (int i = 0; i < NPARTS; i++) {
        float y = BP_Y + BP_H + 14 + i * 36;
        bool sel = g_benchCol == 1 && i == g_benchSel;
        if (sel) rect2(h, BP_X, y - 6, BP_W, 32, col4(1, 0.8f, 0.3f, 0.9f));
        Col tc = sel ? col4(0.08f, 0.08f, 0.1f) : col4(1, 1, 1);
        text2(h, BP_X + 12, y, 3, CURPARTS[g_benchCat][i].name, tc, false);
        const char* st; Col sc;
        if (g_equip[g_benchCat] == i) { st = "EQUIPPED"; sc = sel ? col4(0.05f, 0.4f, 0.1f) : col4(0.4f, 0.95f, 0.45f); }
        else if (g_owned[g_benchCat] & (1u << i)) { st = "OWNED"; sc = sel ? col4(0.1f, 0.1f, 0.1f) : col4(0.8f, 0.8f, 0.85f); }
        else {
            snprintf(buf, sizeof(buf), "$%d", CURPARTS[g_benchCat][i].price); st = buf;
            bool can = g_money >= CURPARTS[g_benchCat][i].price;
            sc = sel ? (can ? col4(0.1f, 0.1f, 0.1f) : col4(0.6f, 0.05f, 0.05f)) : (can ? col4(1, 0.85f, 0.3f) : col4(0.95f, 0.35f, 0.3f));
        }
        text2(h, BP_X + BP_W - 14 - textWidth(st, 3), y, 3, st, sc, false);
    }
    int hi = g_benchCol == 1 ? g_benchSel : g_equip[g_benchCat];
    text2(h, BP_X + 12, BP_Y + BP_H + 14 + 4 * 36 + 4, 2, CURPARTS[g_benchCat][hi].desc, col4(0.75f, 0.85f, 1));
    // stats: current vs preview
    int cfg[NCAT]; benchPreviewCfg(cfg);
    GunStats c = g_gs, pv = computeStats(cfg);
    float sy = 350;
    text2(h, 30, sy, 2, "STATS", col4(1, 0.8f, 0.3f));
    statBar(h, 30, sy + 24, "DAMAGE", c.dmg / 1.5f, pv.dmg / 1.5f);
    statBar(h, 30, sy + 46, "CONTROL", 1.25f - c.recoil * 0.75f, 1.25f - pv.recoil * 0.75f);
    statBar(h, 30, sy + 68, "ACCURACY", 1.3f - 0.42f * (c.spreadHip + c.spreadAds), 1.3f - 0.42f * (pv.spreadHip + pv.spreadAds));
    statBar(h, 30, sy + 90, "AIM SPEED", c.adsSpeed / 1.6f, pv.adsSpeed / 1.6f);
    snprintf(buf, sizeof(buf), "MAG %d   RELOAD %.1fS", pv.mag, pv.reload);
    text2(h, 30, sy + 116, 2, buf, col4(1, 1, 1));
    // footer
    if (g_benchMsgT > 0) textC(h, BP_X + BP_W * 0.5f, SCR_H - 54, 2, g_benchMsg, col4(1, 0.85f, 0.3f, clampf(g_benchMsgT, 0, 1)));
    text2(h, BP_X, SCR_H - 26, 2,
          g_benchCol == 0 ? "UP/DOWN CATEGORY   X/RIGHT PARTS   O CLOSE" : "UP/DOWN PART   X BUY/EQUIP   O/LEFT BACK",
          col4(1, 1, 1, 0.7f));
}

static void drawReticles(Mesh& h) {
    const float cx = SCR_W * 0.5f, cy = SCR_H * 0.5f;
    int sg = g_equip[CAT_SIGHT];
    Col red = col4(1.0f, 0.12f, 0.1f, 1);
    if (sg == 1 && g_ads > 0.75f) {
        rect2(h, cx - 5, cy - 5, 10, 10, col4(1, 0.1f, 0.1f, 0.25f));
        rect2(h, cx - 2, cy - 2, 4, 4, red);
    } else if (sg == 2 && g_ads > 0.75f) {
        for (int k = 0; k < 28; k++) {
            float a = k * 2 * PI_F / 28;
            rect2(h, cx + cosf(a) * 22 - 1.5f, cy + sinf(a) * 22 - 1.5f, 3, 3, red);
        }
        rect2(h, cx - 2, cy - 2, 4, 4, red);
        rect2(h, cx - 1, cy + 8, 2, 8, red);
    } else if (sg == 3 && g_ads > 0.85f) {
        const float Rr = 250.0f;
        Col blk = col4(0, 0, 0, 1);
        for (int y = 0; y < SCR_H; y += 4) {
            float dy = y + 2 - cy;
            if (fabsf(dy) >= Rr) { rect2(h, 0, (float)y, SCR_W, 4, blk); continue; }
            float hw = sqrtf(Rr * Rr - dy * dy);
            rect2(h, 0, (float)y, cx - hw, 4, blk);
            rect2(h, cx + hw, (float)y, SCR_W - (cx + hw), 4, blk);
        }
        rect2(h, cx - Rr, cy - 1, Rr - 40, 2, blk); rect2(h, cx + 40, cy - 1, Rr - 40, 2, blk);
        rect2(h, cx - 1, cy + 40, 2, Rr - 40, blk); rect2(h, cx - 1, cy - Rr, 2, Rr - 40, blk);
        rect2(h, cx - Rr, cy - 4, 120, 8, blk); rect2(h, cx + Rr - 120, cy - 4, 120, 8, blk);
        rect2(h, cx - 4, cy + Rr - 120, 8, 120, blk);
        rect2(h, cx - 40, cy - 0.5f, 80, 1, blk); rect2(h, cx - 0.5f, cy - 40, 1, 80, blk);
        rect2(h, cx - 1.5f, cy - 1.5f, 3, 3, red);
    }
}

void openBenchExt() { openBench(); }

static void setupFog(bool on) {
    if (on) {
        GLfloat fc[4] = {0.78f, 0.84f, 0.90f, 1.0f};
        glEnable(GL_FOG);
        glFogi(GL_FOG_MODE, GL_LINEAR);
        glFogf(GL_FOG_START, FOG_START);
        glFogf(GL_FOG_END, FOG_END);
        glFogfv(GL_FOG_COLOR, fc);
    } else glDisable(GL_FOG);
}

// ---------------------------------------------------------------------
//  Main
// ---------------------------------------------------------------------
int main() {
    { volatile unsigned char t = g_elfPad[0]; (void)t; } // keep the padding linked
    scePowerSetArmClockFrequency(444);
    scePowerSetBusClockFrequency(222);
    scePowerSetGpuClockFrequency(222);
    scePowerSetGpuXbarClockFrequency(166);

    vglInit(0x800000);
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG_WIDE);

    glViewport(0, 0, SCR_W, SCR_H);
    glClearColor(0.78f, 0.84f, 0.90f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_TEXTURE_2D);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    makeTextures();
    genWorld();

    memset(&P, 0, sizeof(P));
    P.x = SPAWN_X; P.z = SPAWN_Z; P.y = CURB_H; P.yaw = PI_F; P.pitch = -0.05f; P.ground = true; // facing Walt
    initLawn();
    initPaint();
    initStoryNpcs();
    g_gs = computeStats(g_equip);
    memset(g_cash, 0, sizeof(g_cash));
    g_rng = 0xBEEF1234u;
    for (int i = 0; i < NUM_NPCS; i++) npcSpawn(g_npcs[i], P.x, P.z, false);
    initTraffic();
    memset(g_decals, 0, sizeof(g_decals));
    for (int i = 0; i < MAX_PARTICLES; i++) g_parts[i].life = 0;

    g_dyn.p.reserve(120000); g_dyn.t.reserve(80000); g_dyn.c.reserve(160000);
    g_hud.p.reserve(60000); g_hud.t.reserve(40000); g_hud.c.reserve(80000);

    SceCtrlData pad; memset(&pad, 0, sizeof(pad));
    uint32_t prevButtons = 0;
    uint64_t last = sceKernelGetProcessTimeWide();
    float fpsAcc = 0; int fpsFrames = 0; int fpsShown = 0;
    const float aspect = (float)SCR_W / (float)SCR_H;

    for (;;) {
        uint64_t now = sceKernelGetProcessTimeWide();
        float dt = (now - last) / 1000000.0f; last = now;
        if (dt > 0.05f) dt = 0.05f;
        fpsAcc += dt; fpsFrames++;
        if (fpsAcc >= 0.5f) { fpsShown = (int)(fpsFrames / fpsAcc + 0.5f); fpsAcc = 0; fpsFrames = 0; }

        sceCtrlPeekBufferPositive(0, &pad, 1);
        uint32_t btn = pad.buttons, pressed = btn & ~prevButtons;
        prevButtons = btn;

        g_time += dt;
        bool simFrame = (g_ui == UI_NONE); // decided before UI input so a closing press doesn't leak into gameplay
        if (g_ui == UI_NONE) {
            if (pressed & SCE_CTRL_START) g_ui = UI_PAUSE;
            else if (pressed & SCE_CTRL_SELECT) { g_ui = UI_PHONE; g_phoneApp = -1; g_mowing = false; }
        } else if (g_ui == UI_PAUSE) {
            if (pressed & SCE_CTRL_START) g_ui = UI_NONE;
            else if (pressed & SCE_CTRL_SELECT) break;
        } else if (g_ui == UI_PHONE) {
            phoneInput(pressed);
        } else if (g_ui == UI_DIALOG) {
            dialogInput(pressed);
        } else if (g_ui == UI_BENCH) {
            benchInput(pressed);
        } else if (g_ui == UI_BARISTA) {
            baristaUpdate(dt, btn, pressed);
        }
        if (g_benchMsgT > 0) g_benchMsgT -= dt;
        if (g_cashPopT > 0) g_cashPopT -= dt;
        if (g_toastT > 0) g_toastT -= dt;

        float lx = (pad.lx - 128) / 128.0f, ly = (pad.ly - 128) / 128.0f;
        float rx = (pad.rx - 128) / 128.0f, ry = (pad.ry - 128) / 128.0f;
        {   // radial deadzones with rescale
            float m = sqrtf(lx * lx + ly * ly);
            if (m < 0.2f) { lx = ly = 0; } else { float s = fminf(1.0f, (m - 0.2f) / 0.8f) / m; lx *= s; ly *= s; }
            m = sqrtf(rx * rx + ry * ry);
            if (m < 0.18f) { rx = ry = 0; } else { float s = fminf(1.0f, (m - 0.18f) / 0.82f) / m; rx *= s; ry *= s; }
        }

        if (simFrame && g_ui == UI_NONE) {
            if (g_helpT > 0) g_helpT -= dt;
            // ---- look
            float rm = sqrtf(rx * rx + ry * ry);
            float curve = rm; // stick * magnitude = squared response
            float lookMul = lerpf(1.0f, ADS_LOOK_MUL * (g_gs.adsFov / FOV_ADS), g_ads);
            P.yaw -= rx * curve * LOOK_YAW * lookMul * dt;
            P.pitch -= ry * curve * LOOK_PITCH * lookMul * dt;
            P.pitch = g_mowing ? clampf(P.pitch, -1.25f, -0.2f) : clampf(P.pitch, -1.45f, 1.45f);
            P.yaw = wrapAngle(P.yaw);

            // ---- states
            bool armed = g_hasGun && !g_mowing && !g_rolling;
            bool wantAds = armed && (btn & SCE_CTRL_LTRIGGER) && g_reload < 0;
            bool firing = armed && (btn & SCE_CTRL_RTRIGGER) != 0;
            bool wantSprint = !g_mowing && (btn & SCE_CTRL_CIRCLE) && ly < -0.3f && !wantAds && !firing;
            g_sprint = approach(g_sprint, wantSprint ? 1.0f : 0.0f, 10.0f, dt);
            g_ads = approach(g_ads, wantAds ? 1.0f : 0.0f, 16.0f * g_gs.adsSpeed, dt);
            if (g_ads < 0.002f) g_ads = 0;
            if (g_ads > 0.998f) g_ads = 1;

            // ---- move
            float spd = lerpf(WALK_SPEED, SPRINT_SPEED, g_sprint) * lerpf(1.0f, ADS_SPEED_MUL, g_ads);
            if (g_mowing) spd = 2.6f;
            float fx = -sinf(P.yaw), fz = -cosf(P.yaw);
            float rxw = cosf(P.yaw), rzw = -sinf(P.yaw);
            float tvx = (fx * -ly + rxw * lx) * spd, tvz = (fz * -ly + rzw * lx) * spd;
            float accel = P.ground ? 12.0f : 2.5f;
            P.vx = approach(P.vx, tvx, accel, dt);
            P.vz = approach(P.vz, tvz, accel, dt);
            P.x += P.vx * dt; P.z += P.vz * dt;

            float gh = groundHeight(P.x, P.z);
            if (P.ground && !g_mowing && (pressed & SCE_CTRL_CROSS)) { P.vy = JUMP_VEL; P.ground = false; }
            if (!P.ground || P.y > gh + 0.01f) {
                P.vy -= GRAVITY * dt; P.y += P.vy * dt;
                if (P.y <= gh) { P.y = gh; P.vy = 0; P.ground = true; } else P.ground = false;
            } else {
                P.y = approach(P.y, gh, 25.0f, dt); // step up/down curbs smoothly
                P.ground = true;
            }
            collidePlayer();

            float hs = sqrtf(P.vx * P.vx + P.vz * P.vz);
            P.moveAmt = approach(P.moveAmt, P.ground ? clampf(hs / WALK_SPEED, 0, 1.4f) : 0.0f, 10.0f, dt);
            P.bobPhase += dt * hs * 1.85f;

            // ---- weapon
            g_fireCD -= dt;
            g_recoil = approach(g_recoil, 0, 14.0f, dt);
            g_bloom = approach(g_bloom, 0, 5.0f, dt);
            if (g_flash > 0) g_flash -= dt;
            if (g_hitMarker > 0) g_hitMarker -= dt;
            if (!armed) {
                // no rifle (or hands busy with the mower)
            } else if (g_reload >= 0) {
                g_reload += dt;
                if (g_reload >= g_gs.reload) { g_reload = -1; g_ammo = g_gs.mag; }
            } else {
                if ((pressed & SCE_CTRL_SQUARE) && g_ammo < g_gs.mag) g_reload = 0;
                else if (firing && g_ammo <= 0 && (pressed & SCE_CTRL_RTRIGGER)) g_reload = 0;
                else if ((g_gs.semi ? (pressed & SCE_CTRL_RTRIGGER) != 0 : firing) && g_fireCD <= 0 && g_ammo > 0 && g_sprint < 0.3f) fireShot();
                if (g_ammo <= 0 && g_reload < 0 && g_fireCD <= -0.25f) g_reload = 0; // auto reload
            }

            // ---- weapon switch (D-pad up) when you own both
            if ((pressed & SCE_CTRL_UP) && g_ownW[0] && g_ownW[1] && !g_mowing && !g_rolling) selectWeapon(1 - g_weapon);

            // ---- quests / interaction
            updatePainting(dt, btn, pressed);
            updateInteraction(pressed);
            updateMower(dt);
            updateCash(dt);
            faceStoryNpc(g_walt, dt);
            faceStoryNpc(g_clerk, dt);
            faceStoryNpc(g_rosa, dt);
            faceStoryNpc(g_mgr, dt);

            // ---- world sim
            updateNpcs(dt, P.x, P.z);
            updateTraffic(dt);
            for (int i = 0; i < MAX_PARTICLES; i++) {
                Particle& q = g_parts[i]; if (q.life <= 0) continue;
                q.life -= dt; q.v.y -= q.grav * dt; q.p = q.p + q.v * dt;
                if (q.p.y < 0.02f) { q.p.y = 0.02f; q.v = q.v * 0.3f; }
            }
        }

        // ================= RENDER =================
        float vfov = lerpf(FOV_HIP, g_gs.adsFov, g_ads);
        float hfov = atanf(tanf(vfov * PI_F / 360.0f) * aspect);
        Vec3 eye = v3(P.x, P.y + EYE_HEIGHT + sinf(P.bobPhase * 2.0f) * 0.03f * P.moveAmt * (1.0f - g_ads * 0.7f), P.z);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        Mat4 proj = mPerspective(vfov, aspect, 0.1f, FAR_PLANE);
        Mat4 view = mMul(mRotX(-P.pitch), mMul(mRotY(-P.yaw), mTrans(-eye.x, -eye.y, -eye.z)));
        glMatrixMode(GL_PROJECTION); glLoadMatrixf(proj.m);
        glMatrixMode(GL_MODELVIEW); glLoadMatrixf(view.m);

        // sky
        setupFog(false);
        glDepthMask(GL_FALSE);
        glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
        buildSky(eye);
        drawMesh(g_sky);
        glDepthMask(GL_TRUE);

        // static world
        setupFog(true);
        glBindTexture(GL_TEXTURE_2D, g_tex[T_ASPHALT]);
        drawMesh(g_outerGround);
        for (int ci = 0; ci < NCHUNK; ci++)
            for (int cj = 0; cj < NCHUNK; cj++) {
                float cx = (CELL_MIN + ci * 2) * CELL + CELL, cz = (CELL_MIN + cj * 2) * CELL + CELL;
                if (!inView(cx, cz, 58.0f, hfov)) continue;
                for (int t = 0; t < NTEX; t++) {
                    if (g_chunks[ci][cj].base[t].count() == 0) continue;
                    glBindTexture(GL_TEXTURE_2D, g_tex[t]);
                    drawMesh(g_chunks[ci][cj].base[t]);
                }
            }
        glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
        for (int i = 0; i < NCELL; i++)
            for (int j = 0; j < NCELL; j++) {
                float cx = (CELL_MIN + i) * CELL + CELL * 0.5f, cz = (CELL_MIN + j) * CELL + CELL * 0.5f;
                float dx = cx - P.x, dz = cz - P.z;
                if (dx * dx + dz * dz > (PROP_DIST + 28) * (PROP_DIST + 28)) continue;
                if (!inView(cx, cz, 30.0f, hfov)) continue;
                drawMesh(g_props[i][j].props);
            }

        // mowable lawn
        if (dist2D(P.x, P.z, 180.0f, 175.0f) < 110.0f && inView(180.0f, 175.0f, 14.0f, hfov)) {
            if (g_lawnDirty) buildLawnMesh();
            glBindTexture(GL_TEXTURE_2D, g_tex[T_GRASS]);
            drawMesh(g_lawnMesh);
            glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
        }

        // Rosa's living room walls
        if (dist2D(P.x, P.z, 220.0f, 182.0f) < 70.0f && inView(220.0f, 182.0f, 10.0f, hfov)) {
            if (g_paintDirty) buildPaintMesh();
            drawMesh(g_paintMesh);
        }

        // dynamic world: NPCs + decals
        g_dyn.clear();
        for (int i = 0; i < NUM_CARS; i++) {
            Car& c = g_cars[i];
            float dx = c.x - P.x, dz = c.z - P.z, d2 = dx * dx + dz * dz;
            if (d2 > 95.0f * 95.0f || !inView(c.x, c.z, 3.0f, hfov)) continue;
            buildCar(g_dyn, c, d2 > 45.0f * 45.0f);
        }
        buildSignals(g_dyn, hfov);
        {
            Npc* sp[4] = {&g_walt, &g_clerk, &g_rosa, &g_mgr};
            for (int i = 0; i < 4; i++)
                if (dist2D(P.x, P.z, sp[i]->x, sp[i]->z) < NPC_DRAW_DIST && inView(sp[i]->x, sp[i]->z, 1.5f, hfov))
                    buildNpc(g_dyn, *sp[i], 0);
            if (dist2D(P.x, P.z, g_mowerPos.x, g_mowerPos.z) < 60.0f) buildMower(g_dyn);
            for (int i = 0; i < MAX_CASH; i++) {
                Cash& c = g_cash[i]; if (!c.used || dist2D(P.x, P.z, c.x, c.z) > 50.0f) continue;
                float cy0 = groundHeight(c.x, c.z) + 0.25f + 0.06f * sinf(g_time * 3.0f + i);
                Mat4 M = mMul(mTrans(c.x, cy0, c.z), mRotY(g_time * 2.5f + i));
                xbox(g_dyn, M, v3(-0.16f, -0.03f, -0.08f), v3(0.16f, 0.03f, 0.08f), col4(0.35f, 0.75f, 0.35f), WORLD_LIGHT);
                xbox(g_dyn, M, v3(-0.04f, -0.035f, -0.085f), v3(0.04f, 0.035f, 0.085f), col4(0.85f, 0.85f, 0.75f), WORLD_LIGHT);
            }
            // floating quest marker
            Npc* mks[4] = {g_q1 == 0 ? &g_walt : 0, g_q2 == 1 ? &g_clerk : 0, g_q3 == 0 ? &g_rosa : 0, !g_hired ? &g_mgr : 0};
            for (int mi = 0; mi < 4; mi++) {
                Npc* mk = mks[mi]; if (!mk) continue;
                float by = groundHeight(mk->x, mk->z) + 2.35f + 0.1f * sinf(g_time * 3.0f);
                Mat4 M = mMul(mTrans(mk->x, by, mk->z), mRotY(g_time * 2.0f));
                Col yc = col4(1.0f, 0.82f, 0.1f);
                xbox(g_dyn, M, v3(-0.07f, 0.16f, -0.07f), v3(0.07f, 0.60f, 0.07f), yc, WORLD_LIGHT);
                xbox(g_dyn, M, v3(-0.07f, -0.02f, -0.07f), v3(0.07f, 0.11f, 0.07f), yc, WORLD_LIGHT);
            }
        }
        for (int i = 0; i < NUM_NPCS; i++) {
            Npc& n = g_npcs[i];
            float dx = n.x - P.x, dz = n.z - P.z, d2 = dx * dx + dz * dz;
            if (d2 > NPC_DRAW_DIST * NPC_DRAW_DIST) continue;
            if (!inView(n.x, n.z, 1.5f, hfov)) continue;
            buildNpc(g_dyn, n, d2 > 38.0f * 38.0f ? 2 : (d2 > 18.0f * 18.0f ? 1 : 0));
        }
        for (int i = 0; i < MAX_DECALS; i++) {
            Decal& d = g_decals[i]; if (!d.used) continue;
            Vec3 ref = fabsf(d.n.y) > 0.9f ? v3(1, 0, 0) : v3(0, 1, 0);
            Vec3 t1 = norm3(cross3(ref, d.n)), t2 = cross3(d.n, t1);
            billboard(g_dyn, d.p, t1, t2, d.s, col4(0.08f, 0.08f, 0.08f));
        }
        drawMesh(g_dyn);

        // particles (blended, no depth write)
        Vec3 cf = camForward();
        Vec3 cr = v3(cosf(P.yaw), 0, -sinf(P.yaw));
        Vec3 cu = cross3(cr, cf);
        g_blend.clear();
        for (int i = 0; i < MAX_PARTICLES; i++) {
            Particle& q = g_parts[i]; if (q.life <= 0) continue;
            Col c = q.c; c.a *= clampf(q.life / q.maxLife * 1.5f, 0, 1);
            billboard(g_blend, q.p, cr, cu, q.size, c);
        }
        if (g_blend.count()) {
            glEnable(GL_BLEND); glDepthMask(GL_FALSE);
            drawMesh(g_blend);
            glDepthMask(GL_TRUE); glDisable(GL_BLEND);
        }
        // laser dot
        if (g_hasGun && !g_mowing && g_equip[CAT_UNDER] == 3 && g_reload < 0 && g_sprint < 0.5f) {
            Vec3 ld = camForward();
            TraceHit lh = traceRay(eye, ld, 120.0f);
            if (lh.type != 0) {
                Vec3 lp = eye + ld * (lh.t - 0.03f);
                float sz = 0.012f + lh.t * 0.0015f;
                g_blend.clear();
                billboard(g_blend, lp, cr, cu, sz * 2.5f, col4(1, 0.1f, 0.05f, 0.35f));
                billboard(g_blend, lp, cr, cu, sz, col4(1, 0.3f, 0.25f, 1));
                glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE); glDepthMask(GL_FALSE);
                drawMesh(g_blend);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
            }
        }

        // ---- viewmodel
        setupFog(false);
        glClear(GL_DEPTH_BUFFER_BIT);
        Mat4 gproj = mPerspective(FOV_GUN, aspect, 0.01f, 5.0f);
        Mat4 ident = mIdent();
        glMatrixMode(GL_PROJECTION); glLoadMatrixf(gproj.m);
        glMatrixMode(GL_MODELVIEW); glLoadMatrixf(ident.m);
        bool scoped = g_equip[CAT_SIGHT] == 3 && g_ads > 0.85f;
        g_gun.clear();
        if (g_ui == UI_BENCH) drawBenchPreview(aspect);
        else if (g_rolling) {
            buildRoller(g_gun);
            drawMesh(g_gun);
        }
        else if (g_hasGun && !g_mowing) {
            buildGunAndArms(g_gun, g_ui != UI_NONE ? 0.0f : dt, rx, ry);
            if (!scoped) drawMesh(g_gun);
        }
        g_blend.clear();
        if (g_ui != UI_BENCH && !scoped && !g_rolling) buildMuzzleFlash(g_blend);
        if (g_blend.count()) {
            glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE); glDepthMask(GL_FALSE);
            drawMesh(g_blend);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
        }

        // ---- HUD
        Mat4 ortho = mOrtho(0, SCR_W, SCR_H, 0, -1, 1);
        glMatrixMode(GL_PROJECTION); glLoadMatrixf(ortho.m);
        glMatrixMode(GL_MODELVIEW); glLoadMatrixf(ident.m);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        g_hud.clear();
        if (g_ui == UI_BENCH) drawBenchHud(g_hud);
        else if (g_ui == UI_BARISTA) drawBarista(g_hud);
        else {
            const float cx = SCR_W * 0.5f, cy = SCR_H * 0.5f;
            if (g_hasGun && !g_mowing && !g_rolling) drawReticles(g_hud);
            float a = 1.0f - g_ads;
            if (!g_hasGun || g_mowing || g_rolling) {
                if (!g_mowing) { rect2(g_hud, cx - 2, cy - 2, 4, 4, col4(0, 0, 0, 0.4f)); rect2(g_hud, cx - 1, cy - 1, 2, 2, col4(1, 1, 1, 0.8f)); }
            } else if (a > 0.02f && g_sprint < 0.5f) {
                float moving = clampf(sqrtf(P.vx * P.vx + P.vz * P.vz) / WALK_SPEED, 0, 1);
                float gap = 7.0f + (g_bloom + 0.012f * (g_gs.spreadHip - 1.0f) + moving * 0.02f) * 520.0f;
                Col c = col4(1, 1, 1, 0.85f * a), sh = col4(0, 0, 0, 0.4f * a);
                rect2(g_hud, cx - gap - 10 - 1, cy - 2, 12, 4, sh); rect2(g_hud, cx + gap - 1, cy - 2, 12, 4, sh);
                rect2(g_hud, cx - 2, cy - gap - 10 - 1, 4, 12, sh); rect2(g_hud, cx - 2, cy + gap - 1, 4, 12, sh);
                rect2(g_hud, cx - gap - 10, cy - 1, 10, 2, c); rect2(g_hud, cx + gap, cy - 1, 10, 2, c);
                rect2(g_hud, cx - 1, cy - gap - 10, 2, 10, c); rect2(g_hud, cx - 1, cy + gap, 2, 10, c);
                rect2(g_hud, cx - 1, cy - 1, 2, 2, c);
            }
            if (g_hitMarker > 0) {
                Col hc = g_hitKill ? col4(1, 0.2f, 0.2f, 1) : col4(1, 1, 1, 1);
                for (int k = 0; k < 4; k++) {
                    float sx = (k & 1) ? 1.0f : -1.0f, sy = (k & 2) ? 1.0f : -1.0f;
                    for (int s = 0; s < 4; s++)
                        rect2(g_hud, cx + sx * (8 + s * 2.5f) - 1.5f, cy + sy * (8 + s * 2.5f) - 1.5f, 3, 3, hc);
                }
            }
            // ammo
            char buf[64];
            if (g_hasGun && !g_rolling) {
            snprintf(buf, sizeof(buf), "%d", g_ammo);
            Col ac = g_ammo <= 5 ? col4(1, 0.35f, 0.3f, 1) : col4(1, 1, 1, 1);
            char mb[16]; snprintf(mb, sizeof(mb), "/%d", g_gs.mag);
            text2(g_hud, SCR_W - 40 - textWidth(WEAPON_NAMES[g_weapon], 2), SCR_H - 92, 2, WEAPON_NAMES[g_weapon], col4(1, 1, 1, 0.75f));
            if (g_ownW[0] && g_ownW[1]) text2(g_hud, SCR_W - 40 - textWidth("UP: SWITCH", 2), SCR_H - 22, 2, "UP: SWITCH", col4(1, 1, 1, 0.5f));
            text2(g_hud, SCR_W - 40 - textWidth(buf, 6) - textWidth(mb, 3) - 8, SCR_H - 66, 6, buf, ac);
            text2(g_hud, SCR_W - 40 - textWidth(mb, 3), SCR_H - 45, 3, mb, col4(0.85f, 0.85f, 0.85f, 1));
            if (g_reload >= 0) {
                const char* r = "RELOADING";
                text2(g_hud, cx - textWidth(r, 3) * 0.5f, cy + 60, 3, r, col4(1, 1, 1, 0.9f));
                float t = clampf(g_reload / g_gs.reload, 0, 1);
                rect2(g_hud, cx - 60, cy + 86, 120, 5, col4(0, 0, 0, 0.5f));
                rect2(g_hud, cx - 60, cy + 86, 120 * t, 5, col4(1, 1, 1, 0.9f));
            } else if (g_ammo == 0) {
                const char* r = "PRESS SQUARE TO RELOAD";
                text2(g_hud, cx - textWidth(r, 2) * 0.5f, cy + 60, 2, r, col4(1, 0.4f, 0.3f, 1));
            }
            } // has gun
            snprintf(buf, sizeof(buf), "$%d", g_money);
            text2(g_hud, 12, 34, 3, buf, col4(0.45f, 1.0f, 0.55f, 1));
            if (g_cashPopT > 0) {
                snprintf(buf, sizeof(buf), "+$%d", g_cashPopAmt);
                text2(g_hud, 12 + textWidth("$000", 3) + 14, 34 - (1.4f - g_cashPopT) * 12, 3, buf, col4(0.45f, 1.0f, 0.55f, clampf(g_cashPopT, 0, 1)));
            }
            if (g_rolling) {
                int pc = (int)paintPercent();
                snprintf(buf, sizeof(buf), "WALLS PAINTED %d%%  (NEED 90%%)", pc);
                text2(g_hud, cx - textWidth(buf, 2) * 0.5f, 46, 2, buf, col4(1, 1, 1, 0.95f));
                rect2(g_hud, cx - 100, 66, 200, 7, col4(0, 0, 0, 0.5f));
                rect2(g_hud, cx - 100, 66, 200 * clampf(pc / 90.0f, 0, 1), 7, PAINT_COLS[g_paintColor]);
                // color picker
                float sx = SCR_W - 230, sy = SCR_H - 92;
                rect2(g_hud, sx - 10, sy - 10, 220, 74, col4(0, 0, 0, 0.5f));
                for (int k = 1; k <= NPAINT; k++) {
                    float bx = sx + (k - 1) * 34;
                    if (k == g_paintColor) rect2(g_hud, bx - 3, sy - 3, 30, 30, col4(1, 1, 1, 1));
                    rect2(g_hud, bx, sy, 24, 24, PAINT_COLS[k]);
                }
                text2(g_hud, sx, sy + 34, 2, PAINT_NAMES[g_paintColor], col4(1, 1, 1));
                if (g_rollHit) { // roller target
                    Col rc = col4(1, 1, 1, 0.7f);
                    rect2(g_hud, cx - 18, cy - 1, 10, 2, rc); rect2(g_hud, cx + 8, cy - 1, 10, 2, rc);
                    rect2(g_hud, cx - 1, cy - 12, 2, 6, rc); rect2(g_hud, cx - 1, cy + 6, 2, 6, rc);
                }
            } else if (g_q1 == 1) {
                int pc = (int)lawnPercent();
                snprintf(buf, sizeof(buf), "LAWN CUT %d%%  (NEED 90%%)", pc);
                text2(g_hud, cx - textWidth(buf, 2) * 0.5f, 46, 2, buf, col4(1, 1, 1, 0.95f));
                rect2(g_hud, cx - 100, 66, 200, 7, col4(0, 0, 0, 0.5f));
                rect2(g_hud, cx - 100, 66, 200 * clampf(pc / 90.0f, 0, 1), 7, col4(0.45f, 0.9f, 0.35f, 1));
            }
            if (g_prompt && g_ui == UI_NONE) {
                float w = textWidth(g_prompt, 3);
                rect2(g_hud, cx - w * 0.5f - 12, SCR_H - 150, w + 24, 36, col4(0, 0, 0, 0.55f));
                text2(g_hud, cx - w * 0.5f, SCR_H - 140, 3, g_prompt, col4(1, 1, 1, 1));
            }
            if (g_toastT > 0) {
                float al = clampf(g_toastT, 0, 1);
                textC(g_hud, cx, 96, 4, g_toast[0], col4(1, 0.85f, 0.25f, al));
                if (g_toast[1][0]) textC(g_hud, cx, 132, 2, g_toast[1], col4(1, 1, 1, al));
            }
            snprintf(buf, sizeof(buf), "FPS %d", fpsShown);
            text2(g_hud, SCR_W - textWidth(buf, 2) - 12, 10, 2, buf, col4(1, 1, 1, 0.7f));
            int aliveN = 0; for (int i = 0; i < NUM_NPCS; i++) if (g_npcs[i].alive) aliveN++;
            snprintf(buf, sizeof(buf), "CITY SANDBOX  POP %d", aliveN);
            text2(g_hud, 12, 10, 2, buf, col4(1, 1, 1, 0.8f));
            // minimal compass heading
            float deg = fmodf(-P.yaw * 180.0f / PI_F + 360.0f, 360.0f);
            const char* dirs[8] = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            const char* hd = dirs[((int)((deg + 22.5f) / 45.0f)) % 8];
            text2(g_hud, cx - textWidth(hd, 3) * 0.5f, 12, 3, hd, col4(1, 1, 1, 0.8f));

            if (g_helpT > 0 && g_ui == UI_NONE) {
                float al = clampf(g_helpT, 0, 1);
                const char* lines[] = {"L STICK MOVE   R STICK LOOK", "TRIANGLE TALK / INTERACT",
                                       "CROSS JUMP   HOLD CIRCLE SPRINT", "SELECT PHONE   START PAUSE"};
                for (int i = 0; i < 4; i++) text2(g_hud, 14, SCR_H - 110 + i * 22, 2, lines[i], col4(1, 1, 1, al));
            }
            if (g_ui == UI_PAUSE) {
                rect2(g_hud, 0, 0, SCR_W, SCR_H, col4(0, 0, 0, 0.6f));
                const char* t = "PAUSED";
                text2(g_hud, cx - textWidth(t, 7) * 0.5f, 70, 7, t, col4(1, 1, 1, 1));
                const char* lines[] = {"LEFT STICK - MOVE", "RIGHT STICK - LOOK", "TRIANGLE - TALK / INTERACT",
                                       "L - AIM DOWN SIGHTS", "R - SHOOT", "SQUARE - RELOAD", "CROSS - JUMP",
                                       "HOLD CIRCLE - SPRINT", "SELECT - PHONE (IN GAME)", "", "START - RESUME", "SELECT - QUIT"};
                for (int i = 0; i < 12; i++)
                    text2(g_hud, cx - textWidth(lines[i], 3) * 0.5f, 150 + i * 28, 3, lines[i], col4(1, 1, 1, 0.95f));
            }
            if (g_ui == UI_PHONE) drawPhone(g_hud);
            if (g_ui == UI_DIALOG) drawDialog(g_hud);
        }
        glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
        drawMesh(g_hud);
        glDisable(GL_BLEND);
        glEnable(GL_DEPTH_TEST);

        vglSwapBuffers(GL_FALSE);
    }


    sceKernelExitProcess(0);
    return 0;
}
