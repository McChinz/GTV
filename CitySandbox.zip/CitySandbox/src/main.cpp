// =====================================================================
//  CITY SANDBOX  v0.1  -  PS Vita (vitaGL, fixed-function pipeline)
//  First-person open-world city sandbox: walk a ~320m city grid with
//  NPC pedestrians, hold a rifle, aim down iron sights and shoot.
//
//  Controls
//    Left stick   move              Right stick  look
//    L            aim down sights   R            shoot (full auto)
//    Square       reload            Cross        jump
//    Circle(hold) sprint            Start        pause / controls
//    Pause menu: Select = quit to LiveArea
//
//  Requires ur0:data/libshacccg.suprx (runtime shader compiler).
// =====================================================================
#include <vitaGL.h>
#include <psp2/ctrl.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/power.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <vector>

#define SCR_W 960
#define SCR_H 544
#define PI_F 3.14159265f

// ---------------------------------------------------------------------
//  Tunables
// ---------------------------------------------------------------------
static const float CELL        = 40.0f;   // block pitch (road center to road center)
static const float ROAD_HALF   = 6.0f;    // half width of each road
static const float CURB_H      = 0.15f;   // sidewalk height
static const int   CELL_MIN    = -1;      // cells -1..8 (outer ring = skyline wall)
static const int   NCELL       = 10;
static const int   NCHUNK      = 5;       // 2x2 cells per render chunk
static const float WORLD_MIN   = -5.0f;   // playable area clamp
static const float WORLD_MAX   = 325.0f;

static const float WALK_SPEED   = 5.4f;   // ~60s to cross 320m
static const float SPRINT_SPEED = 8.6f;
static const float ADS_SPEED_MUL= 0.55f;
static const float JUMP_VEL     = 4.6f;
static const float GRAVITY      = 13.0f;
static const float EYE_HEIGHT   = 1.62f;
static const float PLAYER_RAD   = 0.35f;

static const float LOOK_YAW     = 2.7f;   // rad/s at full stick
static const float LOOK_PITCH   = 1.9f;
static const float ADS_LOOK_MUL = 0.45f;

static const float FOV_HIP      = 72.0f;
static const float FOV_ADS      = 46.0f;
static const float FOV_GUN      = 54.0f;
static const float FAR_PLANE    = 155.0f;
static const float FOG_START    = 50.0f;
static const float FOG_END      = 140.0f;
static const float PROP_DIST    = 62.0f;  // props (trees, cars, lights) LOD distance
static const float NPC_DRAW_DIST= 65.0f;

static const int   MAG_SIZE     = 30;
static const float FIRE_DELAY   = 0.095f; // ~630 rpm
static const float RELOAD_TIME  = 1.75f;
static const int   NUM_NPCS     = 90;

// ---------------------------------------------------------------------
//  Math
// ---------------------------------------------------------------------
struct Vec3 { float x, y, z; };
static inline Vec3 v3(float x, float y, float z) { Vec3 r; r.x = x; r.y = y; r.z = z; return r; }
static inline Vec3 operator+(Vec3 a, Vec3 b) { return v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static inline Vec3 operator-(Vec3 a, Vec3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static inline Vec3 operator*(Vec3 a, float s) { return v3(a.x * s, a.y * s, a.z * s); }
static inline float dot3(Vec3 a, Vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline Vec3 cross3(Vec3 a, Vec3 b) { return v3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
static inline float len3(Vec3 a) { return sqrtf(dot3(a, a)); }
static inline Vec3 norm3(Vec3 a) { float l = len3(a); return l > 1e-6f ? a * (1.0f / l) : v3(0, 1, 0); }
static inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static inline float approach(float cur, float target, float rate, float dt) {
    float k = 1.0f - expf(-rate * dt);
    return cur + (target - cur) * k;
}
static inline float wrapAngle(float a) {
    while (a > PI_F) a -= 2.0f * PI_F;
    while (a < -PI_F) a += 2.0f * PI_F;
    return a;
}

struct Mat4 { float m[16]; };
static Mat4 mIdent() { Mat4 r; memset(r.m, 0, sizeof(r.m)); r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.0f; return r; }
static Mat4 mMul(const Mat4& a, const Mat4& b) {
    Mat4 r;
    for (int c = 0; c < 4; c++)
        for (int rr = 0; rr < 4; rr++) {
            float s = 0;
            for (int k = 0; k < 4; k++) s += a.m[k * 4 + rr] * b.m[c * 4 + k];
            r.m[c * 4 + rr] = s;
        }
    return r;
}
static Mat4 mTrans(float x, float y, float z) { Mat4 r = mIdent(); r.m[12] = x; r.m[13] = y; r.m[14] = z; return r; }
static Mat4 mScale(float s) { Mat4 r = mIdent(); r.m[0] = r.m[5] = r.m[10] = s; return r; }
static Mat4 mRotX(float a) { Mat4 r = mIdent(); float c = cosf(a), s = sinf(a); r.m[5] = c; r.m[9] = -s; r.m[6] = s; r.m[10] = c; return r; }
static Mat4 mRotY(float a) { Mat4 r = mIdent(); float c = cosf(a), s = sinf(a); r.m[0] = c; r.m[8] = s; r.m[2] = -s; r.m[10] = c; return r; }
static Mat4 mRotZ(float a) { Mat4 r = mIdent(); float c = cosf(a), s = sinf(a); r.m[0] = c; r.m[4] = -s; r.m[1] = s; r.m[5] = c; return r; }
static Vec3 mApply(const Mat4& M, Vec3 p) {
    return v3(M.m[0] * p.x + M.m[4] * p.y + M.m[8] * p.z + M.m[12],
              M.m[1] * p.x + M.m[5] * p.y + M.m[9] * p.z + M.m[13],
              M.m[2] * p.x + M.m[6] * p.y + M.m[10] * p.z + M.m[14]);
}
static Mat4 mPerspective(float fovyDeg, float aspect, float n, float f) {
    Mat4 r; memset(r.m, 0, sizeof(r.m));
    float t = 1.0f / tanf(fovyDeg * PI_F / 360.0f);
    r.m[0] = t / aspect; r.m[5] = t;
    r.m[10] = (f + n) / (n - f); r.m[11] = -1.0f;
    r.m[14] = (2.0f * f * n) / (n - f);
    return r;
}
static Mat4 mOrtho(float l, float rr, float b, float t, float n, float f) {
    Mat4 r = mIdent();
    r.m[0] = 2.0f / (rr - l); r.m[5] = 2.0f / (t - b); r.m[10] = -2.0f / (f - n);
    r.m[12] = -(rr + l) / (rr - l); r.m[13] = -(t + b) / (t - b); r.m[14] = -(f + n) / (f - n);
    return r;
}

// ---------------------------------------------------------------------
//  RNG
// ---------------------------------------------------------------------
static uint32_t g_rng = 0x1234567u;
static inline uint32_t xrand() { g_rng ^= g_rng << 13; g_rng ^= g_rng >> 17; g_rng ^= g_rng << 5; return g_rng; }
static inline float frand() { return (xrand() & 0xFFFFFF) / 16777216.0f; }
static inline float frange(float a, float b) { return a + (b - a) * frand(); }
static inline float hash2(int x, int y, int s) {
    uint32_t h = (uint32_t)x * 374761393u + (uint32_t)y * 668265263u + (uint32_t)s * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u; h ^= h >> 16;
    return (h & 0xFFFF) / 65535.0f;
}

// ---------------------------------------------------------------------
//  Mesh (separate tightly packed arrays -> simplest vitaGL client path)
// ---------------------------------------------------------------------
struct Col { float r, g, b, a; };
static inline Col col4(float r, float g, float b, float a = 1.0f) { Col c; c.r = r; c.g = g; c.b = b; c.a = a; return c; }
static inline Col shadeC(Col c, float s) { return col4(c.r * s, c.g * s, c.b * s, c.a); }

struct Mesh {
    std::vector<float> p, t, c;
    void clear() { p.clear(); t.clear(); c.clear(); }
    int count() const { return (int)(p.size() / 3); }
    inline void v(Vec3 q, float u, float w, const Col& k) {
        p.push_back(q.x); p.push_back(q.y); p.push_back(q.z);
        t.push_back(u); t.push_back(w);
        c.push_back(k.r); c.push_back(k.g); c.push_back(k.b); c.push_back(k.a);
    }
};

static void quad(Mesh& m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, float u0, float v0, float u1, float v1, Col k) {
    m.v(a, u0, v0, k); m.v(b, u1, v0, k); m.v(c, u1, v1, k);
    m.v(a, u0, v0, k); m.v(c, u1, v1, k); m.v(d, u0, v1, k);
}

// Horizontal quad (facing up), uv = world coords * uvs
static void topQuad(Mesh& m, float x0, float z0, float x1, float z1, float y, float uvs, Col k) {
    quad(m, v3(x0, y, z0), v3(x1, y, z0), v3(x1, y, z1), v3(x0, y, z1),
         x0 * uvs, z0 * uvs, x1 * uvs, z1 * uvs, k);
}

// u repeats: uSize > 0 -> round(width/uSize) whole repeats, uSize < 0 -> width/|uSize|, 0 -> 1
static inline float repeatsFor(float w, float s) {
    if (s > 0) { float r = floorf(w / s + 0.5f); return r < 1 ? 1 : r; }
    if (s < 0) return w / -s;
    return 1.0f;
}

// Four vertical walls of an axis aligned box (no top/bottom)
static void sideFaces(Mesh& m, float x0, float z0, float x1, float z1, float y0, float y1,
                      float uSize, float vSize, Col k) {
    float ux = repeatsFor(x1 - x0, uSize), uz = repeatsFor(z1 - z0, uSize);
    float vv = repeatsFor(y1 - y0, vSize);
    quad(m, v3(x0, y0, z0), v3(x1, y0, z0), v3(x1, y1, z0), v3(x0, y1, z0), 0, 0, ux, vv, shadeC(k, 0.62f)); // -z
    quad(m, v3(x1, y0, z1), v3(x0, y0, z1), v3(x0, y1, z1), v3(x1, y1, z1), 0, 0, ux, vv, shadeC(k, 0.82f)); // +z
    quad(m, v3(x0, y0, z1), v3(x0, y0, z0), v3(x0, y1, z0), v3(x0, y1, z1), 0, 0, uz, vv, shadeC(k, 0.70f)); // -x
    quad(m, v3(x1, y0, z0), v3(x1, y0, z1), v3(x1, y1, z1), v3(x1, y1, z0), 0, 0, uz, vv, shadeC(k, 0.92f)); // +x
}

static void boxSolid(Mesh& m, float x0, float y0, float z0, float x1, float y1, float z1, Col k) {
    sideFaces(m, x0, z0, x1, z1, y0, y1, 0, 0, k);
    quad(m, v3(x0, y1, z0), v3(x1, y1, z0), v3(x1, y1, z1), v3(x0, y1, z1), 0, 0, 1, 1, k);
}

// Transformed box with simple directional lighting (for NPCs, gun)
static void xbox(Mesh& m, const Mat4& X, Vec3 mn, Vec3 mx, Col k, Vec3 L) {
    Vec3 p[8];
    for (int i = 0; i < 8; i++)
        p[i] = mApply(X, v3((i & 1) ? mx.x : mn.x, (i & 2) ? mx.y : mn.y, (i & 4) ? mx.z : mn.z));
    static const int F[6][4] = {
        {0, 1, 3, 2}, {5, 4, 6, 7}, {4, 0, 2, 6}, {1, 5, 7, 3}, {2, 3, 7, 6}, {4, 5, 1, 0}
    };
    for (int f = 0; f < 6; f++) {
        Vec3 a = p[F[f][0]], b = p[F[f][1]], c = p[F[f][2]], d = p[F[f][3]];
        Vec3 n = norm3(cross3(d - a, b - a));
        float s = 0.55f + 0.45f * fmaxf(0.0f, dot3(n, L));
        quad(m, a, b, c, d, 0, 0, 1, 1, shadeC(k, s));
    }
}

// Box stretched between two points (arms)
static void beam(Mesh& m, Vec3 a, Vec3 b, float w, Col k, Vec3 L) {
    Vec3 dz = b - a; float l = len3(dz); if (l < 1e-4f) return;
    dz = dz * (1.0f / l);
    Vec3 ref = fabsf(dz.y) < 0.9f ? v3(0, 1, 0) : v3(1, 0, 0);
    Vec3 dx = norm3(cross3(ref, dz));
    Vec3 dy = cross3(dz, dx);
    Mat4 X = mIdent();
    X.m[0] = dx.x; X.m[1] = dx.y; X.m[2] = dx.z;
    X.m[4] = dy.x; X.m[5] = dy.y; X.m[6] = dy.z;
    X.m[8] = dz.x; X.m[9] = dz.y; X.m[10] = dz.z;
    X.m[12] = a.x; X.m[13] = a.y; X.m[14] = a.z;
    xbox(m, X, v3(-w, -w, 0), v3(w, w, l), k, L);
}

static void drawMesh(const Mesh& m) {
    int n = m.count();
    if (n <= 0) return;
    const int CH = 30000; // keep each draw well under 16-bit index limits
    for (int s = 0; s < n; s += CH) {
        int cnt = n - s; if (cnt > CH) cnt = CH;
        glVertexPointer(3, GL_FLOAT, 0, &m.p[s * 3]);
        glTexCoordPointer(2, GL_FLOAT, 0, &m.t[s * 2]);
        glColorPointer(4, GL_FLOAT, 0, &m.c[s * 4]);
        glDrawArrays(GL_TRIANGLES, 0, cnt);
    }
}

// ---------------------------------------------------------------------
//  Textures (procedural)
// ---------------------------------------------------------------------
enum { T_WHITE = 0, T_ASPHALT, T_SIDEWALK, T_FACADE, T_SHOP, T_GRASS, NTEX };
static GLuint g_tex[NTEX];

static GLuint uploadTex(int w, int h, const unsigned char* d, bool mip) {
    GLuint id; glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, d);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    if (mip) {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glGenerateMipmap(GL_TEXTURE_2D);
    } else {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    }
    return id;
}

static inline void px(unsigned char* d, int w, int x, int y, int r, int g, int b) {
    unsigned char* q = d + (y * w + x) * 4;
    q[0] = (unsigned char)clampf((float)r, 0, 255); q[1] = (unsigned char)clampf((float)g, 0, 255);
    q[2] = (unsigned char)clampf((float)b, 0, 255); q[3] = 255;
}

static void makeTextures() {
    static unsigned char buf[128 * 128 * 4];
    // white
    memset(buf, 255, 8 * 8 * 4);
    g_tex[T_WHITE] = uploadTex(8, 8, buf, false);

    // asphalt (one repeat = 5m)
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        float n = hash2(x, y, 1) * 18 + hash2(x / 4, y / 4, 2) * 10;
        int g = (int)(66 + n);
        if (hash2(x, y, 3) > 0.985f) g += 30;
        px(buf, 64, x, y, g, g, g + 3);
    }
    g_tex[T_ASPHALT] = uploadTex(64, 64, buf, true);

    // sidewalk tiles (one repeat = 2m, 1m tiles)
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        int g = (int)(176 + hash2(x, y, 4) * 12 + hash2(x / 8, y / 8, 5) * 8);
        if ((x % 32) < 1 || (y % 32) < 1) g -= 42;
        px(buf, 64, x, y, g, g - 2, g - 6);
    }
    g_tex[T_SIDEWALK] = uploadTex(64, 64, buf, true);

    // facade: one window per repeat (4m x 3.5m), v=0 is the bottom
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        int g = (int)(218 + hash2(x, y, 6) * 14);
        int r = g, gg = g - 3, b = g - 8;
        bool win = x >= 12 && x < 52 && y >= 18 && y < 54;
        bool frame = win && (x < 14 || x >= 50 || y < 20 || y >= 52 || (x >= 31 && x < 33));
        bool sill = x >= 10 && x < 54 && y >= 15 && y < 18;
        if (sill) { r = gg = b = 190; }
        if (win) {
            if (frame) { r = 78; gg = 80; b = 86; }
            else {
                float t = (y - 20) / 32.0f;
                r = (int)(52 + t * 40); gg = (int)(70 + t * 42); b = (int)(92 + t * 46);
                if (((x + y) % 26) < 5) { r += 26; gg += 26; b += 26; }
                if (hash2(x / 6, y / 6, 7) > 0.8f) { r -= 12; gg -= 12; b -= 12; }
            }
        }
        if (y < 2) { r -= 30; gg -= 30; b -= 30; }
        px(buf, 64, x, y, r, gg, b);
    }
    g_tex[T_FACADE] = uploadTex(64, 64, buf, true);

    // shop front (one repeat = 6m wide, ground floor height)
    for (int y = 0; y < 64; y++) for (int x = 0; x < 128; x++) {
        int r, g, b;
        if (y < 5) { r = g = b = 70; }
        else if (y < 46) {
            bool frame = x < 6 || x >= 122 || y < 8 || y >= 43 || (x >= 52 && x < 55) || (x >= 75 && x < 78);
            bool door = x >= 55 && x < 75;
            if (frame) { r = 45; g = 45; b = 50; }
            else {
                float t = (y - 8) / 35.0f;
                r = (int)(34 + t * 30); g = (int)(46 + t * 34); b = (int)(60 + t * 40);
                if (door) { r -= 8; g -= 8; b -= 4; }
                if (((x * 2 + y) % 40) < 6) { r += 22; g += 22; b += 22; }
                if (!door && y < 20 && hash2(x / 10, y / 5, 8) > 0.55f) { r += 25; g += 18; b += 8; } // goods inside
            }
        }
        else if (y < 48) { r = g = b = 60; }
        else if (y < 58) { r = g = b = 236; }      // sign band (tinted per shop)
        else { int q = (int)(205 + hash2(x, y, 9) * 12); r = q; g = q - 3; b = q - 8; }
        px(buf, 128, x, y, r, g, b);
    }
    g_tex[T_SHOP] = uploadTex(128, 64, buf, true);

    // grass
    for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
        float n = hash2(x, y, 10) * 30 + hash2(x / 5, y / 5, 11) * 20;
        px(buf, 64, x, y, (int)(52 + n * 0.6f), (int)(98 + n), (int)(40 + n * 0.3f));
    }
    g_tex[T_GRASS] = uploadTex(64, 64, buf, true);
}

// ---------------------------------------------------------------------
//  World
// ---------------------------------------------------------------------
struct AABB { float mn[3], mx[3]; };
static std::vector<AABB> g_cols;

static void addCol(float x0, float y0, float z0, float x1, float y1, float z1) {
    AABB a; a.mn[0] = x0; a.mn[1] = y0; a.mn[2] = z0; a.mx[0] = x1; a.mx[1] = y1; a.mx[2] = z1;
    g_cols.push_back(a);
}

struct Chunk { Mesh base[NTEX]; };
struct CellProps { Mesh props; };
static Chunk g_chunks[NCHUNK][NCHUNK];
static CellProps g_props[NCELL][NCELL];
static Mesh g_outerGround;

static inline bool inBlock(float x, float z) {
    float fx = x - floorf(x / CELL) * CELL;
    float fz = z - floorf(z / CELL) * CELL;
    return fx >= ROAD_HALF && fx <= CELL - ROAD_HALF && fz >= ROAD_HALF && fz <= CELL - ROAD_HALF;
}
static inline float groundHeight(float x, float z) { return inBlock(x, z) ? CURB_H : 0.0f; }

static const Col BUILDING_TINTS[] = {
    {0.95f, 0.90f, 0.80f, 1}, {0.80f, 0.80f, 0.82f, 1}, {0.78f, 0.52f, 0.42f, 1}, {0.88f, 0.78f, 0.62f, 1},
    {0.72f, 0.78f, 0.86f, 1}, {0.98f, 0.97f, 0.95f, 1}, {0.66f, 0.62f, 0.58f, 1}, {0.85f, 0.70f, 0.55f, 1},
    {0.62f, 0.40f, 0.33f, 1}, {0.90f, 0.86f, 0.74f, 1}
};
static const Col SHOP_TINTS[] = {
    {1.0f, 0.70f, 0.65f, 1}, {0.70f, 0.85f, 1.0f, 1}, {0.75f, 1.0f, 0.75f, 1}, {1.0f, 0.95f, 0.65f, 1},
    {0.95f, 0.95f, 0.95f, 1}, {1.0f, 0.80f, 0.55f, 1}, {0.85f, 0.75f, 1.0f, 1}
};
static const Col CAR_COLS[] = {
    {0.75f, 0.10f, 0.10f, 1}, {0.10f, 0.20f, 0.55f, 1}, {0.85f, 0.85f, 0.85f, 1}, {0.12f, 0.12f, 0.13f, 1},
    {0.55f, 0.57f, 0.60f, 1}, {0.95f, 0.75f, 0.10f, 1}, {0.15f, 0.40f, 0.20f, 1}, {0.40f, 0.10f, 0.35f, 1}
};
#define PICK(arr) arr[xrand() % (sizeof(arr) / sizeof(arr[0]))]

static void addBuilding(Chunk& C, float x0, float z0, float x1, float z1, float H) {
    Col tint = PICK(BUILDING_TINTS);
    Col shop = PICK(SHOP_TINTS);
    const float GF = CURB_H + 4.0f;
    // ground floor shops
    sideFaces(C.base[T_SHOP], x0, z0, x1, z1, CURB_H, GF, 6.0f, 0, shop);
    // upper floors
    sideFaces(C.base[T_FACADE], x0, z0, x1, z1, GF, H, 4.0f, 3.5f, tint);
    // ledge above shops
    Col ledge = shadeC(tint, 0.75f);
    Mesh& W = C.base[T_WHITE];
    boxSolid(W, x0 - 0.2f, GF, z0 - 0.2f, x1 + 0.2f, GF + 0.35f, z1 + 0.2f, ledge);
    // roof + parapet
    Col roof = col4(0.45f, 0.44f, 0.43f);
    topQuad(W, x0, z0, x1, z1, H, 0, roof);
    float pt = 0.3f, ph = 0.7f;
    sideFaces(W, x0, z0, x1, z1, H, H + ph, 0, 0, ledge);                         // parapet outside
    sideFaces(W, x0 + pt, z0 + pt, x1 - pt, z1 - pt, H, H + ph, 0, 0, shadeC(ledge, 0.8f)); // inside
    // rooftop unit
    if (frand() < 0.7f) {
        float cx = frange(x0 + 2.5f, x1 - 2.5f), cz = frange(z0 + 2.5f, z1 - 2.5f);
        float s = frange(1.0f, 2.2f);
        boxSolid(W, cx - s, H, cz - s, cx + s, H + frange(1.2f, 2.6f), cz + s, col4(0.6f, 0.6f, 0.62f));
    }
    addCol(x0, 0, z0, x1, H + ph, z1);
}

static void addTree(Mesh& M, float x, float z, float y) {
    float h = frange(2.6f, 3.4f);
    Col trunk = col4(0.38f, 0.27f, 0.18f);
    Col leaf = col4(frange(0.18f, 0.28f), frange(0.42f, 0.55f), frange(0.15f, 0.22f));
    boxSolid(M, x - 0.14f, y, z - 0.14f, x + 0.14f, y + h, z + 0.14f, trunk);
    float r = frange(1.3f, 1.8f);
    boxSolid(M, x - r, y + h - 0.4f, z - r, x + r, y + h + 1.6f, z + r, leaf);
    float r2 = r * 0.65f;
    boxSolid(M, x - r2, y + h + 1.6f, z - r2, x + r2, y + h + 2.6f, z + r2, shadeC(leaf, 1.08f));
    addCol(x - 0.14f, y, z - 0.14f, x + 0.14f, y + h, z + 0.14f);
    addCol(x - r, y + h - 0.4f, z - r, x + r, y + h + 2.6f, z + r);
}

static void addStreetLight(Mesh& M, float x, float z, float dirx, float dirz) {
    Col pole = col4(0.25f, 0.27f, 0.28f);
    float y = CURB_H;
    boxSolid(M, x - 0.08f, y, z - 0.08f, x + 0.08f, y + 6.2f, z + 0.08f, pole);
    float ax = x + dirx * 1.6f, az = z + dirz * 1.6f;
    float mnx = fminf(x, ax) - 0.06f, mxx = fmaxf(x, ax) + 0.06f;
    float mnz = fminf(z, az) - 0.06f, mxz = fmaxf(z, az) + 0.06f;
    boxSolid(M, mnx, y + 6.0f, mnz, mxx, y + 6.12f, mxz, pole);
    boxSolid(M, ax - 0.25f, y + 5.8f, az - 0.25f, ax + 0.25f, y + 6.0f, az + 0.25f, col4(0.95f, 0.93f, 0.80f));
    addCol(x - 0.08f, y, z - 0.08f, x + 0.08f, y + 6.2f, z + 0.08f);
}

static void addCar(Mesh& M, float cx, float cz, bool alongX) {
    Col body = PICK(CAR_COLS);
    Col glass = col4(0.12f, 0.16f, 0.20f);
    Col tire = col4(0.07f, 0.07f, 0.07f);
    float hl = frange(2.0f, 2.3f), hw = 0.9f;
    // local helper: (a = along, c = across)
    #define CBOX(a0, y0, c0, a1, y1, c1, K) do { \
        if (alongX) boxSolid(M, cx + (a0), (y0), cz + (c0), cx + (a1), (y1), cz + (c1), K); \
        else        boxSolid(M, cx + (c0), (y0), cz + (a0), cx + (c1), (y1), cz + (a1), K); } while (0)
    CBOX(-hl, 0.32f, -hw, hl, 0.95f, hw, body);
    CBOX(-hl * 0.55f, 0.95f, -hw * 0.88f, hl * 0.4f, 1.42f, hw * 0.88f, glass);
    CBOX(-hl * 0.5f, 1.42f, -hw * 0.84f, hl * 0.35f, 1.50f, hw * 0.84f, body);
    for (int i = 0; i < 4; i++) {
        float a = (i & 1) ? hl * 0.65f : -hl * 0.65f;
        float c = (i & 2) ? hw * 0.75f : -hw * 0.95f;
        CBOX(a - 0.33f, 0.0f, c, a + 0.33f, 0.62f, c + 0.2f, tire);
    }
    CBOX(hl - 0.02f, 0.62f, -hw * 0.8f, hl + 0.03f, 0.80f, -hw * 0.4f, col4(1, 1, 0.9f));
    CBOX(hl - 0.02f, 0.62f, hw * 0.4f, hl + 0.03f, 0.80f, hw * 0.8f, col4(1, 1, 0.9f));
    CBOX(-hl - 0.03f, 0.62f, -hw * 0.8f, -hl + 0.02f, 0.78f, -hw * 0.45f, col4(0.8f, 0.05f, 0.05f));
    CBOX(-hl - 0.03f, 0.62f, hw * 0.45f, -hl + 0.02f, 0.78f, hw * 0.8f, col4(0.8f, 0.05f, 0.05f));
    #undef CBOX
    if (alongX) addCol(cx - hl, 0, cz - hw, cx + hl, 1.5f, cz + hw);
    else        addCol(cx - hw, 0, cz - hl, cx + hw, 1.5f, cz + hl);
}

static void addMarkings(Mesh& M, float x0, float z0) {
    const float y = 0.02f;
    Col yel = col4(0.92f, 0.78f, 0.20f), wht = col4(0.92f, 0.92f, 0.90f);
    // center dashes on the road along z at x=x0 and along x at z=z0
    for (float s = 9.0f; s < 31.0f; s += 4.0f) {
        topQuad(M, x0 - 0.08f, z0 + s, x0 + 0.08f, z0 + s + 2.0f, y, 0, yel);
        topQuad(M, x0 + s, z0 - 0.08f, x0 + s + 2.0f, z0 + 0.08f, y, 0, yel);
    }
    // crosswalks around intersection (x0, z0)
    for (int k = 0; k < 6; k++) {
        float o = -5.5f + k * 2.0f;
        topQuad(M, x0 + o, z0 + 6.0f, x0 + o + 1.0f, z0 + 9.0f, y, 0, wht);
        topQuad(M, x0 + o, z0 - 9.0f, x0 + o + 1.0f, z0 - 6.0f, y, 0, wht);
        topQuad(M, x0 + 6.0f, z0 + o, x0 + 9.0f, z0 + o + 1.0f, y, 0, wht);
        topQuad(M, x0 - 9.0f, z0 + o, x0 - 6.0f, z0 + o + 1.0f, y, 0, wht);
    }
}

static void genWorld() {
    g_rng = 0xC17C17u;
    g_cols.clear();
    const Col WHITE = col4(1, 1, 1);
    topQuad(g_outerGround, -300, -300, 620, 620, -0.05f, 0.2f, col4(0.85f, 0.85f, 0.85f));

    for (int i = CELL_MIN; i < CELL_MIN + NCELL; i++)
    for (int j = CELL_MIN; j < CELL_MIN + NCELL; j++) {
        Chunk& C = g_chunks[(i - CELL_MIN) / 2][(j - CELL_MIN) / 2];
        Mesh& P = g_props[i - CELL_MIN][j - CELL_MIN].props;
        float x0 = i * CELL, z0 = j * CELL;
        float bx0 = x0 + ROAD_HALF, bx1 = x0 + CELL - ROAD_HALF;
        float bz0 = z0 + ROAD_HALF, bz1 = z0 + CELL - ROAD_HALF;
        bool outer = i < 0 || i > 7 || j < 0 || j > 7;
        bool park = !outer && ((i == 3 && j == 4) || (i == 6 && j == 1) || frand() < 0.06f);

        // road surface + markings
        topQuad(C.base[T_ASPHALT], x0, z0, x0 + CELL, z0 + CELL, 0.0f, 0.2f, WHITE);
        addMarkings(P, x0, z0);

        // sidewalk slab + curb
        topQuad(C.base[T_SIDEWALK], bx0, bz0, bx1, bz1, CURB_H, 0.5f, WHITE);
        sideFaces(C.base[T_SIDEWALK], bx0, bz0, bx1, bz1, 0.0f, CURB_H, -2.0f, -2.0f, col4(0.9f, 0.9f, 0.9f));

        float lx0 = bx0 + 3.0f, lx1 = bx1 - 3.0f, lz0 = bz0 + 3.0f, lz1 = bz1 - 3.0f; // 22m lot
        if (park) {
            topQuad(C.base[T_GRASS], lx0, lz0, lx1, lz1, CURB_H + 0.01f, 0.3f, WHITE);
            float cxm = (lx0 + lx1) * 0.5f, czm = (lz0 + lz1) * 0.5f;
            topQuad(C.base[T_SIDEWALK], cxm - 1.2f, lz0, cxm + 1.2f, lz1, CURB_H + 0.02f, 0.5f, WHITE);
            topQuad(C.base[T_SIDEWALK], lx0, czm - 1.2f, lx1, czm + 1.2f, CURB_H + 0.02f, 0.5f, WHITE);
            // fountain
            Mesh& W = C.base[T_WHITE];
            Col stone = col4(0.75f, 0.73f, 0.70f);
            boxSolid(W, cxm - 3.0f, CURB_H, czm - 3.0f, cxm + 3.0f, CURB_H + 0.6f, czm + 3.0f, stone);
            topQuad(W, cxm - 2.6f, czm - 2.6f, cxm + 2.6f, czm + 2.6f, CURB_H + 0.62f, 0, col4(0.30f, 0.50f, 0.70f));
            boxSolid(W, cxm - 0.4f, CURB_H, czm - 0.4f, cxm + 0.4f, CURB_H + 2.2f, czm + 0.4f, stone);
            addCol(cxm - 3.0f, 0, czm - 3.0f, cxm + 3.0f, CURB_H + 0.6f, czm + 3.0f);
            addCol(cxm - 0.4f, 0, czm - 0.4f, cxm + 0.4f, CURB_H + 2.2f, czm + 0.4f);
            for (int t = 0; t < 10; t++) {
                float tx = frange(lx0 + 1.5f, lx1 - 1.5f), tz = frange(lz0 + 1.5f, lz1 - 1.5f);
                if (fabsf(tx - cxm) < 4.0f || fabsf(tz - czm) < 4.0f) continue;
                addTree(P, tx, tz, CURB_H);
            }
        } else {
            // building height: taller downtown, tall skyline wall on the outer ring
            float dc = sqrtf((x0 + 20 - 160) * (x0 + 20 - 160) + (z0 + 20 - 160) * (z0 + 20 - 160));
            float boost = clampf(1.0f - dc / 200.0f, 0.0f, 1.0f);
            float hmin = outer ? 28.0f : 9.0f, hvar = outer ? 30.0f : 18.0f + 34.0f * boost;
            int type = xrand() % 4;
            float mx = (lx0 + lx1) * 0.5f + frange(-3, 3), mz = (lz0 + lz1) * 0.5f + frange(-3, 3);
            #define HGT() (hmin + frand() * hvar)
            if (type == 0) addBuilding(C, lx0, lz0, lx1, lz1, HGT());
            else if (type == 1) { addBuilding(C, lx0, lz0, mx, lz1, HGT()); addBuilding(C, mx, lz0, lx1, lz1, HGT()); }
            else if (type == 2) { addBuilding(C, lx0, lz0, lx1, mz, HGT()); addBuilding(C, lx0, mz, lx1, lz1, HGT()); }
            else {
                addBuilding(C, lx0, lz0, mx, mz, HGT()); addBuilding(C, mx, lz0, lx1, mz, HGT());
                addBuilding(C, lx0, mz, mx, lz1, HGT()); addBuilding(C, mx, mz, lx1, lz1, HGT());
            }
            #undef HGT
        }

        // street lights at block corners, arms reaching over the road
        addStreetLight(P, bx0 + 0.4f, bz0 + 0.4f, -0.707f, -0.707f);
        addStreetLight(P, bx1 - 0.4f, bz0 + 0.4f, 0.707f, -0.707f);
        addStreetLight(P, bx1 - 0.4f, bz1 - 0.4f, 0.707f, 0.707f);
        addStreetLight(P, bx0 + 0.4f, bz1 - 0.4f, -0.707f, 0.707f);

        if (!outer) {
            // street trees along the curb
            for (int s = 0; s < 4; s++)
                for (int k = 1; k <= 3; k++) {
                    if (frand() > 0.55f) continue;
                    float a = 7.0f * k;
                    if (s == 0) addTree(P, bx0 + a, bz0 + 0.45f, CURB_H);
                    if (s == 1) addTree(P, bx0 + a, bz1 - 0.45f, CURB_H);
                    if (s == 2) addTree(P, bx0 + 0.45f, bz0 + a, CURB_H);
                    if (s == 3) addTree(P, bx1 - 0.45f, bz0 + a, CURB_H);
                }
            // parked cars along curbs
            for (int s = 0; s < 4; s++)
                for (int k = 0; k < 2; k++) {
                    if (frand() > 0.35f) continue;
                    float a = (k == 0 ? 9.0f : 19.0f) + frange(0, 1.5f);
                    if (s == 0) addCar(P, bx0 + a, bz0 - 1.3f, true);
                    if (s == 1) addCar(P, bx0 + a, bz1 + 1.3f, true);
                    if (s == 2) addCar(P, bx0 - 1.3f, bz0 + a, false);
                    if (s == 3) addCar(P, bx1 + 1.3f, bz0 + a, false);
                }
        }
    }
}

// ---------------------------------------------------------------------
//  Raycast
// ---------------------------------------------------------------------
static bool rayAabb(Vec3 o, Vec3 d, const float* mn, const float* mx, float maxT, float& tOut, Vec3& nOut) {
    float tmin = 0.0f, tmax = maxT; int axis = -1; float sign = 0;
    const float oo[3] = {o.x, o.y, o.z}, dd[3] = {d.x, d.y, d.z};
    for (int a = 0; a < 3; a++) {
        if (fabsf(dd[a]) < 1e-8f) { if (oo[a] < mn[a] || oo[a] > mx[a]) return false; continue; }
        float inv = 1.0f / dd[a];
        float t1 = (mn[a] - oo[a]) * inv, t2 = (mx[a] - oo[a]) * inv;
        float s = -1.0f;
        if (t1 > t2) { float tmp = t1; t1 = t2; t2 = tmp; s = 1.0f; }
        if (t1 > tmin) { tmin = t1; axis = a; sign = s; }
        if (t2 < tmax) tmax = t2;
        if (tmin > tmax) return false;
    }
    if (axis < 0) return false;
    tOut = tmin;
    nOut = v3(axis == 0 ? sign : 0.0f, axis == 1 ? sign : 0.0f, axis == 2 ? sign : 0.0f);
    return true;
}

// ---------------------------------------------------------------------
//  NPCs
// ---------------------------------------------------------------------
struct Npc {
    float x, z, yaw;
    int node, target, prev;
    float ox, oz, speed, phase, scale;
    Col shirt, pants, skin, hair, shoes;
    bool alive;
    float health, panic, deadT, fall, fallDir, flinch;
};
static Npc g_npcs[NUM_NPCS];

static const Col SKINS[] = {{0.96f, 0.80f, 0.69f, 1}, {0.87f, 0.67f, 0.52f, 1}, {0.66f, 0.46f, 0.32f, 1}, {0.45f, 0.30f, 0.20f, 1}, {0.93f, 0.75f, 0.60f, 1}};
static const Col SHIRTS[] = {{0.80f, 0.15f, 0.15f, 1}, {0.15f, 0.35f, 0.75f, 1}, {0.95f, 0.95f, 0.95f, 1}, {0.15f, 0.15f, 0.15f, 1}, {0.20f, 0.60f, 0.30f, 1}, {0.95f, 0.75f, 0.20f, 1}, {0.55f, 0.30f, 0.65f, 1}, {0.45f, 0.45f, 0.48f, 1}, {0.95f, 0.50f, 0.20f, 1}, {0.50f, 0.75f, 0.90f, 1}};
static const Col PANTS[] = {{0.15f, 0.20f, 0.40f, 1}, {0.10f, 0.10f, 0.11f, 1}, {0.70f, 0.62f, 0.45f, 1}, {0.35f, 0.35f, 0.37f, 1}, {0.25f, 0.30f, 0.20f, 1}};
static const Col HAIRS[] = {{0.08f, 0.06f, 0.05f, 1}, {0.30f, 0.18f, 0.10f, 1}, {0.75f, 0.60f, 0.30f, 1}, {0.45f, 0.45f, 0.45f, 1}, {0.50f, 0.22f, 0.10f, 1}};

static inline Vec3 nodePos(int n) {
    int b = n / 4, c = n % 4;
    int bi = b % 8, bj = b / 8;
    float x = bi * CELL + ((c == 1 || c == 2) ? 32.5f : 7.5f);
    float z = bj * CELL + ((c >= 2) ? 32.5f : 7.5f);
    return v3(x, 0, z);
}
static int nodeNeighbors(int n, int* out) {
    int b = n / 4, c = n % 4, bi = b % 8, bj = b / 8, k = 0;
    out[k++] = b * 4 + (c + 1) % 4;
    out[k++] = b * 4 + (c + 3) % 4;
    if ((c == 0 || c == 3) && bi > 0) out[k++] = (bj * 8 + bi - 1) * 4 + (c == 0 ? 1 : 2);
    if ((c == 1 || c == 2) && bi < 7) out[k++] = (bj * 8 + bi + 1) * 4 + (c == 1 ? 0 : 3);
    if ((c == 0 || c == 1) && bj > 0) out[k++] = ((bj - 1) * 8 + bi) * 4 + (c == 0 ? 3 : 2);
    if ((c == 2 || c == 3) && bj < 7) out[k++] = ((bj + 1) * 8 + bi) * 4 + (c == 3 ? 0 : 1);
    return k;
}

static void npcPickNext(Npc& n, float px, float pz) {
    int nb[6]; int k = nodeNeighbors(n.node, nb);
    int choice = -1;
    if (n.panic > 0) {
        float best = -1;
        for (int i = 0; i < k; i++) {
            Vec3 p = nodePos(nb[i]);
            float d = (p.x - px) * (p.x - px) + (p.z - pz) * (p.z - pz) + frand() * 30.0f;
            if (d > best) { best = d; choice = nb[i]; }
        }
    } else {
        for (int tries = 0; tries < 6; tries++) {
            int c = nb[xrand() % k];
            if (c != n.prev || frand() < 0.1f) { choice = c; break; }
        }
        if (choice < 0) choice = nb[0];
    }
    n.prev = n.node;
    n.target = choice;
}

static void npcSpawn(Npc& n, float px, float pz, bool farOnly) {
    for (int tries = 0; tries < 50; tries++) {
        n.node = xrand() % (64 * 4);
        Vec3 p = nodePos(n.node);
        float d = sqrtf((p.x - px) * (p.x - px) + (p.z - pz) * (p.z - pz));
        if (!farOnly || d > 70.0f) break;
    }
    n.ox = frange(-0.7f, 0.7f); n.oz = frange(-0.7f, 0.7f);
    Vec3 p = nodePos(n.node);
    n.x = p.x + n.ox; n.z = p.z + n.oz;
    n.prev = -1; n.panic = 0;
    npcPickNext(n, px, pz);
    n.speed = frange(1.1f, 1.6f);
    n.phase = frand() * 6.28f;
    n.scale = frange(0.92f, 1.08f);
    n.shirt = PICK(SHIRTS); n.pants = PICK(PANTS); n.skin = PICK(SKINS); n.hair = PICK(HAIRS);
    n.shoes = frand() < 0.5f ? col4(0.08f, 0.08f, 0.08f) : col4(0.85f, 0.85f, 0.85f);
    n.alive = true; n.health = 100; n.deadT = 0; n.fall = 0; n.fallDir = 1; n.flinch = 0;
    n.yaw = frand() * 6.28f;
}

static void updateNpcs(float dt, float px, float pz) {
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i];
        if (!n.alive) {
            n.fall = fminf(1.0f, n.fall + dt * 2.2f);
            n.deadT += dt;
            float d2 = (n.x - px) * (n.x - px) + (n.z - pz) * (n.z - pz);
            if (n.deadT > 25.0f && d2 > 60.0f * 60.0f) npcSpawn(n, px, pz, true);
            continue;
        }
        if (n.panic > 0) n.panic -= dt;
        if (n.flinch > 0) n.flinch = fmaxf(0, n.flinch - dt * 4.0f);
        Vec3 t = nodePos(n.target);
        float tx = t.x + n.ox, tz = t.z + n.oz;
        float dx = tx - n.x, dz = tz - n.z;
        float d = sqrtf(dx * dx + dz * dz);
        float spd = n.panic > 0 ? 4.6f : n.speed;
        if (d < 0.15f) { n.node = n.target; npcPickNext(n, px, pz); continue; }
        float step = fminf(d, spd * dt);
        n.x += dx / d * step; n.z += dz / d * step;
        float want = atan2f(-dx, -dz);
        n.yaw += wrapAngle(want - n.yaw) * fminf(1.0f, dt * 8.0f);
        n.phase += dt * spd * 4.0f;
    }
}

static void panicAround(float x, float z, float radius) {
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i];
        if (!n.alive) continue;
        float d2 = (n.x - x) * (n.x - x) + (n.z - z) * (n.z - z);
        if (d2 < radius * radius) {
            bool was = n.panic > 0;
            n.panic = frange(7.0f, 11.0f);
            if (!was) {
                // mid-segment: keep going or turn back, whichever leads away from the threat
                Vec3 a = nodePos(n.node), b = nodePos(n.target);
                float da = (a.x - x) * (a.x - x) + (a.z - z) * (a.z - z);
                float db = (b.x - x) * (b.x - x) + (b.z - z) * (b.z - z);
                if (da > db) { int t = n.node; n.node = n.target; n.target = t; n.prev = -1; }
            }
        }
    }
}

static const Vec3 WORLD_LIGHT = {0.48f, 0.78f, 0.40f};

static void buildNpc(Mesh& m, const Npc& n, int lod) {
    float g = groundHeight(n.x, n.z);
    float fallA = n.alive ? (-0.35f * n.flinch * n.fallDir) : (n.fallDir * n.fall * 1.5708f);
    float lift = n.alive ? 0.0f : 0.13f * n.fall;
    Mat4 B = mMul(mTrans(n.x, g + lift, n.z), mMul(mRotY(n.yaw), mMul(mRotX(fallA), mScale(n.scale))));
    float amp = n.alive ? (n.panic > 0 ? 0.85f : 0.55f) : 0.0f;
    float sw = sinf(n.phase) * amp;
    Vec3 L = WORLD_LIGHT;
    if (lod >= 2) { // far: 3 boxes
        xbox(m, B, v3(-0.18f, 0.0f, -0.10f), v3(0.18f, 0.86f, 0.10f), n.pants, L);
        xbox(m, B, v3(-0.28f, 0.84f, -0.12f), v3(0.28f, 1.46f, 0.12f), n.shirt, L);
        xbox(m, B, v3(-0.11f, 1.47f, -0.12f), v3(0.11f, 1.76f, 0.12f), n.skin, L);
        return;
    }

    Mat4 legL = mMul(B, mMul(mTrans(0, 0.86f, 0), mMul(mRotX(sw), mTrans(0, -0.86f, 0))));
    Mat4 legR = mMul(B, mMul(mTrans(0, 0.86f, 0), mMul(mRotX(-sw), mTrans(0, -0.86f, 0))));
    float armSpread = n.alive ? 0.0f : 0.9f;
    Mat4 armL = mMul(B, mMul(mTrans(0, 1.40f, 0), mMul(mRotZ(-armSpread), mMul(mRotX(-sw * 0.9f), mTrans(0, -1.40f, 0)))));
    Mat4 armR = mMul(B, mMul(mTrans(0, 1.40f, 0), mMul(mRotZ(armSpread), mMul(mRotX(sw * 0.9f), mTrans(0, -1.40f, 0)))));

    xbox(m, legL, v3(-0.18f, 0.06f, -0.09f), v3(-0.02f, 0.88f, 0.09f), n.pants, L);
    xbox(m, legR, v3(0.02f, 0.06f, -0.09f), v3(0.18f, 0.88f, 0.09f), n.pants, L);
    xbox(m, B, v3(-0.21f, 0.84f, -0.12f), v3(0.21f, 1.46f, 0.12f), n.shirt, L);
    xbox(m, armL, v3(-0.31f, 1.10f, -0.07f), v3(-0.21f, 1.44f, 0.07f), n.shirt, L);
    xbox(m, armR, v3(0.21f, 1.10f, -0.07f), v3(0.31f, 1.44f, 0.07f), n.shirt, L);
    xbox(m, armL, v3(-0.30f, 0.80f, -0.06f), v3(-0.22f, 1.10f, 0.06f), n.skin, L);
    xbox(m, armR, v3(0.22f, 0.80f, -0.06f), v3(0.30f, 1.10f, 0.06f), n.skin, L);
    xbox(m, B, v3(-0.11f, 1.47f, -0.12f), v3(0.11f, 1.72f, 0.11f), n.skin, L);
    xbox(m, B, v3(-0.12f, 1.66f, -0.13f), v3(0.12f, 1.77f, 0.13f), n.hair, L);
    if (lod == 0) {
        xbox(m, B, v3(-0.12f, 1.50f, 0.06f), v3(0.12f, 1.70f, 0.13f), n.hair, L);
        xbox(m, legL, v3(-0.18f, 0.0f, -0.14f), v3(-0.02f, 0.07f, 0.09f), n.shoes, L);
        xbox(m, legR, v3(0.02f, 0.0f, -0.14f), v3(0.18f, 0.07f, 0.09f), n.shoes, L);
        Col eye = col4(0.1f, 0.1f, 0.1f);
        xbox(m, B, v3(-0.07f, 1.59f, -0.125f), v3(-0.03f, 1.62f, -0.118f), eye, L);
        xbox(m, B, v3(0.03f, 1.59f, -0.125f), v3(0.07f, 1.62f, -0.118f), eye, L);
    }
}

// ---------------------------------------------------------------------
//  Effects
// ---------------------------------------------------------------------
struct Particle { Vec3 p, v; float life, maxLife, size, grav; Col c; };
static const int MAX_PARTICLES = 300;
static Particle g_parts[MAX_PARTICLES];
static int g_partNext = 0;

static void spawnParticle(Vec3 p, Vec3 v, float life, float size, float grav, Col c) {
    Particle& q = g_parts[g_partNext]; g_partNext = (g_partNext + 1) % MAX_PARTICLES;
    q.p = p; q.v = v; q.life = life; q.maxLife = life; q.size = size; q.grav = grav; q.c = c;
}

struct Decal { Vec3 p, n; float s; bool used; };
static const int MAX_DECALS = 120;
static Decal g_decals[MAX_DECALS];
static int g_decalNext = 0;

static void addDecal(Vec3 p, Vec3 n) {
    Decal& d = g_decals[g_decalNext]; g_decalNext = (g_decalNext + 1) % MAX_DECALS;
    d.p = p + n * 0.025f; d.n = n; d.s = frange(0.06f, 0.09f); d.used = true;
}

// ---------------------------------------------------------------------
//  Font (5x7, column-major, bit0 = top)
// ---------------------------------------------------------------------
static const char FONT_CHARS[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ/:-.+|()%!, ";
static const unsigned char FONT_DATA[][5] = {
    {0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},{0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},
    {0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},{0x3C,0x4A,0x49,0x49,0x30},{0x01,0x71,0x09,0x05,0x03},
    {0x36,0x49,0x49,0x49,0x36},{0x06,0x49,0x49,0x29,0x1E},
    {0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},{0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},
    {0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x09,0x01},{0x3E,0x41,0x49,0x49,0x7A},{0x7F,0x08,0x08,0x08,0x7F},
    {0x00,0x41,0x7F,0x41,0x00},{0x20,0x40,0x41,0x3F,0x01},{0x7F,0x08,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
    {0x7F,0x02,0x0C,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},{0x3E,0x41,0x41,0x41,0x3E},{0x7F,0x09,0x09,0x09,0x06},
    {0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},{0x46,0x49,0x49,0x49,0x31},{0x01,0x01,0x7F,0x01,0x01},
    {0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},{0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,0x08,0x14,0x63},
    {0x07,0x08,0x70,0x08,0x07},{0x61,0x51,0x49,0x45,0x43},
    {0x20,0x10,0x08,0x04,0x02},{0x00,0x36,0x36,0x00,0x00},{0x08,0x08,0x08,0x08,0x08},{0x00,0x60,0x60,0x00,0x00},
    {0x08,0x08,0x3E,0x08,0x08},{0x00,0x00,0x7F,0x00,0x00},{0x00,0x1C,0x22,0x41,0x00},{0x00,0x41,0x22,0x1C,0x00},
    {0x23,0x13,0x08,0x64,0x62},{0x00,0x00,0x5F,0x00,0x00},{0x00,0x50,0x30,0x00,0x00},{0x00,0x00,0x00,0x00,0x00}
};

static void rect2(Mesh& m, float x, float y, float w, float h, Col c) {
    quad(m, v3(x, y, 0), v3(x + w, y, 0), v3(x + w, y + h, 0), v3(x, y + h, 0), 0, 0, 1, 1, c);
}

static void text2(Mesh& m, float x, float y, float s, const char* str, Col c, bool shadow = true) {
    for (int pass = shadow ? 0 : 1; pass < 2; pass++) {
        Col k = pass == 0 ? col4(0, 0, 0, c.a * 0.7f) : c;
        float off = pass == 0 ? s * 0.6f : 0.0f;
        float cx = x;
        for (const char* p = str; *p; p++) {
            char ch = *p; if (ch >= 'a' && ch <= 'z') ch -= 32;
            const char* f = strchr(FONT_CHARS, ch);
            if (f && ch) {
                const unsigned char* g = FONT_DATA[f - FONT_CHARS];
                for (int col = 0; col < 5; col++)
                    for (int row = 0; row < 7; row++)
                        if (g[col] & (1 << row)) rect2(m, cx + col * s + off, y + row * s + off, s, s, k);
            }
            cx += 6 * s;
        }
    }
}
static float textWidth(const char* s, float sc) { return strlen(s) * 6 * sc - sc; }

// ---------------------------------------------------------------------
//  Game state
// ---------------------------------------------------------------------
struct Player {
    float x, y, z, vx, vz, vy, yaw, pitch;
    bool ground;
    float bobPhase, moveAmt;
};
static Player P;

static float g_ads = 0, g_sprint = 0, g_fireCD = 0, g_recoil = 0, g_bloom = 0, g_flash = 0;
static float g_reload = -1;            // <0 not reloading, else elapsed time
static int   g_ammo = MAG_SIZE;
static float g_hitMarker = 0; static bool g_hitKill = false;
static float g_swayX = 0, g_swayY = 0;
static bool  g_paused = false;
static float g_helpT = 9.0f;
static float g_flashRot = 0;

static Vec3 camForward() {
    return v3(-sinf(P.yaw) * cosf(P.pitch), sinf(P.pitch), -cosf(P.yaw) * cosf(P.pitch));
}

static void collidePlayer() {
    float feet = P.y;
    for (size_t i = 0; i < g_cols.size(); i++) {
        const AABB& a = g_cols[i];
        if (a.mx[1] < feet + 0.35f || a.mn[1] > feet + 1.8f) continue;
        if (P.x < a.mn[0] - 1 || P.x > a.mx[0] + 1 || P.z < a.mn[2] - 1 || P.z > a.mx[2] + 1) continue;
        float cx = clampf(P.x, a.mn[0], a.mx[0]);
        float cz = clampf(P.z, a.mn[2], a.mx[2]);
        float dx = P.x - cx, dz = P.z - cz;
        float d2 = dx * dx + dz * dz;
        if (d2 >= PLAYER_RAD * PLAYER_RAD) continue;
        if (d2 > 1e-8f) {
            float d = sqrtf(d2), push = PLAYER_RAD - d;
            P.x += dx / d * push; P.z += dz / d * push;
        } else {
            float pl = P.x - a.mn[0], pr = a.mx[0] - P.x, pb = P.z - a.mn[2], pf = a.mx[2] - P.z;
            float mn = fminf(fminf(pl, pr), fminf(pb, pf));
            if (mn == pl) P.x = a.mn[0] - PLAYER_RAD;
            else if (mn == pr) P.x = a.mx[0] + PLAYER_RAD;
            else if (mn == pb) P.z = a.mn[2] - PLAYER_RAD;
            else P.z = a.mx[2] + PLAYER_RAD;
        }
    }
    // NPC bodies push the player gently
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i]; if (!n.alive) continue;
        float dx = P.x - n.x, dz = P.z - n.z, d2 = dx * dx + dz * dz;
        float r = PLAYER_RAD + 0.3f;
        if (d2 < r * r && d2 > 1e-6f) { float d = sqrtf(d2); P.x += dx / d * (r - d); P.z += dz / d * (r - d); }
    }
    P.x = clampf(P.x, WORLD_MIN, WORLD_MAX);
    P.z = clampf(P.z, WORLD_MIN, WORLD_MAX);
}

static void fireShot() {
    g_ammo--;
    g_fireCD = FIRE_DELAY;
    g_flash = 0.05f; g_flashRot = frand() * 6.28f;
    g_recoil = fminf(g_recoil + 1.0f, 2.5f);

    Vec3 eye = v3(P.x, P.y + EYE_HEIGHT, P.z);
    Vec3 f = camForward();
    Vec3 right = v3(cosf(P.yaw), 0, -sinf(P.yaw));
    Vec3 up = cross3(right, f);
    float moving = clampf(sqrtf(P.vx * P.vx + P.vz * P.vz) / WALK_SPEED, 0, 1);
    float spread = lerpf(0.028f, 0.0015f, g_ads) + g_bloom + moving * 0.02f * (1.0f - g_ads * 0.8f) + (P.ground ? 0 : 0.04f);
    float ang = frand() * 6.28f, rad = sqrtf(frand()) * spread;
    Vec3 dir = norm3(f + right * (cosf(ang) * rad) + up * (sinf(ang) * rad));
    g_bloom = fminf(g_bloom + lerpf(0.006f, 0.0025f, g_ads), 0.05f);

    // view kick
    P.pitch += lerpf(0.016f, 0.009f, g_ads);
    P.yaw += frange(-1, 1) * lerpf(0.006f, 0.003f, g_ads);

    // trace
    const float MAXT = 300.0f;
    float bestT = MAXT; Vec3 bestN = v3(0, 1, 0); int hitType = 0; int hitNpc = -1;
    for (size_t i = 0; i < g_cols.size(); i++) {
        float t; Vec3 n;
        if (rayAabb(eye, dir, g_cols[i].mn, g_cols[i].mx, bestT, t, n) && t < bestT) { bestT = t; bestN = n; hitType = 1; }
    }
    if (dir.y < -1e-4f) {
        float t = (CURB_H - eye.y) / dir.y;
        Vec3 p = eye + dir * t;
        if (!inBlock(p.x, p.z)) t = (0.0f - eye.y) / dir.y;
        if (t > 0 && t < bestT) { bestT = t; bestN = v3(0, 1, 0); hitType = 1; }
    }
    bool head = false;
    for (int i = 0; i < NUM_NPCS; i++) {
        Npc& n = g_npcs[i]; if (!n.alive) continue;
        float g = groundHeight(n.x, n.z), h = 1.78f * n.scale;
        float mn[3] = {n.x - 0.27f, g, n.z - 0.27f}, mx[3] = {n.x + 0.27f, g + h, n.z + 0.27f};
        float t; Vec3 nn;
        if (rayAabb(eye, dir, mn, mx, bestT, t, nn) && t < bestT) {
            bestT = t; bestN = nn; hitType = 2; hitNpc = i;
            head = (eye.y + dir.y * t) > g + 1.46f * n.scale;
        }
    }
    Vec3 hp = eye + dir * bestT;
    if (hitType == 2) {
        Npc& n = g_npcs[hitNpc];
        n.health -= head ? 100.0f : 34.0f;
        Vec3 fwd = v3(-sinf(n.yaw), 0, -cosf(n.yaw));
        n.fallDir = dot3(dir, fwd) < 0 ? 1.0f : -1.0f;
        n.flinch = 1.0f;
        for (int k = 0; k < 10; k++)
            spawnParticle(hp, v3(frange(-1.2f, 1.2f), frange(0.2f, 2.0f), frange(-1.2f, 1.2f)) - dir * 1.5f,
                          frange(0.25f, 0.5f), frange(0.04f, 0.09f), 6.0f, col4(0.55f, 0.02f, 0.02f, 1));
        g_hitMarker = 0.18f;
        g_hitKill = n.health <= 0;
        if (n.health <= 0) { n.alive = false; n.deadT = 0; n.fall = 0; }
        panicAround(n.x, n.z, 45.0f);
    } else if (hitType == 1) {
        addDecal(hp, bestN);
        for (int k = 0; k < 7; k++) {
            Vec3 v = bestN * frange(1.0f, 3.0f) + v3(frange(-1.5f, 1.5f), frange(0.0f, 1.5f), frange(-1.5f, 1.5f));
            float g = 0.55f + frand() * 0.2f;
            spawnParticle(hp + bestN * 0.05f, v, frange(0.25f, 0.6f), frange(0.04f, 0.1f), 7.0f, col4(g, g * 0.97f, g * 0.9f, 0.9f));
        }
        spawnParticle(hp + bestN * 0.05f, bestN * 3.0f, 0.06f, 0.12f, 0, col4(1.0f, 0.85f, 0.4f, 1));
    }
    panicAround(P.x, P.z, 32.0f);
}

// ---------------------------------------------------------------------
//  Rendering helpers
// ---------------------------------------------------------------------
static Mesh g_dyn, g_blend, g_gun, g_hud, g_sky;

static bool inView(float cx, float cz, float radius, float hfov) {
    float dx = cx - P.x, dz = cz - P.z;
    float d = sqrtf(dx * dx + dz * dz);
    if (d < radius + 2.0f) return true;
    if (d - radius > FAR_PLANE) return false;
    float fx = -sinf(P.yaw), fz = -cosf(P.yaw);
    float ca = (dx * fx + dz * fz) / d;
    float allowed = hfov + asinf(fminf(1.0f, radius / d)) + 0.12f + fabsf(P.pitch) * 0.6f;
    if (allowed >= PI_F) return true;
    return ca >= cosf(allowed);
}

static void buildSky(Vec3 eye) {
    g_sky.clear();
    Col hz = col4(0.78f, 0.84f, 0.90f), mid = col4(0.60f, 0.74f, 0.90f), top = col4(0.36f, 0.56f, 0.86f);
    const int SEG = 24; const float R = 100.0f;
    float ys[4] = {-40.0f, 8.0f, 45.0f, 85.0f};
    Col cs[4] = {hz, hz, mid, top};
    for (int s = 0; s < SEG; s++) {
        float a0 = s * 2 * PI_F / SEG, a1 = (s + 1) * 2 * PI_F / SEG;
        float rf[4] = {1.0f, 1.0f, 0.85f, 0.45f};
        for (int r = 0; r < 3; r++) {
            Vec3 p00 = eye + v3(cosf(a0) * R * rf[r], ys[r], sinf(a0) * R * rf[r]);
            Vec3 p10 = eye + v3(cosf(a1) * R * rf[r], ys[r], sinf(a1) * R * rf[r]);
            Vec3 p11 = eye + v3(cosf(a1) * R * rf[r + 1], ys[r + 1], sinf(a1) * R * rf[r + 1]);
            Vec3 p01 = eye + v3(cosf(a0) * R * rf[r + 1], ys[r + 1], sinf(a0) * R * rf[r + 1]);
            g_sky.v(p00, 0, 0, cs[r]); g_sky.v(p10, 0, 0, cs[r]); g_sky.v(p11, 0, 0, cs[r + 1]);
            g_sky.v(p00, 0, 0, cs[r]); g_sky.v(p11, 0, 0, cs[r + 1]); g_sky.v(p01, 0, 0, cs[r + 1]);
        }
        Vec3 c0 = eye + v3(cosf(a0) * R * rf[3], ys[3], sinf(a0) * R * rf[3]);
        Vec3 c1 = eye + v3(cosf(a1) * R * rf[3], ys[3], sinf(a1) * R * rf[3]);
        g_sky.v(c0, 0, 0, top); g_sky.v(c1, 0, 0, top); g_sky.v(eye + v3(0, 95.0f, 0), 0, 0, top);
    }
    // sun
    Vec3 sd = norm3(v3(0.48f, 0.55f, 0.40f)) * 90.0f;
    Vec3 sc = eye + sd;
    Vec3 sr = norm3(cross3(sd, v3(0, 1, 0))), su = norm3(cross3(sr, sd));
    float S = 6.0f;
    quad(g_sky, sc - sr * S - su * S, sc + sr * S - su * S, sc + sr * S + su * S, sc - sr * S + su * S, 0, 0, 1, 1, col4(1.0f, 0.97f, 0.85f));
}

static void billboard(Mesh& m, Vec3 p, Vec3 r, Vec3 u, float s, Col c) {
    quad(m, p - r * s - u * s, p + r * s - u * s, p + r * s + u * s, p - r * s + u * s, 0, 0, 1, 1, c);
}

static void buildGunAndArms(Mesh& m, float dt, float lookX, float lookY) {
    const Vec3 L = norm3(v3(0.35f, 0.85f, 0.45f));
    float ads = g_ads;
    float rl = 0, mag = 0;
    if (g_reload >= 0) {
        float t = clampf(g_reload / RELOAD_TIME, 0, 1);
        rl = sinf(t * PI_F);
        if (t > 0.22f && t < 0.78f) mag = sinf((t - 0.22f) / 0.56f * PI_F) * 0.22f;
    }
    float sp = g_sprint * (1.0f - ads);
    // sway lags behind the look input
    g_swayX = approach(g_swayX, -lookX * 0.018f, 8.0f, dt);
    g_swayY = approach(g_swayY, lookY * 0.014f, 8.0f, dt);
    float swayMul = 1.0f - ads * 0.8f;
    float bob = P.moveAmt * (1.0f - ads * 0.85f);
    float bx = sinf(P.bobPhase) * 0.011f * bob * (1.0f + sp);
    float by = -fabsf(cosf(P.bobPhase)) * 0.010f * bob * (1.0f + sp);

    Vec3 hip = v3(0.15f, -0.155f, -0.23f), aim = v3(0.0f, -0.042f, -0.21f);
    Vec3 off = hip * (1.0f - ads) + aim * ads;
    off = off + v3(g_swayX * swayMul + bx, g_swayY * swayMul + by - rl * 0.05f - sp * 0.03f, g_recoil * 0.028f + sp * 0.02f);
    float yawO = 0.035f * (1 - ads) + sp * 0.55f;
    float pitchO = g_recoil * 0.05f * (1.0f - ads * 0.4f) + rl * 0.25f - sp * 0.25f;
    float rollO = rl * 0.55f + sp * 0.2f;

    Mat4 G = mMul(mTrans(off.x, off.y, off.z), mMul(mRotY(yawO), mMul(mRotX(pitchO), mRotZ(rollO))));
    Col metal = col4(0.16f, 0.16f, 0.17f), dark = col4(0.08f, 0.08f, 0.09f), poly = col4(0.22f, 0.21f, 0.19f);
    xbox(m, G, v3(-0.021f, -0.030f, -0.10f), v3(0.021f, 0.022f, 0.14f), metal, L);     // receiver
    xbox(m, G, v3(-0.016f, 0.022f, -0.09f), v3(0.016f, 0.030f, 0.12f), dark, L);       // top rail
    xbox(m, G, v3(-0.024f, -0.036f, -0.34f), v3(0.024f, 0.016f, -0.10f), poly, L);     // handguard
    xbox(m, G, v3(-0.008f, -0.014f, -0.46f), v3(0.008f, 0.002f, -0.34f), dark, L);     // barrel
    xbox(m, G, v3(-0.013f, -0.017f, -0.49f), v3(0.013f, 0.005f, -0.445f), metal, L);   // muzzle brake
    // front sight
    xbox(m, G, v3(-0.010f, 0.016f, -0.335f), v3(0.010f, 0.024f, -0.315f), metal, L);
    xbox(m, G, v3(-0.0022f, 0.024f, -0.330f), v3(0.0022f, 0.042f, -0.323f), dark, L);
    xbox(m, G, v3(-0.013f, 0.024f, -0.332f), v3(-0.010f, 0.047f, -0.320f), metal, L);
    xbox(m, G, v3(0.010f, 0.024f, -0.332f), v3(0.013f, 0.047f, -0.320f), metal, L);
    // rear sight (notch at sight line y = 0.042)
    xbox(m, G, v3(-0.013f, 0.030f, 0.090f), v3(0.013f, 0.042f, 0.106f), metal, L);
    xbox(m, G, v3(-0.013f, 0.042f, 0.090f), v3(-0.005f, 0.055f, 0.106f), metal, L);
    xbox(m, G, v3(0.005f, 0.042f, 0.090f), v3(0.013f, 0.055f, 0.106f), metal, L);
    // magazine (drops during reload)
    Mat4 MG = mMul(G, mMul(mTrans(0, -mag, mag * 0.3f), mRotX(0.12f)));
    xbox(m, MG, v3(-0.014f, -0.16f, -0.075f), v3(0.014f, -0.028f, -0.018f), dark, L);
    // grip, trigger guard, stock
    Mat4 GR = mMul(G, mMul(mTrans(0, -0.03f, 0.085f), mRotX(-0.3f)));
    xbox(m, GR, v3(-0.015f, -0.10f, -0.02f), v3(0.015f, 0.0f, 0.022f), poly, L);
    xbox(m, G, v3(-0.004f, -0.052f, 0.02f), v3(0.004f, -0.046f, 0.07f), metal, L);
    xbox(m, G, v3(-0.017f, -0.045f, 0.14f), v3(0.017f, 0.015f, 0.34f), poly, L);
    xbox(m, G, v3(-0.019f, -0.075f, 0.30f), v3(0.019f, 0.018f, 0.36f), dark, L);

    // arms
    Col sleeve = col4(0.24f, 0.28f, 0.20f), glove = col4(0.12f, 0.11f, 0.10f);
    Vec3 rHand = mApply(GR, v3(0, -0.05f, 0.0f));
    Vec3 rElbow = mApply(G, v3(0.11f, -0.20f, 0.28f));
    Vec3 lHand = mApply(G, v3(0.0f, -0.045f, -0.26f));
    Vec3 lHandM = mApply(MG, v3(0.0f, -0.16f, -0.05f));
    if (g_reload >= 0 && mag > 0.02f) lHand = lHandM; // left hand follows the mag
    Vec3 lElbow = mApply(G, v3(-0.17f, -0.24f, -0.06f));
    beam(m, rHand, rElbow, 0.032f, sleeve, L);
    beam(m, rElbow, rElbow + v3(0.10f, -0.25f, 0.25f), 0.042f, sleeve, L);
    beam(m, lHand, lElbow, 0.030f, sleeve, L);
    beam(m, lElbow, lElbow + v3(-0.12f, -0.25f, 0.25f), 0.042f, sleeve, L);
    Mat4 RH = mMul(mTrans(rHand.x, rHand.y, rHand.z), mMul(mRotY(yawO), mRotX(pitchO)));
    Mat4 LH = mMul(mTrans(lHand.x, lHand.y, lHand.z), mMul(mRotY(yawO), mRotX(pitchO)));
    xbox(m, RH, v3(-0.028f, -0.03f, -0.035f), v3(0.028f, 0.03f, 0.035f), glove, L);
    xbox(m, LH, v3(-0.03f, -0.025f, -0.04f), v3(0.03f, 0.03f, 0.04f), glove, L);
}

static void buildMuzzleFlash(Mesh& m) {
    if (g_flash <= 0) return;
    // recompute muzzle point the same way as the gun (approximate: no sway/bob)
    float ads = g_ads;
    Vec3 hip = v3(0.15f, -0.155f, -0.23f), aim = v3(0.0f, -0.042f, -0.21f);
    Vec3 off = hip * (1.0f - ads) + aim * ads + v3(g_swayX, g_swayY, g_recoil * 0.028f);
    Mat4 G = mMul(mTrans(off.x, off.y, off.z), mMul(mRotY(0.035f * (1 - ads)), mRotX(g_recoil * 0.05f * (1.0f - ads * 0.4f))));
    Vec3 tip = mApply(G, v3(0, -0.006f, -0.50f));
    Col c = col4(1.0f, 0.75f, 0.35f, 0.95f);
    for (int k = 0; k < 3; k++) {
        float a = g_flashRot + k * PI_F / 3.0f;
        Vec3 d = v3(cosf(a), sinf(a), 0), pp = v3(-sinf(a), cosf(a), 0);
        float l = 0.07f + 0.03f * k, w = 0.012f;
        quad(m, tip - d * l - pp * w, tip + d * l - pp * w, tip + d * l + pp * w, tip - d * l + pp * w, 0, 0, 1, 1, c);
    }
    billboard(m, tip, v3(1, 0, 0), v3(0, 1, 0), 0.035f, col4(1, 0.95f, 0.8f, 1));
}

static void setupFog(bool on) {
    if (on) {
        GLfloat fc[4] = {0.78f, 0.84f, 0.90f, 1.0f};
        glEnable(GL_FOG);
        glFogi(GL_FOG_MODE, GL_LINEAR);
        glFogf(GL_FOG_START, FOG_START);
        glFogf(GL_FOG_END, FOG_END);
        glFogfv(GL_FOG_COLOR, fc);
    } else glDisable(GL_FOG);
}

// ---------------------------------------------------------------------
//  Main
// ---------------------------------------------------------------------
int main() {
    scePowerSetArmClockFrequency(444);
    scePowerSetBusClockFrequency(222);
    scePowerSetGpuClockFrequency(222);
    scePowerSetGpuXbarClockFrequency(166);

    vglInit(0x800000);
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG_WIDE);

    glViewport(0, 0, SCR_W, SCR_H);
    glClearColor(0.78f, 0.84f, 0.90f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_TEXTURE_2D);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    makeTextures();
    genWorld();

    memset(&P, 0, sizeof(P));
    P.x = 160.0f; P.z = 165.0f; P.y = 0; P.yaw = 0; P.ground = true;
    g_rng = 0xBEEF1234u;
    for (int i = 0; i < NUM_NPCS; i++) npcSpawn(g_npcs[i], P.x, P.z, false);
    memset(g_decals, 0, sizeof(g_decals));
    for (int i = 0; i < MAX_PARTICLES; i++) g_parts[i].life = 0;

    g_dyn.p.reserve(120000); g_dyn.t.reserve(80000); g_dyn.c.reserve(160000);
    g_hud.p.reserve(60000); g_hud.t.reserve(40000); g_hud.c.reserve(80000);

    SceCtrlData pad; memset(&pad, 0, sizeof(pad));
    uint32_t prevButtons = 0;
    uint64_t last = sceKernelGetProcessTimeWide();
    float fpsAcc = 0; int fpsFrames = 0; int fpsShown = 0;
    const float aspect = (float)SCR_W / (float)SCR_H;

    for (;;) {
        uint64_t now = sceKernelGetProcessTimeWide();
        float dt = (now - last) / 1000000.0f; last = now;
        if (dt > 0.05f) dt = 0.05f;
        fpsAcc += dt; fpsFrames++;
        if (fpsAcc >= 0.5f) { fpsShown = (int)(fpsFrames / fpsAcc + 0.5f); fpsAcc = 0; fpsFrames = 0; }

        sceCtrlPeekBufferPositive(0, &pad, 1);
        uint32_t btn = pad.buttons, pressed = btn & ~prevButtons;
        prevButtons = btn;

        if (pressed & SCE_CTRL_START) g_paused = !g_paused;
        if (g_paused && (pressed & SCE_CTRL_SELECT)) break;

        float lx = (pad.lx - 128) / 128.0f, ly = (pad.ly - 128) / 128.0f;
        float rx = (pad.rx - 128) / 128.0f, ry = (pad.ry - 128) / 128.0f;
        {   // radial deadzones with rescale
            float m = sqrtf(lx * lx + ly * ly);
            if (m < 0.2f) { lx = ly = 0; } else { float s = fminf(1.0f, (m - 0.2f) / 0.8f) / m; lx *= s; ly *= s; }
            m = sqrtf(rx * rx + ry * ry);
            if (m < 0.18f) { rx = ry = 0; } else { float s = fminf(1.0f, (m - 0.18f) / 0.82f) / m; rx *= s; ry *= s; }
        }

        if (!g_paused) {
            if (g_helpT > 0) g_helpT -= dt;
            // ---- look
            float rm = sqrtf(rx * rx + ry * ry);
            float curve = rm; // stick * magnitude = squared response
            float lookMul = lerpf(1.0f, ADS_LOOK_MUL, g_ads);
            P.yaw -= rx * curve * LOOK_YAW * lookMul * dt;
            P.pitch -= ry * curve * LOOK_PITCH * lookMul * dt;
            P.pitch = clampf(P.pitch, -1.45f, 1.45f);
            P.yaw = wrapAngle(P.yaw);

            // ---- states
            bool wantAds = (btn & SCE_CTRL_LTRIGGER) && g_reload < 0;
            bool firing = (btn & SCE_CTRL_RTRIGGER) != 0;
            bool wantSprint = (btn & SCE_CTRL_CIRCLE) && ly < -0.3f && !wantAds && !firing;
            g_sprint = approach(g_sprint, wantSprint ? 1.0f : 0.0f, 10.0f, dt);
            g_ads = approach(g_ads, wantAds ? 1.0f : 0.0f, 16.0f, dt);
            if (g_ads < 0.002f) g_ads = 0;
            if (g_ads > 0.998f) g_ads = 1;

            // ---- move
            float spd = lerpf(WALK_SPEED, SPRINT_SPEED, g_sprint) * lerpf(1.0f, ADS_SPEED_MUL, g_ads);
            float fx = -sinf(P.yaw), fz = -cosf(P.yaw);
            float rxw = cosf(P.yaw), rzw = -sinf(P.yaw);
            float tvx = (fx * -ly + rxw * lx) * spd, tvz = (fz * -ly + rzw * lx) * spd;
            float accel = P.ground ? 12.0f : 2.5f;
            P.vx = approach(P.vx, tvx, accel, dt);
            P.vz = approach(P.vz, tvz, accel, dt);
            P.x += P.vx * dt; P.z += P.vz * dt;

            float gh = groundHeight(P.x, P.z);
            if (P.ground && (pressed & SCE_CTRL_CROSS)) { P.vy = JUMP_VEL; P.ground = false; }
            if (!P.ground || P.y > gh + 0.01f) {
                P.vy -= GRAVITY * dt; P.y += P.vy * dt;
                if (P.y <= gh) { P.y = gh; P.vy = 0; P.ground = true; } else P.ground = false;
            } else {
                P.y = approach(P.y, gh, 25.0f, dt); // step up/down curbs smoothly
                P.ground = true;
            }
            collidePlayer();

            float hs = sqrtf(P.vx * P.vx + P.vz * P.vz);
            P.moveAmt = approach(P.moveAmt, P.ground ? clampf(hs / WALK_SPEED, 0, 1.4f) : 0.0f, 10.0f, dt);
            P.bobPhase += dt * hs * 1.85f;

            // ---- weapon
            g_fireCD -= dt;
            g_recoil = approach(g_recoil, 0, 14.0f, dt);
            g_bloom = approach(g_bloom, 0, 5.0f, dt);
            if (g_flash > 0) g_flash -= dt;
            if (g_hitMarker > 0) g_hitMarker -= dt;
            if (g_reload >= 0) {
                g_reload += dt;
                if (g_reload >= RELOAD_TIME) { g_reload = -1; g_ammo = MAG_SIZE; }
            } else {
                if ((pressed & SCE_CTRL_SQUARE) && g_ammo < MAG_SIZE) g_reload = 0;
                else if (firing && g_ammo <= 0 && (pressed & SCE_CTRL_RTRIGGER)) g_reload = 0;
                else if (firing && g_fireCD <= 0 && g_ammo > 0 && g_sprint < 0.3f) fireShot();
                if (g_ammo <= 0 && g_reload < 0 && g_fireCD <= -0.25f) g_reload = 0; // auto reload
            }

            // ---- world sim
            updateNpcs(dt, P.x, P.z);
            for (int i = 0; i < MAX_PARTICLES; i++) {
                Particle& q = g_parts[i]; if (q.life <= 0) continue;
                q.life -= dt; q.v.y -= q.grav * dt; q.p = q.p + q.v * dt;
                if (q.p.y < 0.02f) { q.p.y = 0.02f; q.v = q.v * 0.3f; }
            }
        }

        // ================= RENDER =================
        float vfov = lerpf(FOV_HIP, FOV_ADS, g_ads);
        float hfov = atanf(tanf(vfov * PI_F / 360.0f) * aspect);
        Vec3 eye = v3(P.x, P.y + EYE_HEIGHT + sinf(P.bobPhase * 2.0f) * 0.03f * P.moveAmt * (1.0f - g_ads * 0.7f), P.z);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        Mat4 proj = mPerspective(vfov, aspect, 0.1f, FAR_PLANE);
        Mat4 view = mMul(mRotX(-P.pitch), mMul(mRotY(-P.yaw), mTrans(-eye.x, -eye.y, -eye.z)));
        glMatrixMode(GL_PROJECTION); glLoadMatrixf(proj.m);
        glMatrixMode(GL_MODELVIEW); glLoadMatrixf(view.m);

        // sky
        setupFog(false);
        glDepthMask(GL_FALSE);
        glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
        buildSky(eye);
        drawMesh(g_sky);
        glDepthMask(GL_TRUE);

        // static world
        setupFog(true);
        glBindTexture(GL_TEXTURE_2D, g_tex[T_ASPHALT]);
        drawMesh(g_outerGround);
        for (int ci = 0; ci < NCHUNK; ci++)
            for (int cj = 0; cj < NCHUNK; cj++) {
                float cx = (CELL_MIN + ci * 2) * CELL + CELL, cz = (CELL_MIN + cj * 2) * CELL + CELL;
                if (!inView(cx, cz, 58.0f, hfov)) continue;
                for (int t = 0; t < NTEX; t++) {
                    if (g_chunks[ci][cj].base[t].count() == 0) continue;
                    glBindTexture(GL_TEXTURE_2D, g_tex[t]);
                    drawMesh(g_chunks[ci][cj].base[t]);
                }
            }
        glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
        for (int i = 0; i < NCELL; i++)
            for (int j = 0; j < NCELL; j++) {
                float cx = (CELL_MIN + i) * CELL + CELL * 0.5f, cz = (CELL_MIN + j) * CELL + CELL * 0.5f;
                float dx = cx - P.x, dz = cz - P.z;
                if (dx * dx + dz * dz > (PROP_DIST + 28) * (PROP_DIST + 28)) continue;
                if (!inView(cx, cz, 30.0f, hfov)) continue;
                drawMesh(g_props[i][j].props);
            }

        // dynamic world: NPCs + decals
        g_dyn.clear();
        for (int i = 0; i < NUM_NPCS; i++) {
            Npc& n = g_npcs[i];
            float dx = n.x - P.x, dz = n.z - P.z, d2 = dx * dx + dz * dz;
            if (d2 > NPC_DRAW_DIST * NPC_DRAW_DIST) continue;
            if (!inView(n.x, n.z, 1.5f, hfov)) continue;
            buildNpc(g_dyn, n, d2 > 38.0f * 38.0f ? 2 : (d2 > 18.0f * 18.0f ? 1 : 0));
        }
        for (int i = 0; i < MAX_DECALS; i++) {
            Decal& d = g_decals[i]; if (!d.used) continue;
            Vec3 ref = fabsf(d.n.y) > 0.9f ? v3(1, 0, 0) : v3(0, 1, 0);
            Vec3 t1 = norm3(cross3(ref, d.n)), t2 = cross3(d.n, t1);
            billboard(g_dyn, d.p, t1, t2, d.s, col4(0.08f, 0.08f, 0.08f));
        }
        drawMesh(g_dyn);

        // particles (blended, no depth write)
        Vec3 cf = camForward();
        Vec3 cr = v3(cosf(P.yaw), 0, -sinf(P.yaw));
        Vec3 cu = cross3(cr, cf);
        g_blend.clear();
        for (int i = 0; i < MAX_PARTICLES; i++) {
            Particle& q = g_parts[i]; if (q.life <= 0) continue;
            Col c = q.c; c.a *= clampf(q.life / q.maxLife * 1.5f, 0, 1);
            billboard(g_blend, q.p, cr, cu, q.size, c);
        }
        if (g_blend.count()) {
            glEnable(GL_BLEND); glDepthMask(GL_FALSE);
            drawMesh(g_blend);
            glDepthMask(GL_TRUE); glDisable(GL_BLEND);
        }

        // ---- viewmodel
        setupFog(false);
        glClear(GL_DEPTH_BUFFER_BIT);
        Mat4 gproj = mPerspective(FOV_GUN, aspect, 0.01f, 5.0f);
        Mat4 ident = mIdent();
        glMatrixMode(GL_PROJECTION); glLoadMatrixf(gproj.m);
        glMatrixMode(GL_MODELVIEW); glLoadMatrixf(ident.m);
        g_gun.clear();
        buildGunAndArms(g_gun, g_paused ? 0.0f : dt, rx, ry);
        drawMesh(g_gun);
        g_blend.clear();
        buildMuzzleFlash(g_blend);
        if (g_blend.count()) {
            glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE); glDepthMask(GL_FALSE);
            drawMesh(g_blend);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); glDepthMask(GL_TRUE); glDisable(GL_BLEND);
        }

        // ---- HUD
        Mat4 ortho = mOrtho(0, SCR_W, SCR_H, 0, -1, 1);
        glMatrixMode(GL_PROJECTION); glLoadMatrixf(ortho.m);
        glMatrixMode(GL_MODELVIEW); glLoadMatrixf(ident.m);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        g_hud.clear();
        {
            const float cx = SCR_W * 0.5f, cy = SCR_H * 0.5f;
            float a = 1.0f - g_ads;
            if (a > 0.02f && g_sprint < 0.5f) {
                float moving = clampf(sqrtf(P.vx * P.vx + P.vz * P.vz) / WALK_SPEED, 0, 1);
                float gap = 7.0f + (g_bloom + moving * 0.02f) * 520.0f;
                Col c = col4(1, 1, 1, 0.85f * a), sh = col4(0, 0, 0, 0.4f * a);
                rect2(g_hud, cx - gap - 10 - 1, cy - 2, 12, 4, sh); rect2(g_hud, cx + gap - 1, cy - 2, 12, 4, sh);
                rect2(g_hud, cx - 2, cy - gap - 10 - 1, 4, 12, sh); rect2(g_hud, cx - 2, cy + gap - 1, 4, 12, sh);
                rect2(g_hud, cx - gap - 10, cy - 1, 10, 2, c); rect2(g_hud, cx + gap, cy - 1, 10, 2, c);
                rect2(g_hud, cx - 1, cy - gap - 10, 2, 10, c); rect2(g_hud, cx - 1, cy + gap, 2, 10, c);
                rect2(g_hud, cx - 1, cy - 1, 2, 2, c);
            }
            if (g_hitMarker > 0) {
                Col hc = g_hitKill ? col4(1, 0.2f, 0.2f, 1) : col4(1, 1, 1, 1);
                for (int k = 0; k < 4; k++) {
                    float sx = (k & 1) ? 1.0f : -1.0f, sy = (k & 2) ? 1.0f : -1.0f;
                    for (int s = 0; s < 4; s++)
                        rect2(g_hud, cx + sx * (8 + s * 2.5f) - 1.5f, cy + sy * (8 + s * 2.5f) - 1.5f, 3, 3, hc);
                }
            }
            // ammo
            char buf[64];
            snprintf(buf, sizeof(buf), "%d", g_ammo);
            Col ac = g_ammo <= 5 ? col4(1, 0.35f, 0.3f, 1) : col4(1, 1, 1, 1);
            text2(g_hud, SCR_W - 40 - textWidth(buf, 6) - textWidth("/30", 3) - 8, SCR_H - 66, 6, buf, ac);
            text2(g_hud, SCR_W - 40 - textWidth("/30", 3), SCR_H - 45, 3, "/30", col4(0.85f, 0.85f, 0.85f, 1));
            if (g_reload >= 0) {
                const char* r = "RELOADING";
                text2(g_hud, cx - textWidth(r, 3) * 0.5f, cy + 60, 3, r, col4(1, 1, 1, 0.9f));
                float t = clampf(g_reload / RELOAD_TIME, 0, 1);
                rect2(g_hud, cx - 60, cy + 86, 120, 5, col4(0, 0, 0, 0.5f));
                rect2(g_hud, cx - 60, cy + 86, 120 * t, 5, col4(1, 1, 1, 0.9f));
            } else if (g_ammo == 0) {
                const char* r = "PRESS SQUARE TO RELOAD";
                text2(g_hud, cx - textWidth(r, 2) * 0.5f, cy + 60, 2, r, col4(1, 0.4f, 0.3f, 1));
            }
            snprintf(buf, sizeof(buf), "FPS %d", fpsShown);
            text2(g_hud, SCR_W - textWidth(buf, 2) - 12, 10, 2, buf, col4(1, 1, 1, 0.7f));
            int aliveN = 0; for (int i = 0; i < NUM_NPCS; i++) if (g_npcs[i].alive) aliveN++;
            snprintf(buf, sizeof(buf), "CITY SANDBOX  POP %d", aliveN);
            text2(g_hud, 12, 10, 2, buf, col4(1, 1, 1, 0.8f));
            // minimal compass heading
            float deg = fmodf(-P.yaw * 180.0f / PI_F + 360.0f, 360.0f);
            const char* dirs[8] = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
            const char* hd = dirs[((int)((deg + 22.5f) / 45.0f)) % 8];
            text2(g_hud, cx - textWidth(hd, 3) * 0.5f, 12, 3, hd, col4(1, 1, 1, 0.8f));

            if (g_helpT > 0 && !g_paused) {
                float al = clampf(g_helpT, 0, 1);
                const char* lines[] = {"L STICK MOVE   R STICK LOOK", "L AIM   R SHOOT   SQUARE RELOAD",
                                       "CROSS JUMP   HOLD CIRCLE SPRINT", "START PAUSE"};
                for (int i = 0; i < 4; i++) text2(g_hud, 14, SCR_H - 110 + i * 22, 2, lines[i], col4(1, 1, 1, al));
            }
            if (g_paused) {
                rect2(g_hud, 0, 0, SCR_W, SCR_H, col4(0, 0, 0, 0.6f));
                const char* t = "PAUSED";
                text2(g_hud, cx - textWidth(t, 7) * 0.5f, 110, 7, t, col4(1, 1, 1, 1));
                const char* lines[] = {"LEFT STICK - MOVE", "RIGHT STICK - LOOK", "L - AIM DOWN SIGHTS",
                                       "R - SHOOT", "SQUARE - RELOAD", "CROSS - JUMP", "HOLD CIRCLE - SPRINT",
                                       "", "START - RESUME", "SELECT - QUIT"};
                for (int i = 0; i < 10; i++)
                    text2(g_hud, cx - textWidth(lines[i], 3) * 0.5f, 200 + i * 28, 3, lines[i], col4(1, 1, 1, 0.95f));
            }
        }
        glBindTexture(GL_TEXTURE_2D, g_tex[T_WHITE]);
        drawMesh(g_hud);
        glDisable(GL_BLEND);
        glEnable(GL_DEPTH_TEST);

        vglSwapBuffers(GL_FALSE);
    }

    vglEnd();
    sceKernelExitProcess(0);
    return 0;
}
