# City Sandbox v0.3 (PS Vita)

First-person open-world city sandbox. ~320m city grid (about a minute to
cross on foot), 90 NPC pedestrians, rifle with iron-sight ADS, hitscan shooting.

## Build on GitHub (no computer needed)
1. Put `build.yml` in the repo at `.github/workflows/build.yml`.
2. Upload `CitySandbox.zip` to the repo root (keep only one .zip there).
3. Actions tab -> latest run -> download the `CitySandbox-vpk` artifact.
4. Unzip the artifact to get `CitySandbox.vpk`, install with VitaShell.

Requires `ur0:data/libshacccg.suprx` (same as other vitaGL homebrew).

## Story so far
You start next to Walt (yellow ! over his head). Mow his front lawn (90%+)
for $25, then walk to the GUN STORE (red block on the phone map) and buy
the rifle. You have no gun until you buy it.

## Gun bench (v0.3)
Walk into the gun store (door under the red sign). The bench is on the
right wall. Triangle to open. 5 categories x 4 parts (barrel, muzzle,
sight, magazine, underbarrel); each part is modeled on the rifle and
changes stats. Downed pedestrians drop cash ($4-$12) - walk over it.

## Controls
Left stick move | Right stick look | Triangle talk / interact
L aim down sights | R shoot (full auto) | Square reload
Cross jump | Hold Circle sprint | Select phone (Map, Quests, Wallet)
Start pause (Select in pause = quit)
Phone: D-pad left/right pick app, Cross open, Circle back

## Where to tweak
All tunables are at the top of `src/main.cpp` (speeds, FOVs, fog/draw
distance, fire rate, mag size, NPC count).
