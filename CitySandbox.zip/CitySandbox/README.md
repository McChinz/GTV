# City Sandbox v0.1 (PS Vita)

First-person open-world city sandbox. ~320m city grid (about a minute to
cross on foot), 90 NPC pedestrians, rifle with iron-sight ADS, hitscan shooting.

## Build on GitHub (no computer needed)
1. Put `build.yml` in the repo at `.github/workflows/build.yml`.
2. Upload `CitySandbox.zip` to the repo root (keep only one .zip there).
3. Actions tab -> latest run -> download the `CitySandbox-vpk` artifact.
4. Unzip the artifact to get `CitySandbox.vpk`, install with VitaShell.

Requires `ur0:data/libshacccg.suprx` (same as other vitaGL homebrew).

## Controls
Left stick move | Right stick look | L aim down sights | R shoot (full auto)
Square reload | Cross jump | Hold Circle sprint | Start pause (Select = quit)

## Where to tweak
All tunables are at the top of `src/main.cpp` (speeds, FOVs, fog/draw
distance, fire rate, mag size, NPC count).
