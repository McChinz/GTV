# City Sandbox v0.5 (PS Vita)

First-person open-world city sandbox. ~320m city grid (about a minute to
cross on foot), 90 NPC pedestrians, rifle with iron-sight ADS, hitscan shooting.

## Build on GitHub (no computer needed)
1. Put `build.yml` in the repo at `.github/workflows/build.yml`.
2. Upload `CitySandbox.zip` to the repo root (keep only one .zip there).
3. Actions tab -> latest run -> download the `CitySandbox-vpk` artifact.
4. Unzip the artifact to get `CitySandbox.vpk`, install with VitaShell.

Requires `ur0:data/libshacccg.suprx` (same as other vitaGL homebrew).

## Story so far
You start next to Walt (yellow ! over his head). Mow his front lawn (90%+)
for $25, then walk to the GUN STORE (red block on the phone map) and buy
the rifle. You have no gun until you buy it.

## Gun bench (v0.3)
Walk into the gun store (door under the red sign). The bench is on the
right wall. Triangle to open. 5 categories x 4 parts (barrel, muzzle,
sight, magazine, underbarrel); each part is modeled on the rifle and
changes stats. Downed pedestrians drop cash ($4-$12) - walk over it.

## Traffic + paint job (v0.4)
56 cars drive on the right, stop at red/yellow lights (signal heads on
every corner pole), queue, signal turns, yield on left turns, and stop
for pedestrians and you. Pedestrians wait for the walk phase.
Side quest: Rosa (! marker, the house next door to Walt) wants her living
room painted. Inside: hold R to roll paint, D-pad left/right picks color.
90% of the walls = $40.

## v0.5
- Road hierarchy: 12m avenues on every other grid line, 8m side streets
  between. Traffic lights only where two avenues cross; two-way stop signs
  where a side street meets an avenue; all-way stops where side streets meet.
- Alleys cut through some blocks (dumpsters, trash bags, fire escapes).
- Bodies sink away after ~15s and the person respawns elsewhere.
- Pistol ($15) at the gun store: semi-auto, its own 20 modeled parts at the
  gun bench (L/R at the bench switches weapon). D-pad up swaps guns in play.
- Barista job at the CAFE (C on the map): apply with the manager, then use
  the espresso machine. Hold X to pour, let go at the line; the flow speeds
  up and slows down at random. 8 cups a shift, tips for perfect pours.

## Controls
Left stick move | Right stick look | Triangle talk / interact
L aim down sights | R shoot (full auto) | Square reload
Cross jump | Hold Circle sprint | Select phone (Map, Quests, Wallet)
Start pause (Select in pause = quit)
Phone: D-pad left/right pick app, Cross open, Circle back

## Where to tweak
All tunables are at the top of `src/main.cpp` (speeds, FOVs, fog/draw
distance, fire rate, mag size, NPC count).
